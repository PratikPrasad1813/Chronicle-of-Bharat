(function(){
  'use strict';
  var events=(window.MAP_TIMELINE_EVENTS||[]).slice().sort(function(a,b){return a.year-b.year||a.title.localeCompare(b.title);});
  var range=document.getElementById('map-time-range'),dateLabel=document.getElementById('map-time-label'),list=document.getElementById('map-time-events'),panel=document.getElementById('map-time-detail'),markers=document.getElementById('map-time-markers'),filter=document.getElementById('map-era-filter'),play=document.getElementById('map-time-play');
  var featureGroup=document.getElementById('map-time-geography'),mapSvg=document.getElementById('map-time-svg');
  if(!range||!events.length)return;
  var selected=Math.max(0,events.findIndex(function(e){return e.year>=1947;}));
  var playing=false,timer=null;
  range.min='0';range.max=String(events.length-1);range.step='1';range.value=String(selected);
  function eraLabel(era){return ({ancient:'Ancient',medieval:'Medieval',colonial:'Colonial',modern:'Post-Independence'})[era]||era;}
  function safeText(n,text){n.textContent=String(text==null?'':text);return n;}
  function eventLink(event){
    var row=document.createElement('button');row.type='button';row.className='cb-map-event'+(events.indexOf(event)===selected?' is-active':'');
    var date=document.createElement('small');safeText(date,event.date+' · '+eraLabel(event.era));
    var title=document.createElement('strong');safeText(title,event.title);
    var place=document.createElement('span');safeText(place,event.place);
    row.appendChild(date);row.appendChild(title);row.appendChild(place);
    row.addEventListener('click',function(){setSelected(events.indexOf(event));});
    return row;
  }
  function currentDate(e){return e.year<0?Math.abs(e.year).toLocaleString('en-IN')+' BCE':e.year===0?'c. 1 BCE / 1 CE':e.year.toLocaleString('en-IN')+' CE';}
  function drawPanel(e){
    panel.textContent='';
    var eyebrow=document.createElement('p');eyebrow.className='cb-kicker';safeText(eyebrow,e.date+' · '+eraLabel(e.era));
    var title=document.createElement('h2');safeText(title,e.title);
    var place=document.createElement('p');place.className='cb-map-detail__place';safeText(place,'📍 '+e.place);
    var body=document.createElement('p');safeText(body,e.summary);
    var actions=document.createElement('div');actions.className='cb-page-actions';
    if(e.url){var chapter=document.createElement('a');chapter.className='cb-btn cb-btn--primary';chapter.href=e.url;safeText(chapter,'Read the related chapter →');actions.appendChild(chapter);}
    [['English Wikipedia','en'],['हिंदी विकिपीडिया','hi']].forEach(function(item){var wiki=document.createElement('a');wiki.className='cb-btn cb-btn--quiet';wiki.target='_blank';wiki.rel='noopener noreferrer';wiki.href='https://'+item[1]+'.wikipedia.org/w/index.php?search='+encodeURIComponent(e.title)+'&go=Go';safeText(wiki,item[0]+' ↗');actions.appendChild(wiki);});
    panel.appendChild(eyebrow);panel.appendChild(title);panel.appendChild(place);panel.appendChild(body);panel.appendChild(actions);
  }
  function drawList(){
    var era=filter?filter.value:'all';
    var visible=events.filter(function(e,i){return i<=selected&&(era==='all'||e.era===era);});
    var limit=14;if(visible.length>limit)visible=visible.slice(-limit);
    list.textContent='';
    if(!visible.length){var empty=document.createElement('p');safeText(empty,'No earlier events match this filter yet. Move the timeline forward.');list.appendChild(empty);return;}
    visible.forEach(function(e){list.appendChild(eventLink(e));});
  }
  function drawMarkers(){
    markers.textContent='';
    var era=filter?filter.value:'all';
    events.forEach(function(e,i){
      if(i>selected||(era!=='all'&&era!==e.era))return;
      var pt=window.projectLonLat?window.projectLonLat(e.lon,e.lat):{x:0,y:0};
      var b=document.createElement('button');b.type='button';b.className='cb-map-pin cb-map-pin--'+e.era+(i===selected?' is-selected':'')+(i<selected?' is-old':'');
      b.style.left=(pt.x/1000*100)+'%';b.style.top=(pt.y/1000*100)+'%';
      b.setAttribute('aria-label',e.date+': '+e.title+' at '+e.place);b.title=e.date+' — '+e.title;
      b.addEventListener('click',function(){setSelected(i);});markers.appendChild(b);
    });
  }
  function render(){
    var e=events[selected];if(!e)return;
    dateLabel.textContent=e.date+' · '+eraLabel(e.era);
    range.setAttribute('aria-valuetext',e.date+' — '+e.title);
    drawPanel(e);drawList();drawMarkers();
    var count=events.slice(0,selected+1).filter(function(item){return !filter||filter.value==='all'||item.era===filter.value;}).length;
    var countEl=document.getElementById('map-time-count');if(countEl)countEl.textContent=count+' mapped '+(count===1?'event':'events')+' up to this point';
  }
  function setSelected(i){selected=Math.max(0,Math.min(events.length-1,i));range.value=String(selected);render();}
  range.addEventListener('input',function(){setSelected(parseInt(range.value,10)||0);});
  if(filter)filter.addEventListener('change',render);
  document.querySelectorAll('[data-map-jump]').forEach(function(button){button.addEventListener('click',function(){var year=Number(button.getAttribute('data-map-jump'));var i=0;for(var j=0;j<events.length;j++){if(events[j].year<=year)i=j;else break;}setSelected(i);});});
  document.getElementById('map-time-prev').addEventListener('click',function(){setSelected(selected-1);});
  document.getElementById('map-time-next').addEventListener('click',function(){setSelected(selected+1);});
  if(play)play.addEventListener('click',function(){
    playing=!playing;play.textContent=playing?'Pause timeline':'Play timeline';play.setAttribute('aria-pressed',String(playing));
    if(playing){timer=setInterval(function(){if(selected>=events.length-1){setSelected(0);}else setSelected(selected+1);},1500);}else{clearInterval(timer);timer=null;}
  });
  document.addEventListener('visibilitychange',function(){if(document.hidden&&playing){playing=false;clearInterval(timer);timer=null;if(play){play.textContent='Play timeline';play.setAttribute('aria-pressed','false');}}});
  function loadMap(){
    var href=window.INDIA_GEO&&window.INDIA_GEO.svgHref;
    if(!href||!window.fetch)return;
    fetch(href).then(function(r){if(!r.ok)throw new Error('Map unavailable');return r.text();}).then(function(text){
      var source=new DOMParser().parseFromString(text,'image/svg+xml');
      var root=source.documentElement,features=source.getElementById('features');
      if(!features||!mapSvg||!featureGroup)return;
      mapSvg.setAttribute('viewBox',root.getAttribute('viewBox')||'0 0 1000 1000');
      featureGroup.appendChild(document.importNode(features,true));
    }).catch(function(){var note=document.getElementById('map-load-note');if(note)note.hidden=false;});
  }
  loadMap();render();
})();
