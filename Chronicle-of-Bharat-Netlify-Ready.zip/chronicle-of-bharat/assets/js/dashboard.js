(function(){
  'use strict';
  var api=window.ChronicleStudy;
  if(!api)return;
  var state=api.read();
  var revisionKey='chronicle-revision-v1';
  var topics={
    ancient:{label:'Ancient India',className:'ancient',items:[
      ['Historiography','ancient-india/historiography.html'],['Prehistory','ancient-india/prehistory.html'],['Indus Valley','ancient-india/indus-valley.html'],['The Vedic Age','ancient-india/vedic-age.html'],['Keezhadi','ancient-india/keezhadi.html'],['Mauryas to Guptas','ancient-india/mauryas-guptas.html']
    ]},
    medieval:{label:'Medieval India',className:'medieval',items:[
      ['Tripartite Struggle','medieval-india/tripartite-struggle.html'],['Delhi Sultanate','medieval-india/delhi-sultanate.html'],['Vijayanagara & the Deccan','medieval-india/vijayanagara-deccan.html'],['Bhakti & Sufi Kingdoms','medieval-india/bhakti-sufi.html'],['Mughal Empire','medieval-india/mughal-empire.html'],['Maratha Ascendancy','medieval-india/maratha-ascendancy.html']
    ]},
    colonial:{label:'Colonial India',className:'colonial',items:[
      ['Mughal Decline','colonial-india/mughal-decline.html'],['Company Raj','colonial-india/company-raj.html'],['The Great Rebellion','colonial-india/the-great-rebellion.html'],['Deindustrialisation','colonial-india/deindustrialisation-debate.html'],['Land & Famine','colonial-india/land-and-famine.html'],['Resistance & Reform','colonial-india/resistance-and-reform.html'],['Steel Frame & Partition','colonial-india/steel-frame-and-partition.html']
    ]},
    modern:{label:'Post-Independence India',className:'modern',items:[
      ['Princely Integration','modern-india/princely-states.html'],['Planning & Nonalignment','modern-india/nehruvian-planning.html'],['Green Revolution','modern-india/green-revolution.html'],['Pokhran-I (1974)','modern-india/pokhran-1974.html'],['Pokhran-II (1998)','modern-india/pokhran-1998.html'],['The 1991 Reforms','modern-india/reforms-1991.html'],['Caste & Secularism','modern-india/caste-secularism.html']
    ]},
    themes:{label:'Thematic Studies',className:'themes',items:[
      ['Rajasthan & the North-West','thematic-studies/rajasthan-northwest.html'],['Indian Ocean trade','thematic-studies/indian-ocean.html'],['People’s Histories','thematic-studies/peoples-histories.html'],['Constitutional Federalism','thematic-studies/constitution-federalism.html'],['Environmental History','thematic-studies/environmental-history.html'],['Science, Technology & Knowledge','thematic-studies/science-knowledge.html'],['Cities Through Time','thematic-studies/cities-through-time.html'],['Regional Movements Atlas','thematic-studies/regional-movements.html'],['Exam Answer Workshops','thematic-studies/exam-answer-workshops.html']
    ]}
  };
  var topicPaths=Object.keys(topics).reduce(function(all,k){return all.concat(topics[k].items.map(function(item){return item[1];}));},[]);
  var totalTopics=topicPaths.length;
  function $(id){return document.getElementById(id);}
  function readRevision(){try{var r=JSON.parse(localStorage.getItem(revisionKey)||'{"cards":{},"custom":[],"deletedCustom":[]}');if(!r||typeof r!=='object')return {cards:{},custom:[],deletedCustom:[]};if(!r.cards||typeof r.cards!=='object')r.cards={};if(!Array.isArray(r.custom))r.custom=[];if(!Array.isArray(r.deletedCustom))r.deletedCustom=[];return r;}catch(e){return {cards:{},custom:[],deletedCustom:[]};}}
  function dueCount(){
    var r=readRevision(),now=Date.now(),cards=r.cards||{},all=[];
    (window.GLOSSARY||[]).forEach(function(t){var id='g-'+String(t.term+'-'+t.era).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');all.push(id);});
    (Array.isArray(r.custom)?r.custom:[]).forEach(function(t){all.push(t.id);});
    if(!all.length)all=Object.keys(cards);
    return all.filter(function(k){var card=cards[k];return !card||!card.due||Number(card.due)<=now;}).length;
  }
  function pct(){var count=topicPaths.filter(function(k){return !!(state.completed||{})[k];}).length;return {count:count,total:totalTopics,pct:Math.round(count/totalTopics*100)};}
  function save(){state=api.read();renderStats();}
  function renderTopics(){
    var root=$('cb-era-grid');if(!root)return;root.textContent='';
    Object.keys(topics).forEach(function(key){
      var group=topics[key],card=document.createElement('article');card.className='cb-card cb-era-card cb-era-card--'+group.className;
      var head=document.createElement('div');head.className='cb-era-head';var title=document.createElement('h3');title.textContent=group.label;var done=document.createElement('span');
      var completeCount=group.items.filter(function(item){return !!state.completed[item[1]];}).length;done.textContent=completeCount+' / '+group.items.length+' complete';head.appendChild(title);head.appendChild(done);card.appendChild(head);
      var list=document.createElement('div');list.className='cb-topic-list';
      group.items.forEach(function(item){
        var row=document.createElement('div');row.className='cb-topic';var check=document.createElement('input');check.type='checkbox';check.checked=!!state.completed[item[1]];check.setAttribute('aria-label','Mark '+item[0]+' complete');
        check.addEventListener('change',function(){state=api.read();if(check.checked)state.completed[item[1]]={at:Date.now(),title:item[0]};else delete state.completed[item[1]];api.write(state);state=api.read();renderTopics();renderStats();});
        var a=document.createElement('a');a.href=item[1];a.textContent=item[0];var meta=document.createElement('small');meta.textContent=state.visited[item[1]]?'Visited on this device':'Not visited yet';a.appendChild(meta);
        var status=document.createElement('span');status.className='cb-topic__status';status.textContent=state.completed[item[1]]?'DONE':'OPEN';row.appendChild(check);row.appendChild(a);row.appendChild(status);list.appendChild(row);
      });
      card.appendChild(list);root.appendChild(card);
    });
  }
  function renderStats(){
    var result=pct();$('cb-stat-completed').textContent=result.count;$('cb-stat-topics-total').textContent='of '+result.total+' topics';$('cb-stat-visited').textContent=Object.keys(state.visited||{}).length;$('cb-stat-due').textContent=dueCount();
    var progress=$('cb-progress-bar');if(progress)progress.style.width=result.pct+'%';var box=document.querySelector('[role="progressbar"]');if(box)box.setAttribute('aria-valuenow',String(result.pct));
    var copy=$('cb-progress-copy');if(copy)copy.textContent=result.count+' of '+result.total+' study topics marked complete · '+result.pct+'%';
    var attempts=state.quizAttempts||[];$('cb-stat-quizzes').textContent=attempts.length;
    var best=attempts.slice().sort(function(a,b){return Number(b.pct||0)-Number(a.pct||0);})[0];
    if(!best){try{best=JSON.parse(localStorage.getItem('chronicle-quiz-best')||'null');}catch(e){}}
    $('cb-stat-best').textContent=best?(Number(best.pct)||0)+'% best score':'Start a quiz to record a score';
    var record=$('cb-quiz-record');record.textContent='';
    if(!attempts.length){var none=document.createElement('p');none.textContent=best?'Best cross-era score: '+best.score+'/'+best.total+' ('+best.pct+'%).':'No quiz attempts recorded yet.';record.appendChild(none);}
    else{
      var list=document.createElement('div');list.className='cb-topic-list';
      attempts.slice(0,5).forEach(function(a){var item=document.createElement('div');item.className='cb-topic';var title=document.createElement('strong');title.textContent=(a.eraLabel||a.era||'Cross-era')+' quiz';var resultText=document.createElement('span');resultText.className='cb-topic__status';resultText.textContent=(a.score||0)+'/'+(a.total||0)+' · '+(a.pct||0)+'%';var when=document.createElement('small');when.textContent=a.date||new Date(a.at||Date.now()).toLocaleDateString();title.appendChild(when);item.appendChild(title);item.appendChild(resultText);list.appendChild(item);});record.appendChild(list);
    }
    var last=$('cb-last-page');if(last){last.textContent='';if(state.lastPage){var copy=document.createElement('p');copy.innerHTML='<strong></strong><br><span></span>';copy.querySelector('strong').textContent=state.lastTitle||state.lastPage;copy.querySelector('span').textContent=state.lastVisitedAt?'Last opened '+new Date(state.lastVisitedAt).toLocaleString():'';var link=document.createElement('a');link.className='cb-btn cb-btn--primary';link.href=state.lastPage;link.textContent='Continue reading →';last.appendChild(copy);last.appendChild(link);}else{var msg=document.createElement('p');msg.textContent='Open a chapter to start building your local progress.';var start=document.createElement('a');start.className='cb-btn cb-btn--primary';start.href='ancient.html';start.textContent='Begin with Ancient India →';last.appendChild(msg);last.appendChild(start);}}
  }
  function bindNotes(){var field=$('cb-personal-notes'),status=$('cb-notes-saved');field.value=state.notes||'';var timer;field.addEventListener('input',function(){clearTimeout(timer);status.textContent='Saving…';timer=setTimeout(function(){state=api.read();state.notes=field.value;api.write(state);state=api.read();status.textContent='Saved on this device';},350);});}
  function download(name,mime,text){var blob=new Blob([text],{type:mime});var url=URL.createObjectURL(blob);var a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(url);},1200);}
  function bindBackup(){
    $('cb-export-progress').addEventListener('click',function(){state=api.read();var pack={type:'chronicle-of-bharat-study-backup',version:1,exportedAt:new Date().toISOString(),study:state,revision:readRevision()};download('chronicle-study-backup-'+new Date().toISOString().slice(0,10)+'.json','application/json;charset=utf-8',JSON.stringify(pack,null,2));});
    $('cb-import-progress').addEventListener('change',function(e){var file=e.target.files&&e.target.files[0];if(!file)return;var reader=new FileReader();reader.onload=function(){try{var pack=JSON.parse(reader.result);if(!pack||pack.type!=='chronicle-of-bharat-study-backup'||!pack.study)throw new Error('This does not look like a Chronicle study backup.');if(!confirm('Restore this backup? It will replace the local dashboard progress and revision schedule.'))return;api.write(pack.study);if(pack.revision)localStorage.setItem(revisionKey,JSON.stringify(pack.revision));state=api.read();renderTopics();renderStats();bindNotesRefresh();alert('Progress restored.');}catch(err){alert(err.message||'Could not read that backup.');}finally{e.target.value='';}};reader.readAsText(file);});
    $('cb-print-dashboard').addEventListener('click',function(){window.print();});
  }
  function bindNotesRefresh(){var field=$('cb-personal-notes');if(field)field.value=api.read().notes||'';}
  function bindInstall(){var button=$('cb-install-app');function update(){if(window.__chronicleInstallPrompt)button.hidden=false;}window.addEventListener('chronicle:pwa-ready',update);update();button.addEventListener('click',async function(){var prompt=window.__chronicleInstallPrompt;if(!prompt){alert('To save offline, use your browser menu and choose “Install app” or “Add to Home Screen”.');return;}prompt.prompt();await prompt.userChoice;window.__chronicleInstallPrompt=null;button.hidden=true;});}

  renderTopics();renderStats();bindNotes();bindBackup();bindInstall();
  window.addEventListener('chronicle:study-updated',function(){state=api.read();renderStats();});
  window.addEventListener('storage',function(e){if(e.key===api.key){state=api.read();renderTopics();renderStats();}});

})();
