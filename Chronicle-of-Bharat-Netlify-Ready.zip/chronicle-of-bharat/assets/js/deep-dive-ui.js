/* Chronicle of Bharat — shared deep-dive search and glossary layer. */
(function(){
  'use strict';
  var body=document.body, trigger=document.querySelector('.search-trigger'), overlay=document.querySelector('.search-overlay');
  var era=(body&&body.getAttribute('data-era'))||((location.pathname.match(/\/(ancient|medieval|colonial|modern)-india\//)||[])[1])||'overview';
  var portalByEra={ancient:'ancient-india',medieval:'medieval-india',colonial:'colonial-india',modern:'modern-india'};
  var labels={ancient:'Ancient India',medieval:'Medieval India',colonial:'Colonial India',modern:'Post-Independence India'};

  function slugify(s){return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');}
  function item(title,section,snippet,url,keywords){return {title:title,section:section,snippet:snippet,url:url,keywords:keywords||''};}

  var entries=[
    item('Chronicle of Bharat','Overview','Four chronicles of Indian history, with an atlas, shared timeline and revision tools.','../index.html','home overview India history'),
    item('Ancient India','Chronicle','A focused journey from prehistory and the Indus cities to Mauryan and Gupta power.','../ancient.html','ancient'),
    item('Medieval India','Chronicle','Kannauj, the Sultanates, Vijayanagara, the Mughals and Maratha power.','../medieval.html','medieval'),
    item('Colonial India','Chronicle','From Mughal decline and Company rule to resistance, Crown rule and Partition.','../colonial.html','colonial empire company British'),
    item('Post-Independence India','Chronicle','Integration, the republic, planning, food security, nuclear policy and reform.','../modern.html','modern post independence republic'),
    item('All-India timeline','Study tools','A cross-era chronology from the first stone tools to the present.','../timeline.html','timeline chronology'),
    item('All-India atlas','Study tools','Explore historic places across India and toggle the chronology layers.','../map.html','atlas map sites'),
    item('All-India glossary','Study tools','Search definitions for technical terms across all four chronicles.','../glossary.html','glossary definitions'),
    item('All-India flashcards','Study tools','Quick revision cards for key terms from every era.','../flashcards.html','flashcards revision'),
    item('All-India revision notes','Study tools','Condensed printable notes for close reading and exam revision.','../notes.html','notes revision'),
    item('All-India examination hall','Study tools','A scored quiz spanning all four chronicles.','../quiz.html','quiz test'),
    item('Study dashboard','Study tools','Track completed chapters, scores and revision; your study data stays in this browser and no sign-in is needed.','../dashboard.html','dashboard progress'),
    item('Revision room','Study tools','Spaced-repetition review with due cards and custom prompts.','../revision.html','revision spaced repetition'),
    item('Map timeline','Study tools','Follow dated historical events across an interactive India map.','../map-timeline.html','map timeline'),
    item('All-India Dynasty Trees','Study tools','Succession diagrams for major ruling houses and political eras.','../dynasties.html','dynasty trees'),
    item('Ancient India portal','Deep-dive portal','Six chapters, from historiography and prehistory through the Mauryas and Guptas.','../ancient-india/index.html','portal'),
    item('Medieval India portal','Deep-dive portal','Six chapters covering the major medieval political and cultural worlds.','../medieval-india/index.html','portal'),
    item('Colonial India portal','Deep-dive portal','Seven chapter studies plus an era-specific study companion.','../colonial-india/index.html','portal study tools'),
    item('Post-Independence India portal','Deep-dive portal','Seven chapter studies plus an era-specific study companion.','../modern-india/index.html','portal study tools')
  ];

  var chapterData={
    ancient:[
      ['Historiography','Reading the same evidence differently','Schools of interpretation and competing ways to periodise ancient India.','historiography.html'],
      ['Prehistory','Before the cities','Stone tools, early farming and the long human story of the subcontinent.','prehistory.html'],
      ['Indus Valley','The Indus Valley Civilisation','Harappa, urban planning, trade networks and the evidence around decline.','indus-valley.html'],
      ['The Vedic Age','The Vedic Age','From pastoral clans and cattle wealth to settled agriculture and janapadas.','vedic-age.html'],
      ['Keezhadi','Keezhadi and the Vaigai valley','Archaeology, Tamil-Brahmi and the chronology of South Indian urbanism.','keezhadi.html'],
      ['Mauryas to Guptas','Mauryas to Guptas','Imperial statecraft, Ashoka’s Dhamma and classical-age institutions.','mauryas-guptas.html']
    ],
    medieval:[
      ['Tripartite Struggle','The Tripartite Struggle','Pratihara, Pala and Rashtrakuta contest for Kannauj.','tripartite-struggle.html'],
      ['Delhi Sultanate','The Delhi Sultanate','Iqta administration, central power and the Sultanate’s changing dynasties.','delhi-sultanate.html'],
      ['Vijayanagara & the Deccan','Vijayanagara and the Deccan','The Nayankara system, urban centres and the Battle of Talikota.','vijayanagara-deccan.html'],
      ['Bhakti & Sufi','Bhakti, Sufi devotion and society','Devotional traditions, khanqahs and regional cultural exchange.','bhakti-sufi.html'],
      ['Mughal Empire','The Mughal imperial machine','Mansabdari, jagirdari, revenue and the pressures on imperial authority.','mughal-empire.html'],
      ['Maratha Ascendancy','The Maratha Ascendancy','Shivaji, Chauth and a new political order across the Deccan.','maratha-ascendancy.html']
    ],
    colonial:[
      ['Mughal Decline','An empire that ran out of land','The jama–hasil gap, court factionalism and successor states.','mughal-decline.html'],
      ['Company Raj','A trading company becomes a sovereign','Plassey, Buxar, the Diwani and the machinery of Company rule.','company-raj.html'],
      ['The Great Rebellion','The rebellion that ended the Company','The causes, coalitions and consequences of 1857–58.','the-great-rebellion.html'],
      ['Deindustrialisation','Did the British deindustrialise India?','A structured comparison of nationalist, neoclassical and macroeconomic arguments.','deindustrialisation-debate.html'],
      ['Land & Famine','Land revenue and famine','Permanent Settlement, Ryotwari, Mahalwari and entitlement.','land-and-famine.html'],
      ['Resistance & Reform','Resistance, reform and the public sphere','Tribal, peasant and social reform movements across the colonial century.','resistance-and-reform.html'],
      ['Steel Frame & Partition','The Raj’s final architecture','Civil service, constitutional concessions, the Cabinet Mission and 1947.','steel-frame-and-partition.html']
    ],
    modern:[
      ['Princely Integration','Stitching a republic','Accession, diplomacy and the incorporation of princely states.','princely-states.html'],
      ['Planning & Nonalignment','The Nehruvian era','Planning, public institutions and non-alignment in the early republic.','nehruvian-planning.html'],
      ['Green Revolution','The Green Revolution','Food security, high-yield seeds and the uneven ecological cost.','green-revolution.html'],
      ['Pokhran-I','Pokhran-I: Smiling Buddha','The 1974 test, peaceful-use framing and the international response.','pokhran-1974.html'],
      ['Pokhran-II','Pokhran-II and nuclear doctrine','The 1998 tests, deterrence and the stated No First Use doctrine.','pokhran-1998.html'],
      ['The 1991 Reforms','A crisis and a new economic direction','Balance-of-payments pressure, LPG reforms and their long shadow.','reforms-1991.html'],
      ['Caste & Secularism','Caste, secularism and renegotiation','Mandal, representation and India’s distinctive constitutional secularism.','caste-secularism.html']
    ]
  };
  Object.keys(chapterData).forEach(function(key){
    chapterData[key].forEach(function(ch){
      entries.push(item(ch[1],labels[key]+' · Chapter',ch[2],'../'+portalByEra[key]+'/'+ch[3],ch[0]+' '+key));
    });
  });

  var studyTools=[
    ['timeline','Timeline','See the era’s turning points in chronological order.'],
    ['map','Atlas','Place key events and institutions in their geographical context.'],
    ['glossary','Glossary','Definitions for the technical language of the era.'],
    ['flashcards','Flashcards','Review key vocabulary with an active recall deck.'],
    ['quiz','Quiz','Test understanding with questions drawn from the era’s chapters.'],
    ['notes','Revision notes','A concise, print-ready guide to the era’s arguments.'],
    ['dynasties','Dynasty Trees','Track the transfer of authority, institutions and leadership.']
  ];
  Object.keys(portalByEra).forEach(function(key){
    studyTools.forEach(function(tool){
      entries.push(item(tool[1]+' · '+labels[key],labels[key]+' · Study room',tool[2],'../'+portalByEra[key]+'/'+tool[0]+'.html',tool[0]+' '+key));
    });
  });
  (window.GLOSSARY||[]).forEach(function(g){
    var p=portalByEra[g.era]||'glossary.html';
    var url=portalByEra[g.era]?'../'+p+'/glossary.html#term-'+slugify(g.term):'../glossary.html#term-'+slugify(g.term);
    entries.push(item(g.term,'Glossary · '+(labels[g.era]||''),g.def,url,'definition '+g.era));
  });
  // Deep pages search the same overview index as the main site, plus their
  // local chapter/tool/definition entries above. Convert root-relative URLs.
  (window.CHRONICLE_SITE_INDEX||[]).forEach(function(source){
    var entry=Object.assign({},source),url=String(entry.url||'');
    if(url&&!/^(https?:|mailto:|tel:|data:|javascript:|\.\.\/)/i.test(url))entry.url='../'+url;
    entries.push(entry);
  });
  var seenURLs=Object.create(null);
  entries=entries.filter(function(entry){
    var key=entry.url||((entry.title||'')+'|'+(entry.section||''));
    if(seenURLs[key])return false;seenURLs[key]=true;return true;
  });

  function currentPortal(){return portalByEra[era]||'';}
  function rank(entry,q){
    var title=(entry.title||'').toLowerCase(),section=(entry.section||'').toLowerCase();
    var hay=(title+' '+section+' '+(entry.snippet||'')+' '+(entry.keywords||'')).toLowerCase();
    if(!q)return (entry.url.indexOf('../'+currentPortal()+'/')===0?24:0)+(title.length<35?4:0);
    var score=0;
    if(title===q)score+=100;
    else if(title.indexOf(q)===0)score+=55;
    else if(title.indexOf(q)!==-1)score+=40;
    if(section.indexOf(q)!==-1)score+=12;
    if((entry.snippet||'').toLowerCase().indexOf(q)!==-1)score+=8;
    if((entry.keywords||'').toLowerCase().indexOf(q)!==-1)score+=5;
    return hay.indexOf(q)!==-1?score:0;
  }
  function renderSearch(query,active){
    if(!overlay)return;
    var box=overlay.querySelector('.search-results');if(!box)return;
    var q=(query||'').trim().toLowerCase();
    var found=entries.map(function(e){return {entry:e,score:rank(e,q)}}).filter(function(x){return x.score>0;});
    found.sort(function(a,b){return b.score-a.score||a.entry.title.localeCompare(b.entry.title);});
    found=found.slice(0,q?22:9);
    box.textContent='';
    if(!found.length){
      var empty=document.createElement('p');empty.className='search-empty';empty.textContent='No matches for “'+(query||'')+'”. Try a chapter, place, term or study tool.';box.appendChild(empty);return;
    }
    found.forEach(function(result,index){
      var e=result.entry,a=document.createElement('a');a.className='search-result';a.href=e.url;a.setAttribute('role','option');a.setAttribute('aria-selected',index===active?'true':'false');a.dataset.index=String(index);
      var meta=document.createElement('p');meta.className='search-result__meta';meta.textContent=e.section||'Chronicle';
      var title=document.createElement('h3');title.className='search-result__title';title.textContent=e.title;
      var snippet=document.createElement('p');snippet.className='search-result__snippet';snippet.textContent=e.snippet||'';
      a.appendChild(meta);a.appendChild(title);a.appendChild(snippet);box.appendChild(a);
      if(index===active)a.classList.add('is-active');
    });
  }
  if(trigger&&overlay){
    var input=overlay.querySelector('input'),close=overlay.querySelector('.search-close'),results=overlay.querySelector('.search-results'),lastFocus=null,active=-1;
    function open(){lastFocus=document.activeElement;overlay.classList.add('is-open');overlay.setAttribute('aria-hidden','false');body&&body.classList.add('search-open');active=-1;renderSearch('',active);window.setTimeout(function(){if(input)input.focus();},50);}
    function shut(){overlay.classList.remove('is-open');overlay.setAttribute('aria-hidden','true');body&&body.classList.remove('search-open');if(input)input.value='';active=-1;if(lastFocus&&lastFocus.focus)lastFocus.focus();else trigger.focus();}
    function move(delta){var links=results?Array.prototype.slice.call(results.querySelectorAll('.search-result')):[];if(!links.length)return;active=(active+delta+links.length)%links.length;renderSearch(input.value,active);var current=results.querySelector('[data-index="'+active+'"]');if(current){current.scrollIntoView({block:'nearest'});input.setAttribute('aria-activedescendant','search-result-'+active);current.id='search-result-'+active;}}
    trigger.addEventListener('click',open);
    if(close)close.addEventListener('click',shut);
    if(input){
      input.addEventListener('input',function(){active=-1;input.removeAttribute('aria-activedescendant');renderSearch(input.value,active);});
      input.addEventListener('keydown',function(e){if(e.key==='ArrowDown'){e.preventDefault();move(1);}else if(e.key==='ArrowUp'){e.preventDefault();move(-1);}else if(e.key==='Enter'&&active>=0){var a=results.querySelector('[data-index="'+active+'"]');if(a)a.click();}});
    }
    overlay.addEventListener('click',function(e){if(e.target===overlay)shut();});
    document.addEventListener('keydown',function(e){
      var target=e.target,tag=target&&target.tagName;
      if((e.key==='/'||((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'))&&tag!=='INPUT'&&tag!=='TEXTAREA'&&tag!=='SELECT'&&!(target&&target.isContentEditable)&&!overlay.classList.contains('is-open')){e.preventDefault();open();}
      else if(e.key==='Escape'&&overlay.classList.contains('is-open')){e.preventDefault();shut();}
    });
  }

  // Underline the first mention of each glossary term in editorial prose,
  // with a keyboard-accessible definition tooltip. Navigation links are skipped;
  // chapter-card copy is allowed so portal summaries receive the same treatment.
  function applyGlossary(){
    var glossary=window.GLOSSARY||[];if(!glossary.length)return;
    var selectors='.entry p,.entry li,.method p,.hero .lede,.era-band .lede,.section > .wrap > p,.section-head p,.chapter-card p,.portal-tool-shelf p,.study-section-head__aside,.study-event__body,.note-card p,.note-card li,.power-step p,.atlas-detail p';
    var containers=Array.prototype.slice.call(document.querySelectorAll(selectors));
    if(!containers.length)return;
    var nodes=[];
    containers.forEach(function(container){
      var walker=document.createTreeWalker(container,NodeFilter.SHOW_TEXT,{
        acceptNode:function(node){
          if(!node.nodeValue||!node.nodeValue.trim())return NodeFilter.FILTER_REJECT;
          var p=node.parentElement;if(!p||p.closest('button,code,pre,input,textarea,select,.gloss-term,[data-no-glossary],.search-overlay,.term-card,.study-quiz-card,.study-flashcard')||p.closest('a:not(.chapter-card)'))return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      });
      var node;while((node=walker.nextNode()))nodes.push(node);
    });
    glossary.slice().sort(function(a,b){return b.term.length-a.term.length;}).forEach(function(g){
      var escaped=String(g.term).replace(/[-/\\^$*+?.()|[\]{}]/g,'\\$&'),regex=new RegExp('\\b('+escaped+')\\b','i');
      for(var i=0;i<nodes.length;i++){
        var node=nodes[i];if(!node.parentNode||node.parentElement.closest('.gloss-term'))continue;
        var match=regex.exec(node.nodeValue);if(!match)continue;
        var range=document.createRange();range.setStart(node,match.index);range.setEnd(node,match.index+match[0].length);
        var span=document.createElement('span');span.className='gloss-term';span.tabIndex=0;span.setAttribute('role','term');span.setAttribute('data-def',g.def);span.setAttribute('title',g.def);span.setAttribute('aria-label',g.term+': '+g.def);
        range.surroundContents(span);break;
      }
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',applyGlossary,{once:true});else applyGlossary();
})();
