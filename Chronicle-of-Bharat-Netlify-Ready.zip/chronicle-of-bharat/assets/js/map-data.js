// Real-world coordinates (lat, lon). Positions are projected onto the map
// at render time with window.projectLonLat(). Sites in present-day Pakistan
// (Harappa, Mohenjo-daro, Taxila) are plotted at their true location beyond
// today's border — the Indus civilisation and Gandhara predate that border
// by millennia, and historical atlases conventionally show them this way.
window.MAP_SITES = [
  // ---- Ancient ----
  { name:"Harappa", lat:30.633, lon:72.868, era:"ancient", blurb:"Type-site of the Indus Valley Civilisation — granaries and working platforms on the Ravi." },
  { name:"Mohenjo-daro", lat:27.325, lon:68.138, era:"ancient", blurb:"The Great Bath and a grid-planned citadel on the Indus, Sindh." },
  { name:"Dholavira", lat:23.888, lon:70.212, era:"ancient", blurb:"Rock-cut water reservoirs engineered to harvest flash floods, Rann of Kutch." },
  { name:"Lothal", lat:22.527, lon:72.249, era:"ancient", blurb:"An artificial tidal dockyard — Harappan maritime trade infrastructure." },
  { name:"Rakhigarhi", lat:29.290, lon:76.113, era:"ancient", blurb:"Largest known Harappan site; ancient-DNA sample I4411 recovered here." },
  { name:"Kalibangan", lat:29.470, lon:74.133, era:"ancient", blurb:"Ploughed-field impressions and fire altars, Ghaggar-Hakra basin." },
  { name:"Taxila", lat:33.744, lon:72.786, era:"ancient", blurb:"Gandhara's monarchy and trans-regional centre of trade and learning." },
  { name:"Pataliputra (Patna)", lat:25.594, lon:85.137, era:"ancient", blurb:"Magadha's capital — seat of the Nandas, Mauryas, and Guptas." },
  { name:"Vaishali", lat:25.980, lon:85.130, era:"ancient", blurb:"Capital of the Vajji confederate republic (gana-sangha)." },
  { name:"Ujjain", lat:23.179, lon:75.785, era:"ancient", blurb:"Avanti's capital, a major western trade-route hub." },
  { name:"Keezhadi", lat:9.860, lon:78.190, era:"ancient", blurb:"Vaigai valley site redating South Indian urbanisation to c. 580 BCE." },

  // ---- Medieval ----
  { name:"Kannauj", lat:27.054, lon:79.915, era:"medieval", blurb:"Symbolic prize of the Tripartite Struggle between Pratihara, Pala and Rashtrakuta." },
  { name:"Delhi", lat:28.614, lon:77.209, era:"medieval", blurb:"Seat of five Sultanate dynasties, 1206–1526, and later the Mughals." },
  { name:"Agra", lat:27.177, lon:78.008, era:"medieval", blurb:"Mughal capital under Akbar and Shah Jahan; site of the Taj Mahal." },
  { name:"Fatehpur Sikri", lat:27.094, lon:77.663, era:"medieval", blurb:"Akbar's planned capital, built and largely abandoned within decades." },
  { name:"Hampi", lat:15.335, lon:76.460, era:"medieval", blurb:"Capital of the Vijayanagara Empire, destroyed after the Battle of Talikota (1565)." },
  { name:"Thanjavur", lat:10.787, lon:79.137, era:"medieval", blurb:"Chola capital; the naval empire's Dravidian temple heartland." },
  { name:"Manyakheta", lat:17.190, lon:77.200, era:"medieval", blurb:"Rashtrakuta capital, patrons of the rock-cut Kailash Temple at Ellora." },
  { name:"Bijapur", lat:16.826, lon:75.713, era:"medieval", blurb:"One of the five Deccan Sultanates formed after the Bahmani split." },
  { name:"Golconda", lat:17.383, lon:78.402, era:"medieval", blurb:"Qutb Shahi Deccan Sultanate, near present-day Hyderabad." },
  { name:"Ajmer", lat:26.450, lon:74.640, era:"medieval", blurb:"Seat of Khwaja Moinuddin Chishti's Sufi order." },

  // ---- Colonial ----
  { name:"Plassey", lat:23.790, lon:88.257, era:"colonial", blurb:"Robert Clive's political manoeuvring wins Bengal, 1757 — the EIC's first great territorial prize." },
  { name:"Buxar", lat:25.594, lon:83.982, era:"colonial", blurb:"The EIC defeats a combined Mughal-Awadh-Bengal force outright, 1764." },
  { name:"Kolkata", lat:22.573, lon:88.364, era:"colonial", blurb:"Company, then Crown, capital — seat of the Governor-General until 1911." },
  { name:"Meerut", lat:28.985, lon:77.706, era:"colonial", blurb:"Sepoy mutiny begins here, 10 May 1857, igniting the Great Rebellion." },
  { name:"Jhansi", lat:25.448, lon:78.569, era:"colonial", blurb:"Rani Lakshmibai's resistance to the Doctrine of Lapse and the 1857 Rebellion." },
  { name:"Rajmahal Hills", lat:24.933, lon:87.750, era:"colonial", blurb:"The Santhal Rebellion (Hul), 1855\u201356, against dikus and land dispossession." },
  { name:"Ranchi", lat:23.344, lon:85.310, era:"colonial", blurb:"Birsa Munda's Ulgulan, 1899\u20131900, defending Khuntkatti tribal land rights." },
  { name:"Nadia (Bengal)", lat:23.401, lon:88.512, era:"colonial", blurb:"The Indigo Revolt, 1859\u201360, against coercive planter contracts." },
  { name:"Pune", lat:18.520, lon:73.857, era:"colonial", blurb:"The Deccan Riots, 1875, against Ryotwari tax burdens and moneylender debt." },

  // ---- Modern ----
  { name:"Delhi", lat:28.614, lon:77.209, era:"modern", blurb:"Capital of the Republic since 1950." },
  { name:"Hyderabad", lat:17.385, lon:78.486, era:"modern", blurb:"Integrated into the Union after Operation Polo, September 1948." },
  { name:"Pokhran", lat:26.916, lon:71.922, era:"modern", blurb:"Site of both nuclear tests — Smiling Buddha (1974) and Pokhran-II (1998)." },
  { name:"Ludhiana (Punjab belt)", lat:30.901, lon:75.857, era:"modern", blurb:"Epicentre of Green Revolution HYV adoption and irrigation intensity." },
  { name:"Mumbai", lat:19.076, lon:72.877, era:"modern", blurb:"Financial capital; gateway for post-1991 FDI and trade integration." },
  { name:"Bengaluru", lat:12.972, lon:77.595, era:"modern", blurb:"Emerged as a primary global services and technology hub after 1991." },
  // ---------- THEMATIC STUDIES ----------
  { name:"Ahar", lat:24.580, lon:73.700, era:"ancient", blurb:"Ahar-Banas settlement zone; distinctive Chalcolithic pottery and copper-working traditions." },
  { name:"Muziris / Pattanam region", lat:10.160, lon:76.210, era:"ancient", blurb:"Malabar coast port zone associated with long-distance Indian Ocean trade; exact identification is discussed." },
  { name:"Bharuch (Barygaza)", lat:21.705, lon:72.995, era:"ancient", blurb:"Western Indian port linked to inland routes and Red Sea–Arabian Sea exchange." },
  { name:"Arikamedu", lat:11.910, lon:79.810, era:"ancient", blurb:"An archaeological site near Puducherry with evidence for coastal exchange in the early historic period." },
  { name:"Nalanda", lat:25.136, lon:85.443, era:"ancient", blurb:"A major monastic and learning centre connected to regional and transregional scholarly networks." },
  { name:"Calicut (Kozhikode)", lat:11.259, lon:75.780, era:"medieval", blurb:"A major Malabar port whose merchant and political networks connected the Indian Ocean." },
  { name:"Cambay (Khambhat)", lat:22.317, lon:72.620, era:"medieval", blurb:"Gujarat port and trading centre linked to inland markets and western Indian Ocean routes." },
  { name:"Zawar", lat:24.346, lon:73.687, era:"medieval", blurb:"Rajasthan mining landscape associated with historical lead and zinc production." },
  { name:"Khejarli", lat:26.046, lon:73.087, era:"colonial", blurb:"Bishnoi tradition remembers the 1730 defence of khejri trees at this Marwar village." },
  { name:"Mangarh Hill", lat:23.660, lon:74.020, era:"colonial", blurb:"Site of Govind Guru’s Bhil-led mobilisation and the 1913 attack; casualty estimates vary." },
  { name:"Bijolia", lat:25.147, lon:75.341, era:"colonial", blurb:"Mewar centre of a long peasant campaign against taxes and compulsory labour." },
  { name:"Champaran", lat:26.650, lon:84.900, era:"colonial", blurb:"Indigo cultivators’ 1917 campaign and a major episode in local and national politics." },
  { name:"Kheda", lat:22.750, lon:72.680, era:"colonial", blurb:"Site of the 1918 peasant campaign for revenue relief after crop failure." },
  { name:"Sri Ganganagar", lat:29.920, lon:73.880, era:"colonial", blurb:"Gang Canal irrigation reshaped Bikaner’s north-west frontier, settlement and agriculture." },
  { name:"Chennai (Madras)", lat:13.083, lon:80.270, era:"colonial", blurb:"A colonial port and administrative centre whose growth drew on coastal and inland networks." },
  { name:"Kolkata (Calcutta)", lat:22.573, lon:88.364, era:"colonial", blurb:"Company and Crown port city shaped by imperial administration, labour, migration and industry." },
];
