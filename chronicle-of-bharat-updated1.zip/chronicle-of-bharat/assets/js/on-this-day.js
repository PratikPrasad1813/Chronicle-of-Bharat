// Chronicle of Bharat — "On this day" widget (v2, polished UI)
// Renders into <section id="on-this-day"></section>. Uses the site's own
// [data-era] cascade for colour, and its .chip / .eyebrow / .reveal
// components so the widget reads as native to the redesign rather than
// bolted on. Every calendar day (including 29 Feb) has an entry; on
// non-leap years 29 Feb falls back to 28 Feb rather than showing nothing.
(function(){
  "use strict";
  var MONTH_NAMES = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  var ERA_LABEL = { ancient:"Ancient India", medieval:"Medieval India", colonial:"Colonial India", modern:"Post-Independence" };

  function eraHref(era){
    var inPortal = /\/ancient-india\//.test(location.pathname);
    if(inPortal) return era === "ancient" ? "index.html" : "../" + era + ".html";
    return era + ".html";
  }
  function findEvent(events, m, d){
    for(var i=0;i<events.length;i++){
      if(events[i].month === m && events[i].day === d) return events[i];
    }
    return null;
  }

  function init(){
    var el = document.getElementById("on-this-day");
    if(!el || !window.ON_THIS_DAY || !window.ON_THIS_DAY.length) return;

    var now = new Date();
    var todayKey = now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate();
    try{
      if(localStorage.getItem("chronicle-otd-dismissed") === todayKey){ el.style.display = "none"; return; }
    }catch(e){}

    var m = now.getMonth() + 1, d = now.getDate();
    var ev = findEvent(window.ON_THIS_DAY, m, d) || findEvent(window.ON_THIS_DAY, 2, 28);
    if(!ev) return;

    el.setAttribute("data-era", ev.era);
    var dateLabel = ev.day + " " + MONTH_NAMES[ev.month - 1];

    el.innerHTML =
      '<span class="otd__icon" aria-hidden="true">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/><circle cx="12" cy="14.6" r="2"/></svg>' +
      '</span>' +
      '<span class="otd__main">' +
        '<span class="otd__top">' +
          '<span class="eyebrow otd__eyebrow">On this day \u00b7 ' + dateLabel + '</span>' +
          '<span class="chip otd__chip">' + ERA_LABEL[ev.era] + '</span>' +
        '</span>' +
        '<strong class="otd__title">' + ev.title + '<span class="otd__year">' + ev.year + '</span></strong>' +
        '<p class="otd__desc">' + ev.body + '</p>' +
        '<a class="otd__link" href="' + eraHref(ev.era) + '">Read the chronicle <span aria-hidden="true">\u2192</span></a>' +
      '</span>' +
      '<button class="otd__close" type="button" aria-label="Dismiss for today">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6L6 18"/></svg>' +
      '</button>';

    var closeBtn = el.querySelector(".otd__close");
    if(closeBtn){
      closeBtn.addEventListener("click", function(){
        el.classList.add("is-dismissing");
        setTimeout(function(){ el.style.display = "none"; }, 220);
        try{ localStorage.setItem("chronicle-otd-dismissed", todayKey); }catch(e){}
      });
    }
  }

  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
