(function(){
  'use strict';
  var storageKey='chronicle-revision-v1',terms=(window.GLOSSARY||[]).map(function(t){return {id:'g-'+slug(t.term+'-'+t.era),term:t.term,def:t.def,era:t.era,custom:false};}),custom=[],queue=[],current=null,answerShown=false,reviewedThisRun=0;
  var $=function(id){return document.getElementById(id);};
  function slug(s){return String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');}
  function load(){try{var x=JSON.parse(localStorage.getItem(storageKey)||'null');var out=x&&typeof x==='object'?Object.assign({cards:{},custom:[],deletedCustom:[],reviewStats:{total:0}},x):{cards:{},custom:[],deletedCustom:[],reviewStats:{total:0}};if(!out.cards||typeof out.cards!=='object')out.cards={};if(!Array.isArray(out.custom))out.custom=[];if(!Array.isArray(out.deletedCustom))out.deletedCustom=[];return out;}catch(e){return {cards:{},custom:[],deletedCustom:[],reviewStats:{total:0}};}}
  var data=load(),deletedCustomIds=Object.create(null);data.deletedCustom.forEach(function(id){deletedCustomIds[id]=true;});custom=Array.isArray(data.custom)?data.custom.filter(function(c){return c&&!deletedCustomIds[c.id];}):[];
  custom.forEach(function(c){terms.push({id:c.id,term:c.term,def:c.def,era:c.era||'ancient',custom:true});});
  function save(){data.cards=data.cards||{};data.custom=custom.filter(function(c){return c.custom;}).map(function(c){return {id:c.id,term:c.term,def:c.def,era:c.era,custom:true};});data.deletedCustom=Array.from(new Set((data.deletedCustom||[]).filter(Boolean)));data.updatedAt=Date.now();try{localStorage.setItem(storageKey,JSON.stringify(data));}catch(e){};try{window.dispatchEvent(new CustomEvent('chronicle:study-updated',{detail:{revision:data}}));}catch(e){};updateSummary();}
  function record(card){return data.cards[card.id]||{due:0,reps:0,interval:0,ease:2.5,last:0};}
  function isDue(card){var r=record(card);return !r.due||Number(r.due)<=Date.now();}
  function updateSummary(){
    var due=terms.filter(isDue),counts={ancient:0,medieval:0,colonial:0,modern:0};due.forEach(function(c){counts[c.era]=(counts[c.era]||0)+1;});
    $('cb-revision-session-count').textContent=due.length+' cards currently due · '+terms.length+' cards in your deck';
    var box=$('cb-revision-summary');box.textContent='';[['Due now',due.length],['Reviewed ever',Number(data.reviewStats&&data.reviewStats.total)||0],['Ancient',counts.ancient],['Medieval',counts.medieval],['Colonial',counts.colonial],['Republic',counts.modern]].forEach(function(x){var span=document.createElement('span');span.className='cb-chip';span.textContent=x[0]+': '+x[1];box.appendChild(span);});
  }
  function eraName(era){return ({ancient:'Ancient',medieval:'Medieval',colonial:'Colonial',modern:'Post-Independence'})[era]||era;}
  function showButton(id,show){$(id).hidden=!show;}
  function setStatus(text){$('cb-revision-feedback').textContent=text||'';}
  function renderCard(preserveFeedback){
    $('cb-revision-answer').hidden=true;answerShown=false;showButton('cb-revision-reveal',!!current);document.querySelectorAll('[data-grade]').forEach(function(b){b.hidden=true;});
    if(!current){
      $('cb-revision-term').textContent=reviewedThisRun?'Session complete — well done.':'Choose a session to begin';
      $('cb-revision-answer').textContent=reviewedThisRun?('You reviewed '+reviewedThisRun+' card'+(reviewedThisRun===1?'':'s')+'. Feedback below confirms the next review interval.'):'Select an era and start with due cards, or turn off “Due cards only” to practise the full deck.';
      $('cb-revision-answer').hidden=false;$('cb-revision-status').textContent=reviewedThisRun?'REVIEW COMPLETE':'SPACED REVISION';$('cb-revision-card-era').textContent='';if(!preserveFeedback)setStatus('');return;
    }
    $('cb-revision-status').textContent='CARD '+(reviewedThisRun+1)+' · '+(queue.length+1)+' LEFT';$('cb-revision-term').textContent=current.term;$('cb-revision-card-era').textContent=eraName(current.era)+(current.custom?' · Your card':'');$('cb-revision-answer').textContent=current.def;
    var dueDate=record(current).due;if(!preserveFeedback)setStatus(dueDate&&dueDate>Date.now()?'Previously scheduled for '+new Date(dueDate).toLocaleString():'New or due now.');
  }
  function startSession(){
    var era=$('cb-revision-era').value,dueOnly=$('cb-revision-due-only').checked,length=$('cb-revision-length').value;
    var pool=terms.filter(function(c){return (era==='all'||c.era===era)&&(!dueOnly||isDue(c));});
    for(var i=pool.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),t=pool[i];pool[i]=pool[j];pool[j]=t;}
    if(length!=='all')pool=pool.slice(0,Number(length));
    queue=pool.slice();reviewedThisRun=0;current=queue.shift()||null;
    if(!pool.length)setStatus('No cards match. Change the era filter or turn off “Due cards only”.');else setStatus('');
    renderCard(!pool.length);
  }
  function reveal(){if(!current)return;answerShown=true;$('cb-revision-answer').hidden=false;showButton('cb-revision-reveal',false);document.querySelectorAll('[data-grade]').forEach(function(b){b.hidden=false;});}
  function grade(kind){
    if(!current||!answerShown)return;
    var r=record(current),day=86400000,now=Date.now();
    if(kind==='again'){r.reps=0;r.interval=0;r.due=now+10*60*1000;r.ease=Math.max(1.3,(Number(r.ease)||2.5)-.2);}
    else if(kind==='hard'){r.reps=(Number(r.reps)||0)+1;r.interval=Math.max(1,Number(r.interval)||0,Math.round((Number(r.interval)||0)*1.2));r.due=now+r.interval*day;r.ease=Math.max(1.3,(Number(r.ease)||2.5)-.15);}
    else{r.reps=(Number(r.reps)||0)+1;var ladder=[1,3,7,14,30,60];var base=ladder[Math.min(r.reps-1,ladder.length-1)];r.interval=Math.max(base,Math.round((Number(r.interval)||0)*(Number(r.ease)||2.5)));r.due=now+r.interval*day;r.ease=Math.min(3.1,(Number(r.ease)||2.5)+.05);}
    r.last=now;r.lastGrade=kind;data.cards[current.id]=r;data.reviewStats=data.reviewStats||{total:0};data.reviewStats.total=(Number(data.reviewStats.total)||0)+1;data.reviewStats.lastAt=now;reviewedThisRun++;
    save();setStatus(kind==='again'?'Scheduled again in about 10 minutes.':'Scheduled for '+r.interval+' day'+(r.interval===1?'':'s')+'.');
    current=queue.shift()||null;renderCard(true);
  }
  function renderCustom(){var root=$('cb-custom-list');root.textContent='';if(!custom.length){var p=document.createElement('p');p.className='cb-map-note';p.textContent='No custom cards yet.';root.appendChild(p);return;}custom.forEach(function(c){var row=document.createElement('div');row.className='cb-topic';var label=document.createElement('div');var strong=document.createElement('strong');strong.textContent=c.term;var small=document.createElement('small');small.textContent=eraName(c.era)+' · '+c.def;label.appendChild(strong);label.appendChild(small);var del=document.createElement('button');del.className='cb-btn';del.type='button';del.textContent='Remove';del.addEventListener('click',function(){custom=custom.filter(function(x){return x.id!==c.id;});terms=terms.filter(function(x){return x.id!==c.id;});delete data.cards[c.id];data.deletedCustom=(data.deletedCustom||[]).concat(c.id);save();renderCustom();});row.appendChild(label);row.appendChild(del);root.appendChild(row);});}
  $('cb-custom-card-form').addEventListener('submit',function(e){e.preventDefault();var term=$('cb-custom-term').value.trim(),def=$('cb-custom-answer').value.trim(),era=$('cb-custom-era').value;if(!term||!def)return;var item={id:'c-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,6),term:term,def:def,era:era,custom:true};custom.push(item);terms.push(item);data.deletedCustom=(data.deletedCustom||[]).filter(function(id){return id!==item.id;});data.cards[item.id]={due:0,reps:0,interval:0,ease:2.5,last:0};save();renderCustom();e.target.reset();});
  $('cb-revision-start').addEventListener('click',startSession);$('cb-revision-reveal').addEventListener('click',reveal);document.querySelectorAll('[data-grade]').forEach(function(b){b.addEventListener('click',function(){grade(b.getAttribute('data-grade'));});});
  $('cb-revision-era').addEventListener('change',updateSummary);$('cb-revision-due-only').addEventListener('change',updateSummary);
  function markdown(){var lines=['# Chronicle of Bharat — Revision Pack','',new Date().toLocaleDateString(),''];var list=terms.filter(function(c){return $('cb-revision-era').value==='all'||c.era===$('cb-revision-era').value;});list.forEach(function(c){lines.push('## '+c.term+' — '+eraName(c.era),'',c.def,'');});return lines.join('\n');}
  $('cb-download-revision').addEventListener('click',function(){var blob=new Blob([markdown()],{type:'text/markdown;charset=utf-8'});var url=URL.createObjectURL(blob);var a=document.createElement('a');a.href=url;a.download='chronicle-revision-pack.md';document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(url);},1200);});
  $('cb-export-cards').addEventListener('click',function(){var pack={type:'chronicle-revision-backup',version:1,exportedAt:new Date().toISOString(),revision:data};var url=URL.createObjectURL(new Blob([JSON.stringify(pack,null,2)],{type:'application/json'}));var a=document.createElement('a');a.href=url;a.download='chronicle-revision-cards.json';document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(url);},1200);});
  $('cb-print-revision').addEventListener('click',function(){var sheet=$('cb-print-sheet');sheet.textContent='';var title=document.createElement('h1');title.textContent='Chronicle of Bharat — Revision Sheet';sheet.appendChild(title);terms.filter(function(c){return $('cb-revision-era').value==='all'||c.era===$('cb-revision-era').value;}).forEach(function(c){var article=document.createElement('article');var h=document.createElement('h2');h.textContent=c.term+' · '+eraName(c.era);var p=document.createElement('p');p.textContent=c.def;article.appendChild(h);article.appendChild(p);sheet.appendChild(article);});window.print();});
  updateSummary();renderCard();renderCustom();
})();
