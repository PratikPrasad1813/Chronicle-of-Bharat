(function(){
  "use strict";
  var sites = window.MAP_SITES || [];
  var layer = document.getElementById("map-markers");
  var panel = document.getElementById("map-panel");
  var toggles = document.querySelectorAll(".map-toggle");
  var activeEras = { ancient:true, medieval:true, colonial:true, modern:true };
  var geo = window.INDIA_GEO ? window.INDIA_GEO.proj : { VBW:520, VBH:584 };
  var VIEW_W = geo.VBW, VIEW_H = geo.VBH;

  function eraLabel(era){ return era === "ancient" ? "Ancient" : era === "medieval" ? "Medieval" : era === "colonial" ? "Colonial" : "Modern"; }

  function showPanel(site){
    panel.innerHTML =
      '<p class="eyebrow map-panel__era map-panel__era--' + site.era + '">' + eraLabel(site.era) + '</p>' +
      '<h3>' + site.name + '</h3>' +
      '<p class="small">' + site.blurb + '</p>';
    panel.classList.add("is-active");
  }

  function render(){
    layer.innerHTML = "";
    sites.forEach(function(site, i){
      if(!activeEras[site.era]) return;
      var pt = window.projectLonLat ? window.projectLonLat(site.lon, site.lat) : { x:0, y:0 };
      var btn = document.createElement("button");
      btn.className = "map-pin map-pin--" + site.era;
      btn.style.left = (pt.x / VIEW_W * 100) + "%";
      btn.style.top = (pt.y / VIEW_H * 100) + "%";
      btn.setAttribute("aria-label", site.name + " — " + eraLabel(site.era));
      btn.innerHTML = '<span class="map-pin__dot"></span><span class="map-pin__tag">' + site.name + '</span>';
      btn.addEventListener("click", function(){ showPanel(site); });
      layer.appendChild(btn);
    });
  }

  toggles.forEach(function(t){
    t.addEventListener("change", function(){
      activeEras[t.value] = t.checked;
      render();
    });
  });

  render();
})();
