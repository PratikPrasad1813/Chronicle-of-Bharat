#!/usr/bin/env python3
"""Add thematic module study data to the shared tools and legacy root tool pages.
Idempotent: each insertion is guarded by a marker comment."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

GLOSSARY=r'''  // ---------- THEMATIC STUDIES ----------
  { term:"Ahar-Banas culture", era:"ancient", def:"A modern archaeological label for Chalcolithic communities in south-eastern Rajasthan, associated with distinctive pottery, copper working, farming and exchange." },
  { term:"Kalibangan", era:"ancient", def:"A Harappan settlement in present-day Hanumangarh district, with earlier settlement levels, planned streets, furrow impressions and installations whose functions are debated." },
  { term:"Ghaggar-Hakra", era:"ancient", def:"A river system and palaeochannel zone in the north-west, important to settlement histories but not a single unchanging river course." },
  { term:"Monsoon winds", era:"ancient", def:"Seasonally changing winds that helped make Indian Ocean voyages more predictable when navigators timed routes to local conditions." },
  { term:"Muziris", era:"ancient", def:"A major ancient port on the Malabar coast, commonly associated with Indo-Roman exchange; its precise location and archaeological identification are discussed." },
  { term:"Barygaza", era:"ancient", def:"The name used in the Periplus of the Erythraean Sea for Bharuch, a western Indian port connected to inland trade routes." },
  { term:"Gurjara-Pratihara", era:"medieval", def:"A major early-medieval north Indian power, one of the three dynasties involved in the long contest for Kannauj." },
  { term:"Chishti dargah", era:"medieval", def:"A shrine associated with a Chishti Sufi lineage; Ajmer’s shrine became an important destination for devotion, patronage and pilgrimage." },
  { term:"Ayyavole", era:"medieval", def:"A name associated with long-distance South Indian merchant-guild networks, active in trade and inscriptional records across regions." },
  { term:"Srivijaya", era:"medieval", def:"A maritime polity centred in Southeast Asia that participated in Indian Ocean and straits trade; its societies were not merely extensions of Indian influence." },
  { term:"Cartaz", era:"colonial", def:"A Portuguese maritime pass system used to regulate and tax some shipping in the Indian Ocean; its reach was contested and uneven." },
  { term:"Rajputana Agency", era:"colonial", def:"A British political-administrative grouping for princely states and territories in the region later incorporated into Rajasthan; it did not describe one ancient polity." },
  { term:"Praja Mandal", era:"colonial", def:"A political association in a princely state that sought civil rights, representative institutions or responsible government; programmes varied by state." },
  { term:"Begar", era:"colonial", def:"Compulsory unpaid labour demanded by authorities or local elites, resisted in several princely-state and agrarian movements." },
  { term:"Gang Canal", era:"colonial", def:"An irrigation system sponsored by Bikaner ruler Ganga Singh and brought into use in 1927, helping transform the north-western settlement and farming frontier." },
  { term:"Santhal Hul", era:"colonial", def:"The Santhal uprising of 1855–56 against exploitative revenue arrangements, moneylending and encroaching political authority." },
  { term:"Ulgulan", era:"colonial", def:"The ‘great tumult’ associated with Birsa Munda’s late-nineteenth-century movement for land, community authority and religious renewal." },
  { term:"Tebhaga", era:"colonial", def:"A late-colonial sharecropper movement in Bengal demanding a larger share of the harvest and greater control over threshing." },
  { term:"Khejarli", era:"colonial", def:"A 1730 event remembered in Bishnoi tradition for the defence of khejri trees by Amrita Devi and other community members." },
  { term:"Mangarh mobilisation", era:"colonial", def:"A Bhil-led social and political mobilisation associated with Govind Guru and the 1913 attack on a gathering at Mangarh; casualty estimates vary." },
  { term:"Adivasi", era:"colonial", def:"A broad political and social term used by many Indigenous communities in India; it does not name one uniform culture or history." },
  { term:"Constituent Assembly", era:"modern", def:"The representative body that debated and adopted the Constitution of India, drawing on the work of committees, advisers and members with varied viewpoints." },
  { term:"Union of States", era:"modern", def:"The phrase in Article 1 of the Constitution of India describing the country’s constitutional union of states." },
  { term:"Seventh Schedule", era:"modern", def:"The constitutional schedule allocating legislative subjects among the Union, State and Concurrent Lists." },
  { term:"Concurrent List", era:"modern", def:"A constitutional list of subjects on which both Parliament and state legislatures may legislate, subject to constitutional rules on conflicts." },
  { term:"States Reorganisation Act", era:"modern", def:"The 1956 law that reorganised much of India’s internal state map, substantially using language while also reflecting administrative and political considerations." },
  { term:"Matsya Union", era:"modern", def:"A short-lived union formed in 1948 from former princely states in eastern Rajputana and merged into the larger Rajasthan union in 1949." },
  { term:"GST Council", era:"modern", def:"A constitutional intergovernmental body created for recommendations and coordination within India’s Goods and Services Tax framework." },
  { term:"Panchayati Raj", era:"modern", def:"A system of rural local self-government; the 73rd Constitutional Amendment created a constitutional framework for panchayats." },
  { term:"Chipko movement", era:"modern", def:"A set of locally varied Himalayan forest campaigns from the 1970s onward, involving village organisers and making forest access and commercial felling public issues." },
  { term:"Environmental history", era:"modern", def:"An approach that studies how people, institutions and ecological processes shaped one another across time." },
  { term:"Canal colony", era:"modern", def:"A planned settlement and farming area created around irrigation infrastructure, often involving migration, land allocation and new patterns of labour." },
'''

QUIZ=r'''  // ---------- THEMATIC STUDIES ----------
  { era:"ancient", q:"What can the furrow impressions at Kalibangan most securely tell historians?", options:["They prove one fixed crop and ownership system","They provide evidence of ploughing, while the wider social meaning remains open","They show that the site was a Vedic capital","They prove that the Ghaggar-Hakra never changed course"], correct:1, explain:"Furrow impressions are important evidence of agricultural practice, but they do not by themselves identify crops, ownership or a permanent river course." },
  { era:"ancient", q:"Why is Lothal’s large basin sometimes described cautiously?", options:["No Harappan objects have been found there","Its exact function as a dock or reservoir is debated, even though wider maritime exchange is well supported","It lies in the Himalayan foothills","It was built by the Cholas"], correct:1, explain:"The basin’s function is debated; historians distinguish that question from the broader evidence for Harappan exchange and coastal contact." },
  { era:"ancient", q:"Which best describes the Ahar-Banas archaeological tradition?", options:["A single empire centred on Delhi","Chalcolithic communities in south-eastern Rajasthan with farming, copper working and distinctive pottery","A medieval maritime guild","A colonial irrigation district"], correct:1, explain:"Ahar-Banas is a modern archaeological label for varied communities and sites in the Banas basin, not the name of a single ancient state." },
  { era:"ancient", q:"Which scholar is especially associated with seventh-century arithmetic rules involving zero?", options:["Brahmagupta","Kautilya","Kalidasa","Megasthenes"], correct:0, explain:"Brahmagupta’s work includes rules for arithmetic involving zero and negative quantities; the history of place-value notation developed over time." },
  { era:"medieval", q:"What is the safest summary of Rajendra Chola I’s 1025 expedition?", options:["It created a permanent Chola empire across Southeast Asia","It attacked centres associated with Srivijaya but did not establish lasting territorial rule there","It ended all Indian Ocean trade","It occurred before Chola naval activity"], correct:1, explain:"The campaign demonstrated long-distance military reach, but it did not create a durable Chola territorial administration across Southeast Asia." },
  { era:"medieval", q:"Why were monsoon winds important to Indian Ocean sailing?", options:["They made every voyage risk-free","Their seasonal patterns helped navigators plan crossings, alongside local knowledge and port networks","They eliminated the need for ships and pilots","They only affected trade after steam power"], correct:1, explain:"Seasonal winds made routes more predictable, but voyages still depended on skill, timing, ships, supplies and political conditions." },
  { era:"medieval", q:"Which statement best describes the Gurjara-Pratiharas?", options:["A major early-medieval north Indian power involved in the contest for Kannauj","A modern political party","A port city in Kerala","A colonial forest law"], correct:0, explain:"The Gurjara-Pratiharas were one of the major powers in the long, shifting contest for Kannauj alongside the Palas and Rashtrakutas." },
  { era:"medieval", q:"Ajmer’s Chishti shrine became important through which combination?", options:["Only military conquest","Pilgrimage, devotional practice, patronage and travel networks","The 1956 States Reorganisation Act","A Portuguese cartaz monopoly"], correct:1, explain:"Ajmer’s dargah grew as a devotional and pilgrimage institution tied to broader social, political and travel networks." },
  { era:"colonial", q:"What did many Praja Mandal organisations seek in princely states?", options:["Abolition of all regional languages","Civil rights, representation and responsible government, with programmes that varied by state","An end to every form of local association","A Portuguese maritime pass"], correct:1, explain:"Praja Mandals and related associations challenged arbitrary authority and sought rights or representative institutions; their local contexts differed." },
  { era:"colonial", q:"When was the Gang Canal brought into use?", options:["1757","1857","1927","1956"], correct:2, explain:"The Gang Canal was brought into use in 1927, reshaping settlement and cultivation in the north-western Bikaner frontier." },
  { era:"colonial", q:"What is an important caution when discussing the 1913 Mangarh attack?", options:["It was unrelated to Bhil mobilisation","Casualty estimates vary and should not be repeated as a single certain figure","It happened after the 1956 reorganisation","It was a port tax dispute"], correct:1, explain:"The attack is linked to Bhil mobilisation around Govind Guru; estimates of deaths vary and deserve careful qualification." },
  { era:"colonial", q:"Which is a sound way to explain famine in environmental history?", options:["Weather alone determines who starves","Separate the hazard from access to food, wages, prices, policy and relief","Ignore transport and land rights","Assume every region experienced the same effects"], correct:1, explain:"Environmental stress matters, but vulnerability and famine are shaped by entitlements, markets, state policy and unequal access." },
  { era:"modern", q:"Which pair correctly distinguishes the Constitution’s adoption from its commencement?", options:["Adopted 26 January 1950; in force 26 November 1949","Adopted 26 November 1949; in force 26 January 1950","Both occurred in 1947","Both occurred in 1956"], correct:1, explain:"The Constituent Assembly adopted the Constitution on 26 November 1949; it came into force on 26 January 1950." },
  { era:"modern", q:"Which sequence best describes linguistic state reorganisation?", options:["The 1956 Act preceded the creation of Andhra State in 1953","Andhra State was created in 1953; a major reorganisation followed in 1956","All state boundaries were fixed permanently in 1947","The Constitution banned linguistic states"], correct:1, explain:"Andhra State was created in 1953; the States Reorganisation Act of 1956 redrew many boundaries, and reorganisation continued later." },
  { era:"modern", q:"What does the GST Council illustrate in Indian federalism?", options:["A purely local village assembly","A forum for Union–state coordination and bargaining over a shared tax framework","A colonial port authority","A body that replaced the Constitution"], correct:1, explain:"The GST Council is an intergovernmental institution; its history shows both cooperation and negotiation between the Union and states." },
  { era:"modern", q:"Which concern is commonly linked to Green Revolution agriculture in Punjab?", options:["Groundwater pressure from intensive irrigation and crop concentration","The disappearance of all foodgrain production","The end of state procurement","The creation of the Indian Ocean monsoon"], correct:0, explain:"The package raised foodgrain production, but intensive irrigation and concentration in wheat and rice increased ecological pressures, including groundwater depletion." },
'''

TIMELINE=r'''  // ---------- THEMATIC STUDIES ----------
  { sortKey:-3000, date:"c. 3000 BCE onward", era:"ancient", title:"Ahar-Banas communities", body:"Chalcolithic settlements in south-eastern Rajasthan connect farming, copper working, pottery and regional exchange." },
  { sortKey:100, date:"First centuries CE", era:"ancient", title:"Indian Ocean port networks", body:"Ports such as Bharuch, Arikamedu and Muziris connect South Asian coasts with the Red Sea, Persian Gulf and wider trading worlds." },
  { sortKey:750, date:"Eighth–tenth centuries", era:"medieval", title:"Gurjara-Pratihara power", body:"The Pratiharas participate in a long contest for Kannauj with Pala and Rashtrakuta powers." },
  { sortKey:1025, date:"1025 CE", era:"medieval", title:"Chola expedition toward Srivijaya", body:"Rajendra Chola I’s forces attack centres associated with Srivijaya; the campaign does not establish lasting Chola rule across Southeast Asia." },
  { sortKey:1730, date:"1730 CE", era:"colonial", title:"Khejarli remembered", body:"Bishnoi tradition remembers Amrita Devi and others who resisted the felling of khejri trees at Khejarli in Marwar." },
  { sortKey:1855, date:"1855–56 CE", era:"colonial", title:"Santhal Hul", body:"Santhal communities rise against exploitative revenue relations, moneylending and encroaching authority in eastern India." },
  { sortKey:1865, date:"1865 CE", era:"colonial", title:"First Indian Forest Act", body:"Colonial forest law begins a changing framework for state regulation of forests and local access." },
  { sortKey:1899, date:"1899–1900 CE", era:"colonial", title:"Munda Ulgulan", body:"Birsa Munda’s movement links religious renewal to land, community authority and resistance in Chotanagpur." },
  { sortKey:1913, date:"1913 CE", era:"colonial", title:"Mangarh mobilisation and attack", body:"Govind Guru’s Bhil-led social and political mobilisation is violently suppressed at Mangarh; casualty estimates vary." },
  { sortKey:1916, date:"1916 onward", era:"colonial", title:"Bijolia peasant movement", body:"A long campaign in Mewar challenges taxes and compulsory labour under princely rule." },
  { sortKey:1917, date:"1917 CE", era:"colonial", title:"Champaran satyagraha", body:"Cultivators challenge coercive indigo arrangements through local organisation and public political action." },
  { sortKey:1918, date:"1918 CE", era:"colonial", title:"Kheda satyagraha", body:"Peasants seek revenue relief after crop failure, linking local organisation to a wider campaign." },
  { sortKey:1925, date:"1925–1927 CE", era:"colonial", title:"Gang Canal construction", body:"Bikaner’s canal project brings Sutlej water toward the dry north-western frontier and reshapes settlement and farming." },
  { sortKey:1949, date:"30 March 1949", era:"modern", title:"Greater Rajasthan inaugurated", body:"A staged sequence of unions brings major princely states together; further state reorganisation continues through 1956." },
  { sortKey:1953, date:"1953 CE", era:"modern", title:"Andhra State created", body:"A major linguistic-state demand changes the debate over India’s federal map." },
  { sortKey:1956, date:"1956 CE", era:"modern", title:"States Reorganisation Act", body:"A major redrawing of state boundaries reshapes the federation, with language a central but not exclusive principle." },
  { sortKey:1973, date:"1973 onward", era:"modern", title:"Chipko campaigns", body:"Local Himalayan campaigns contest commercial tree felling and connect forests to livelihood and community voice." },
  { sortKey:1979, date:"1979–1985 CE", era:"modern", title:"Assam movement", body:"A mass movement over migration, citizenship and electoral rolls leads to negotiations and the Assam Accord." },
  { sortKey:2017, date:"2017 CE", era:"modern", title:"Goods and Services Tax begins", body:"The GST Council becomes a central forum for Union–state coordination and disagreement over a shared tax framework." },
'''

MAP_SITES=r'''  // ---------- THEMATIC STUDIES ----------
  { name:"Ahar", lat:24.580, lon:73.700, era:"ancient", blurb:"Ahar-Banas settlement zone; distinctive Chalcolithic pottery and copper-working traditions." },
  { name:"Muziris / Pattanam region", lat:10.160, lon:76.210, era:"ancient", blurb:"Malabar coast port zone associated with long-distance Indian Ocean trade; exact identification is discussed." },
  { name:"Bharuch (Barygaza)", lat:21.705, lon:72.995, era:"ancient", blurb:"Western Indian port linked to inland routes and Red Sea–Arabian Sea exchange." },
  { name:"Arikamedu", lat:11.910, lon:79.810, era:"ancient", blurb:"An archaeological site near Puducherry with evidence for coastal exchange in the early historic period." },
  { name:"Nalanda", lat:25.136, lon:85.443, era:"ancient", blurb:"A major monastic and learning centre connected to regional and transregional scholarly networks." },
  { name:"Calicut (Kozhikode)", lat:11.259, lon:75.780, era:"medieval", blurb:"A major Malabar port whose merchant and political networks connected the Indian Ocean." },
  { name:"Cambay (Khambhat)", lat:22.317, lon:72.620, era:"medieval", blurb:"Gujarat port and trading centre linked to inland markets and western Indian Ocean routes." },
  { name:"Zawar", lat:24.346, lon:73.687, era:"medieval", blurb:"Rajasthan mining landscape associated with historical lead and zinc production." },
  { name:"Khejarli", lat:26.046, lon:73.087, era:"colonial", blurb:"Bishnoi tradition remembers the 1730 defence of khejri trees at this Marwar village." },
  { name:"Mangarh Hill", lat:23.660, lon:74.020, era:"colonial", blurb:"Site of Govind Guru’s Bhil-led mobilisation and the 1913 attack; casualty estimates vary." },
  { name:"Bijolia", lat:25.147, lon:75.341, era:"colonial", blurb:"Mewar centre of a long peasant campaign against taxes and compulsory labour." },
  { name:"Champaran", lat:26.650, lon:84.900, era:"colonial", blurb:"Indigo cultivators’ 1917 campaign and a major episode in local and national politics." },
  { name:"Kheda", lat:22.750, lon:72.680, era:"colonial", blurb:"Site of the 1918 peasant campaign for revenue relief after crop failure." },
  { name:"Sri Ganganagar", lat:29.920, lon:73.880, era:"colonial", blurb:"Gang Canal irrigation reshaped Bikaner’s north-west frontier, settlement and agriculture." },
  { name:"Chennai (Madras)", lat:13.083, lon:80.270, era:"colonial", blurb:"A colonial port and administrative centre whose growth drew on coastal and inland networks." },
  { name:"Kolkata (Calcutta)", lat:22.573, lon:88.364, era:"colonial", blurb:"Company and Crown port city shaped by imperial administration, labour, migration and industry." },
'''

MAP_TIMELINE=r'''  // ---------- THEMATIC STUDIES ----------
  {year:-3000,date:"c. 3000 BCE onward",era:"ancient",title:"Ahar-Banas communities",place:"Ahar",lat:24.580,lon:73.700,summary:"Chalcolithic settlements in south-eastern Rajasthan connect farming, copper working and exchange.",url:"thematic-studies/rajasthan-northwest.html"},
  {year:100,date:"First centuries CE",era:"ancient",title:"Muziris and Indian Ocean exchange",place:"Muziris / Pattanam region",lat:10.160,lon:76.210,summary:"Malabar coast ports linked South Asian traders to Red Sea, Persian Gulf and wider maritime networks.",url:"thematic-studies/indian-ocean.html"},
  {year:1025,date:"1025 CE",era:"medieval",title:"Chola expedition toward Srivijaya",place:"Thanjavur",lat:10.787,lon:79.137,summary:"Rajendra Chola I’s forces attack centres associated with Srivijaya; this is not a story of lasting Chola territorial rule there.",url:"thematic-studies/indian-ocean.html"},
  {year:1730,date:"1730 CE",era:"colonial",title:"Khejarli tree defence remembered",place:"Khejarli",lat:26.046,lon:73.087,summary:"Bishnoi tradition remembers Amrita Devi and others who resisted the felling of khejri trees in Marwar.",url:"thematic-studies/environmental-history.html"},
  {year:1855,date:"1855–56 CE",era:"colonial",title:"Santhal Hul",place:"Santhal Pargana region",lat:24.800,lon:87.550,summary:"Santhal communities rise against exploitative revenue relations, moneylending and encroaching authority.",url:"thematic-studies/regional-movements.html"},
  {year:1899,date:"1899–1900 CE",era:"colonial",title:"Munda Ulgulan",place:"Chotanagpur",lat:23.350,lon:85.330,summary:"Birsa Munda’s movement links land claims, community authority and religious renewal.",url:"thematic-studies/regional-movements.html"},
  {year:1913,date:"1913 CE",era:"colonial",title:"Mangarh mobilisation and attack",place:"Mangarh Hill",lat:23.660,lon:74.020,summary:"A Bhil-led movement associated with Govind Guru is violently suppressed; casualty estimates vary.",url:"thematic-studies/regional-movements.html"},
  {year:1916,date:"1916 onward",era:"colonial",title:"Bijolia peasant movement",place:"Bijolia, Mewar",lat:25.147,lon:75.341,summary:"A long agrarian campaign challenges taxes and compulsory labour under princely rule.",url:"thematic-studies/regional-movements.html"},
  {year:1917,date:"1917 CE",era:"colonial",title:"Champaran satyagraha",place:"Champaran",lat:26.650,lon:84.900,summary:"Cultivators contest coercive indigo arrangements through local organisation and public politics.",url:"thematic-studies/regional-movements.html"},
  {year:1918,date:"1918 CE",era:"colonial",title:"Kheda satyagraha",place:"Kheda",lat:22.750,lon:72.680,summary:"Peasants seek revenue relief after crop failure through negotiation and organised non-payment.",url:"thematic-studies/regional-movements.html"},
  {year:1927,date:"1927 CE",era:"colonial",title:"Gang Canal brought into use",place:"Sri Ganganagar",lat:29.920,lon:73.880,summary:"Irrigation transforms settlement, farming and water use in the north-western Bikaner frontier.",url:"thematic-studies/rajasthan-northwest.html"},
  {year:1949,date:"30 March 1949",era:"modern",title:"Greater Rajasthan inaugurated",place:"Jaipur",lat:26.912,lon:75.787,summary:"A staged sequence of accessions and unions shapes Rajasthan; reorganisation continues through 1956.",url:"thematic-studies/rajasthan-northwest.html"},
  {year:1953,date:"1953 CE",era:"modern",title:"Andhra State created",place:"Kurnool",lat:15.828,lon:78.037,summary:"A linguistic-state demand reshapes the debate over India’s federal map.",url:"thematic-studies/constitution-federalism.html"},
  {year:1956,date:"1956 CE",era:"modern",title:"States Reorganisation Act",place:"New Delhi",lat:28.614,lon:77.209,summary:"A major redrawing of India’s state boundaries uses language as an important, though not exclusive, principle.",url:"thematic-studies/constitution-federalism.html"},
  {year:1973,date:"1973 onward",era:"modern",title:"Chipko campaigns",place:"Uttarakhand Himalaya",lat:30.400,lon:79.320,summary:"Local campaigns contest commercial tree felling and connect forest access to livelihood and community voice.",url:"thematic-studies/environmental-history.html"},
  {year:1979,date:"1979–1985 CE",era:"modern",title:"Assam movement",place:"Assam",lat:26.145,lon:91.736,summary:"A mass movement over migration, citizenship and electoral rolls leads to negotiation and the Assam Accord.",url:"thematic-studies/regional-movements.html"},
  {year:2017,date:"2017 CE",era:"modern",title:"GST Council and fiscal federalism",place:"New Delhi",lat:28.614,lon:77.209,summary:"The shared tax framework makes Union–state coordination and bargaining central to the fiscal story.",url:"thematic-studies/constitution-federalism.html"}
'''


def insert_array(path, variable, fragment, marker):
    p=ROOT/path
    s=p.read_text(encoding='utf-8')
    if marker in s:
        return False
    start=s.find(variable)
    if start<0:
        raise ValueError(f"{variable} not found in {path}")
    close=s.find('\n];',start)
    if close<0:
        raise ValueError(f"closing array not found after {variable} in {path}")
    before=s[:close].rstrip()
    if before.endswith('}'):
        s=before+','+s[len(before):]
        close=s.find('\n];',start)
    s=s[:close]+"\n"+fragment.rstrip()+s[close:]
    p.write_text(s,encoding='utf-8')
    return True

# Shared data sources used by deep-dive portals and the revision room.
insert_array(Path('assets/js/glossary-data.js'),'window.GLOSSARY = [',GLOSSARY,'// ---------- THEMATIC STUDIES ----------')
insert_array(Path('assets/js/quiz-data.js'),'window.QUIZ_BANK = [',QUIZ,'// ---------- THEMATIC STUDIES ----------')
insert_array(Path('assets/js/timeline-data.js'),'window.TIMELINE_EVENTS = [',TIMELINE,'// ---------- THEMATIC STUDIES ----------')
insert_array(Path('assets/js/map-data.js'),'window.MAP_SITES = [',MAP_SITES,'// ---------- THEMATIC STUDIES ----------')
insert_array(Path('assets/js/map-timeline-data.js'),'window.MAP_TIMELINE_EVENTS=[',MAP_TIMELINE,'// ---------- THEMATIC STUDIES ----------')

# The legacy overview pages keep their own inline data for these primary study tools.
insert_array(Path('glossary.html'),'window.GLOSSARY = [',GLOSSARY,'// ---------- THEMATIC STUDIES ----------')
insert_array(Path('flashcards.html'),'window.GLOSSARY = [',GLOSSARY,'// ---------- THEMATIC STUDIES ----------')
insert_array(Path('quiz.html'),'window.QUIZ_BANK = [',QUIZ,'// ---------- THEMATIC STUDIES ----------')
insert_array(Path('timeline.html'),'window.TIMELINE_EVENTS = [',TIMELINE,'// ---------- THEMATIC STUDIES ----------')
insert_array(Path('map.html'),'window.MAP_SITES = [',MAP_SITES,'// ---------- THEMATIC STUDIES ----------')
print('Integrated thematic glossary, quiz, timeline, atlas and map-timeline data.')
