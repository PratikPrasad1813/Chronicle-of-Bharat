// Chronicle of Bharat — shared site behavior
(function(){
  "use strict";

  // Site-wide search index. Glossary terms are merged in automatically
  // wherever glossary-data.js is also loaded.
  window.SEARCH_INDEX = [
    { title:"Chronicle of Bharat", section:"Home", snippet:"Three chronicles of Indian history, a timeline, an atlas, and a quiz.", url:"index.html" },
    { title:"Historiography: reading the same evidence differently", section:"Ancient India", snippet:"Six historiographical schools and three competing periodisations of ancient India.", url:"ancient.html#historiography" },
    { title:"Before the cities: prehistory", section:"Ancient India", snippet:"Palaeolithic toolmakers, Mehrgarh, and the Chalcolithic horizon.", url:"ancient.html#prehistory" },
    { title:"The Indus Valley Civilisation", section:"Ancient India", snippet:"Harappa, Mohenjo-daro, trade with Mesopotamia, and the drought that ended it.", url:"ancient.html#indus" },
    { title:"The Vedic Age", section:"Ancient India", snippet:"Cattle wealth to iron ploughs — pastoral clans harden into the varna system.", url:"ancient.html#vedic" },
    { title:"Sixteen Mahajanapadas", section:"Ancient India", snippet:"The Second Urbanisation and the rise of Buddhism and Jainism.", url:"ancient.html#mahajanapadas" },
    { title:"Keezhadi rewrites the map", section:"Ancient India", snippet:"Tamil Nadu's urbanisation redated to 580 BCE.", url:"ancient.html#keezhadi" },
    { title:"Mauryas to Guptas", section:"Ancient India", snippet:"Kautilya's Arthashastra, Ashoka's Dhamma, and Aryabhata's zero.", url:"ancient.html#empires" },
    { title:"Ancient India: comprehensive chronology", section:"Ancient India", snippet:"The full timeline from Palaeolithic to early medieval in one table.", url:"ancient.html#synthesis" },
    { title:"Was early-medieval India feudal?", section:"Medieval India", snippet:"R.S. Sharma's feudal-decay model versus Chattopadhyaya's integrative model.", url:"medieval.html#historiography" },
    { title:"The Tripartite Struggle for Kannauj", section:"Medieval India", snippet:"Gurjara-Pratihara, Pala and Rashtrakuta fight for the Gangetic heartland.", url:"medieval.html#tripartite" },
    { title:"The Delhi Sultanate", section:"Medieval India", snippet:"The Iqta system, the six Diwans, and Alauddin Khalji's price controls.", url:"medieval.html#sultanate" },
    { title:"Vijayanagara and the Deccan Sultanates", section:"Medieval India", snippet:"The Nayankara system and the Battle of Talikota.", url:"medieval.html#deccan" },
    { title:"The Mughal machine", section:"Medieval India", snippet:"Mansabdari ranks, the Dahsala revenue system, and the Be-jagiri crisis.", url:"medieval.html#mughal" },
    { title:"Bhakti, Sufi devotion and architecture", section:"Medieval India", snippet:"Nirguna and Saguna Bhakti, the Chishti order, and Indo-Islamic architecture.", url:"medieval.html#culture" },
    { title:"An empire that ran out of land", section:"Colonial India", snippet:"The jama-hasil revenue gap, Nadir Shah's sack of Delhi, and the rise of successor states.", url:"colonial.html#decline" },
    { title:"A trading company becomes a sovereign", section:"Colonial India", snippet:"Plassey, Buxar, the Diwani, and Parliament's regulation of the East India Company.", url:"colonial.html#company" },
    { title:"The rebellion that ended the Company", section:"Colonial India", snippet:"The 1857 Rebellion and the transfer of power to the Crown.", url:"colonial.html#1857" },
    { title:"Did the British deindustrialise India?", section:"Colonial India", snippet:"Three historiographical schools and the Drain of Wealth.", url:"colonial.html#economy" },
    { title:"Land revenue and famine", section:"Colonial India", snippet:"Permanent Settlement, Ryotwari, Mahalwari, and Amartya Sen's entitlement model.", url:"colonial.html#land" },
    { title:"Resistance: tribal and peasant uprisings", section:"Colonial India", snippet:"The Santhal Hul, the Munda Ulgulan, the Indigo Revolt, and the Deccan Riots.", url:"colonial.html#resistance" },
    { title:"Path to Partition", section:"Colonial India", snippet:"The Steel Frame, constitutional concessions, the Cabinet Mission, and 1947.", url:"colonial.html#partition" },
    { title:"Stitching a republic: integration", section:"Post-Independence", snippet:"565+ princely states, Operation Polo, and the 1950 Constitution.", url:"modern.html#integration" },
    { title:"The Nehruvian era", section:"Post-Independence", snippet:"Five-Year Plans, the IITs, and Non-Alignment.", url:"modern.html#nehru" },
    { title:"The Green Revolution", section:"Post-Independence", snippet:"High-yield seeds, food security, and the groundwater cost.", url:"modern.html#green" },
    { title:"1971 and nuclear doctrine", section:"Post-Independence", snippet:"The Bangladesh Liberation War, Smiling Buddha, and Pokhran-II.", url:"modern.html#nuclear" },
    { title:"The 1991 reforms", section:"Post-Independence", snippet:"Liberalisation, Privatisation, Globalisation, and the services-led growth paradox.", url:"modern.html#reforms" },
    { title:"Caste, secularism and unfinished renegotiation", section:"Post-Independence", snippet:"The Mandal Commission and Sarva Dharma Sambhava.", url:"modern.html#society" },
    { title:"The full timeline", section:"Study tools", snippet:"All three chronicles on one filterable, colour-coded timeline.", url:"timeline.html" },
    { title:"The atlas", section:"Study tools", snippet:"A real map of India with sites from every era, toggleable by layer.", url:"map.html" },
    { title:"The examination hall", section:"Study tools", snippet:"A scored quiz drawn from all three chronicles.", url:"quiz.html" },
    { title:"Glossary", section:"Study tools", snippet:"Every technical term across all three chronicles, defined in one place.", url:"glossary.html" },
    { title:"Flashcards", section:"Study tools", snippet:"Flip through every glossary term for quick revision.", url:"flashcards.html" },
    { title:"Revision notes", section:"Study tools", snippet:"Condensed, printable exam notes for all three chronicles.", url:"notes.html" },
    { title:"Dynasty family trees", section:"Study tools", snippet:"Succession diagrams for the Mauryas, Guptas, Sultanate, Mughals, Vijayanagara and Cholas.", url:"dynasties.html" }
  ];

  // Mobile nav toggle
  var toggle = document.querySelector(".nav__toggle");
  var nav = document.querySelector(".nav");
  if(toggle && nav){
    toggle.addEventListener("click", function(){
      var open = nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    nav.querySelectorAll("a").forEach(function(a){
      a.addEventListener("click", function(){ nav.classList.remove("is-open"); });
    });
  }

  // Highlight current page in nav
  var here = (location.pathname.split("/").pop() || "index.html");
  document.querySelectorAll(".nav a[href]").forEach(function(a){
    var href = a.getAttribute("href");
    if(href === here || (here === "" && href === "index.html")){
      a.classList.add("is-active");
    }
  });

  // Scroll reveal
  var reveals = document.querySelectorAll(".reveal");
  if("IntersectionObserver" in window && reveals.length){
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting){
          entry.target.classList.add("is-visible");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    reveals.forEach(function(el){ io.observe(el); });
  } else {
    reveals.forEach(function(el){ el.classList.add("is-visible"); });
  }

  // Scroll-spy: highlight the page-rail link for the section in view
  var railLinks = document.querySelectorAll(".page-rail a[href^='#']");
  if(railLinks.length && "IntersectionObserver" in window){
    var railMap = [];
    railLinks.forEach(function(a){
      var el = document.getElementById(a.getAttribute("href").slice(1));
      if(el) railMap.push({ link:a, el:el });
    });
    var spy = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(!entry.isIntersecting) return;
        var match = railMap.find(function(m){ return m.el === entry.target; });
        if(!match) return;
        railLinks.forEach(function(a){ a.classList.remove("is-active"); });
        match.link.classList.add("is-active");
      });
    }, { rootMargin: "-104px 0px -70% 0px", threshold: 0 });
    railMap.forEach(function(m){ spy.observe(m.el); });
  }

  // Footer year
  document.querySelectorAll("[data-year]").forEach(function(el){
    el.textContent = new Date().getFullYear();
  });

  // ---------------------------------------------------------------------
  // Theme toggle (dark / light). The <head> of every page also runs a tiny
  // inline script that applies the saved theme before first paint, so
  // there's no flash — this just wires up the visible button.
  // ---------------------------------------------------------------------
  var themeBtn = document.querySelector(".theme-toggle");
  if(themeBtn){
    themeBtn.addEventListener("click", function(){
      var isDark = document.documentElement.getAttribute("data-theme") === "dark";
      var next = isDark ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", next);
      try{ localStorage.setItem("chronicle-theme", next); }catch(e){}
    });
  }

  // ---------------------------------------------------------------------
  // Site-wide search
  // ---------------------------------------------------------------------
  var searchBtn = document.querySelector(".search-trigger");
  var overlay = document.querySelector(".search-overlay");
  if(searchBtn && overlay){
    var input = overlay.querySelector("input");
    var resultsEl = overlay.querySelector(".search-results");
    var closeBtn = overlay.querySelector(".search-close");

    function slugify(s){
      return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    }

    function allEntries(){
      var base = (window.SEARCH_INDEX || []).slice();
      (window.GLOSSARY || []).forEach(function(g){
        base.push({ title:g.term, section:"Glossary \u00b7 " + (g.era||""), snippet:g.def, url:"glossary.html#term-" + slugify(g.term) });
      });
      return base;
    }

    function renderResults(query){
      var items = allEntries();
      var q = query.trim().toLowerCase();
      var matches = !q ? items.slice(0, 8) : items.filter(function(it){
        return (it.title + " " + it.snippet + " " + (it.section||"") + " " + (it.keywords||"")).toLowerCase().indexOf(q) !== -1;
      }).slice(0, 24);
      resultsEl.innerHTML = "";
      if(!matches.length){
        resultsEl.innerHTML = '<div class="search-empty">No matches for &ldquo;' + query + '&rdquo;. Try a different word.</div>';
        return;
      }
      matches.forEach(function(it){
        var a = document.createElement("a");
        a.className = "search-result";
        a.href = it.url;
        a.innerHTML = '<p class="eyebrow">' + it.section + '</p><h4>' + it.title + '</h4><p>' + it.snippet + '</p>';
        resultsEl.appendChild(a);
      });
    }

    function openSearch(){
      overlay.classList.add("is-open");
      overlay.setAttribute("aria-hidden", "false");
      renderResults("");
      setTimeout(function(){ input.focus(); }, 60);
    }
    function closeSearch(){
      overlay.classList.remove("is-open");
      overlay.setAttribute("aria-hidden", "true");
      input.value = "";
    }

    searchBtn.addEventListener("click", openSearch);
    if(closeBtn) closeBtn.addEventListener("click", closeSearch);
    overlay.addEventListener("click", function(e){ if(e.target === overlay) closeSearch(); });
    input.addEventListener("input", function(){ renderResults(input.value); });
    document.addEventListener("keydown", function(e){
      var tag = (document.activeElement && document.activeElement.tagName) || "";
      if(e.key === "/" && tag !== "INPUT" && tag !== "TEXTAREA" && !overlay.classList.contains("is-open")){
        e.preventDefault(); openSearch();
      } else if(e.key === "Escape" && overlay.classList.contains("is-open")){
        closeSearch();
      }
    });
  }

  // ---------------------------------------------------------------------
  // Glossary auto-tooltips — wraps the first mention of each glossary term
  // found in chronicle prose with a hoverable/focusable definition.
  // ---------------------------------------------------------------------
  document.addEventListener("DOMContentLoaded", function(){
    if(!window.GLOSSARY || !window.GLOSSARY.length) return;
    var containers = document.querySelectorAll(".entry p, .entry li");
    if(!containers.length) return;

    function escapeRegex(s){ return s.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&"); }
    var terms = window.GLOSSARY.slice().sort(function(a,b){ return b.term.length - a.term.length; });

    terms.forEach(function(g){
      var regex = new RegExp("\\b(" + escapeRegex(g.term) + ")\\b", "i");
      for(var i = 0; i < containers.length; i++){
        var el = containers[i];
        var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null);
        var node, wrapped = false;
        while((node = walker.nextNode())){
          var m = regex.exec(node.nodeValue);
          if(m){
            var range = document.createRange();
            range.setStart(node, m.index);
            range.setEnd(node, m.index + m[0].length);
            var span = document.createElement("span");
            span.className = "gloss-term";
            span.tabIndex = 0;
            span.setAttribute("data-def", g.def);
            range.surroundContents(span);
            wrapped = true;
            break;
          }
        }
        if(wrapped) break;
      }
    });
  });
})();
