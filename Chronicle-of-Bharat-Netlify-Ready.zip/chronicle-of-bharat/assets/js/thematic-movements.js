/* Accessible filter controls for the regional movements atlas. */
(function(){
  'use strict';
  var cards=Array.prototype.slice.call(document.querySelectorAll('.theme-movement'));
  var buttons=Array.prototype.slice.call(document.querySelectorAll('[data-period-filter]'));
  var region=document.getElementById('movement-region');
  var count=document.getElementById('movement-count');
  if(!cards.length||!buttons.length)return;
  var period='all';
  function update(){
    var visible=0;
    cards.forEach(function(card){
      var periodMatch=period==='all'||card.dataset.period===period;
      var regionMatch=!region||region.value==='all'||card.dataset.region===region.value;
      card.hidden=!(periodMatch&&regionMatch);
      if(!card.hidden)visible++;
    });
    if(count)count.textContent='Showing '+visible+' of '+cards.length+' selected examples.';
  }
  buttons.forEach(function(button){
    button.addEventListener('click',function(){
      period=button.dataset.periodFilter||'all';
      buttons.forEach(function(other){other.setAttribute('aria-pressed',String(other===button));});
      update();
    });
  });
  if(region)region.addEventListener('change',update);
  update();
})();
