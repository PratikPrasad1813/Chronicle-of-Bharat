/* Chronicle of Bharat — shared map reference and projection.
 * Map geometry is loaded from the supplied Simplemaps India state/UT SVG.
 * Copyright (c) 2024 Pareto Software, LLC DBA Simplemaps.com.
 * Free for commercial use under https://simplemaps.com/resources/svg-license;
 * attribution is appreciated at https://simplemaps.com.
 */
(function(){
  'use strict';
  var script=document.currentScript;
  var svgHref=script&&script.src
    ? new URL('../svg/india-states-simplemaps.svg',script.src).href
    : '../assets/svg/india-states-simplemaps.svg';
  var regionNames=[
    'Andaman and Nicobar','Telangana','Andhra Pradesh','Arunachal Pradesh','Assam','Bihar',
    'Chandigarh','Chhattisgarh','Dādra and Nagar Haveli and Damān and Diu','Delhi','Goa','Gujarat',
    'Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra',
    'Manipur','Meghalaya','Mizoram','Nagaland','Orissa','Puducherry','Punjab','Rajasthan','Sikkim',
    'Tamil Nadu','Tripura','Uttar Pradesh','Uttaranchal','West Bengal','Lakshadweep',
    'Jammu and Kashmir','Ladakh'
  ];
  window.INDIA_GEO={
    proj:{A:27.38031127839343,B:-1767.0707166707837,C:-1568.6441448290477,D:1139.9190289622813,VBW:1000,VBH:1000},
    svgHref:svgHref,
    featureHref:svgHref+'#features',
    regionNames:regionNames
  };
  window.projectLonLat=function(lon,lat){
    var p=window.INDIA_GEO.proj;
    var merc=Math.log(Math.tan(Math.PI/4+(lat*Math.PI/180)/2));
    return {x:p.A*lon+p.B,y:p.C*merc+p.D};
  };
})();
