/* Chronicle of Bharat — shared dashboard, language, Wikipedia and offline hooks. */
(function(){
  'use strict';
  if(window.__chronicleExtrasLoaded) return;
  window.__chronicleExtrasLoaded=true;

  var current=document.currentScript;
  var scriptUrl=current&&current.src?current.src:new URL('assets/js/chronicle-extras.js',location.href).href;
  var rootUrl=new URL('../../',scriptUrl);
  var rootPath=rootUrl.pathname;
  function asset(path){return new URL(path,rootUrl).href;}
  var STORE_KEY='chronicle-study-v1';

  function emptyState(){return {version:1,visited:{},completed:{},visitCounts:{},lastPage:'',lastTitle:'',notes:'',quizAttempts:[],flashcardStats:{},updatedAt:0};}
  function readState(){
    try{
      var saved=JSON.parse(localStorage.getItem(STORE_KEY)||'null');
      if(!saved||typeof saved!=='object') return emptyState();
      var base=emptyState();
      Object.keys(base).forEach(function(k){if(saved[k]!==undefined)base[k]=saved[k];});
      ['visited','completed','visitCounts','flashcardStats'].forEach(function(k){if(!base[k]||typeof base[k]!=='object')base[k]={};});
      if(!Array.isArray(base.quizAttempts))base.quizAttempts=[];
      return base;
    }catch(e){return emptyState();}
  }
  function emit(state){
    state.updatedAt=Date.now();
    try{localStorage.setItem(STORE_KEY,JSON.stringify(state));}catch(e){}
    try{window.dispatchEvent(new CustomEvent('chronicle:study-updated',{detail:state}));}catch(e){}
    return state;
  }
  function pageKey(){
    var path=decodeURIComponent(location.pathname||'');
    if(path.indexOf(rootPath)===0)path=path.slice(rootPath.length);
    path=path.replace(/^\/+/, '');
    return path||'index.html';
  }
  function pageTitle(){
    var h=document.querySelector('main h1');
    return (h&&h.textContent.trim())||document.title.replace(/\s*[—–|-]\s*Chronicle of Bharat.*$/i,'').trim()||pageKey();
  }
  function markVisited(){
    var key=pageKey();
    if(/^(dashboard|revision|map-timeline|offline)\.html$/i.test(key))return;
    var state=readState(),now=Date.now();
    state.visited[key]={title:pageTitle(),at:now};
    state.visitCounts[key]=(Number(state.visitCounts[key])||0)+1;
    state.lastPage=key;state.lastTitle=pageTitle();state.lastVisitedAt=now;
    emit(state);
  }
  function markComplete(key){
    key=key||pageKey();
    if(/^(dashboard|revision|map-timeline|offline)\.html$/i.test(key))return;
    var state=readState();
    state.completed[key]={at:Date.now(),title:state.visited[key]&&state.visited[key].title||pageTitle()};
    emit(state);
  }
  function recordQuiz(result){
    var state=readState();
    state.quizAttempts.unshift(Object.assign({at:Date.now()},result||{}));
    state.quizAttempts=state.quizAttempts.slice(0,100);
    emit(state);
  }
  function recordFlashcards(result){
    var state=readState(),era=(result&&result.era)||'all';
    var old=state.flashcardStats[era]||{sessions:0,known:0,learning:0};
    old.sessions=(Number(old.sessions)||0)+1;
    old.known=(Number(old.known)||0)+(Number(result&&result.known)||0);
    old.learning=(Number(old.learning)||0)+(Number(result&&result.learning)||0);
    old.lastAt=Date.now();state.flashcardStats[era]=old;emit(state);
  }
  window.ChronicleStudy={key:STORE_KEY,read:readState,write:emit,pageKey:pageKey,markComplete:markComplete,recordQuiz:recordQuiz,recordFlashcards:recordFlashcards,rootUrl:rootUrl.href};

  markVisited();
  var completionQueued=false;
  function checkReading(){
    if(completionQueued)return;
    var max=document.documentElement.scrollHeight-window.innerHeight;
    if(max<=0||window.scrollY>=max*.82){
      completionQueued=true;
      markComplete(pageKey());
    }
  }
  window.addEventListener('scroll',checkReading,{passive:true});
  window.addEventListener('load',function(){setTimeout(checkReading,1500);});
  window.addEventListener('resize',checkReading);

  if(!document.querySelector('link[data-chronicle-extra-css]')){
    var css=document.createElement('link');css.rel='stylesheet';css.href=asset('assets/css/chronicle-extras.css');css.setAttribute('data-chronicle-extra-css','');document.head.appendChild(css);
  }
  if(!document.querySelector('link[rel="manifest"]')){
    var manifest=document.createElement('link');manifest.rel='manifest';manifest.href=asset('manifest.webmanifest');document.head.appendChild(manifest);
  }
  if(!document.querySelector('meta[name="theme-color"]')){
    var color=document.createElement('meta');color.name='theme-color';color.content='#24170f';document.head.appendChild(color);
  }

  /* A small global route to the local study dashboard. */
  var headerRight=document.querySelector('.site-header .header__right');
  if(headerRight&&!headerRight.querySelector('.chronicle-dashboard-link')&&!/^(dashboard)\.html$/i.test(pageKey())){
    var link=document.createElement('a');link.className='chronicle-dashboard-link';link.href=asset('dashboard.html');
    link.setAttribute('aria-label','Open the study dashboard');
    link.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="5" rx="1.5"/><rect x="13" y="10" width="8" height="11" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/></svg><span>Study dashboard</span>';
    var reference=headerRight.querySelector('.header__tools,.search-trigger,.chapters-menu');
    if(reference)headerRight.insertBefore(link,reference);else headerRight.insertBefore(link,headerRight.firstChild);
  }
  if(headerRight&&!headerRight.querySelector('.chronicle-themes-link')){
    var themeLink=document.createElement('a');themeLink.className='chronicle-themes-link';themeLink.href=asset('thematic-studies/index.html');themeLink.setAttribute('aria-label','Open cross-era thematic studies');
    themeLink.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 5.5h6.5A2.5 2.5 0 0 1 13 8v11a2.5 2.5 0 0 0-2.5-2.5H4zM20 5.5h-4A3 3 0 0 0 13 8v11a2.5 2.5 0 0 1 2.5-2.5H20z"/><path d="M6.5 9h3M6.5 12h3M16 9h1.5M16 12h1.5"/></svg><span>Themes</span>';
    var themeReference=headerRight.querySelector('.header__tools,.search-trigger,.chapters-menu');
    if(themeReference)headerRight.insertBefore(themeLink,themeReference);else headerRight.insertBefore(themeLink,headerRight.firstChild);
  }

  var footer=document.querySelector('.site-footer');
  if(footer&&!footer.querySelector('.chronicle-footer-tools')){
    var footerTools=document.createElement('nav');footerTools.className='chronicle-footer-tools';footerTools.setAttribute('aria-label','Study tools');
    [['Thematic studies','thematic-studies/index.html'],['Study dashboard','dashboard.html'],['Revision room','revision.html'],['Map timeline','map-timeline.html']].forEach(function(item){var a=document.createElement('a');a.href=asset(item[1]);a.textContent=item[0]+' →';footerTools.appendChild(a);});
    footer.appendChild(footerTools);
  }

  /* Full-page machine translation (English/Hindi) for every page. */
  if(!document.querySelector('.chronicle-language-holder')){
    var holder=document.createElement('div');holder.className='chronicle-language-holder';
    holder.innerHTML='<span class="chronicle-language-label">Language</span><div class="gtranslate_wrapper" aria-label="Choose English or Hindi"></div><span class="chronicle-language-fallback" hidden role="status">Translation is unavailable right now.</span>';
    var anchor=headerRight||document.querySelector('.site-header__row')||document.body;
    anchor.appendChild(holder);
    window.gtranslateSettings={default_language:'en',languages:['en','hi'],native_language_names:true,wrapper_selector:'.gtranslate_wrapper'};
    var gscript=document.createElement('script');gscript.src='https://cdn.gtranslate.net/widgets/latest/dropdown.js';gscript.async=true;
    gscript.onload=function(){setTimeout(function(){if(holder.querySelector('select,button,a'))holder.querySelector('.chronicle-language-fallback').hidden=true;},700);};
    gscript.onerror=function(){var fallback=holder.querySelector('.chronicle-language-fallback');fallback.hidden=false;};
    document.head.appendChild(gscript);
  }

  /* Wikipedia search is offered as further reading, never as an authority claim. */
  var key=pageKey();
  if(!/^(dashboard|revision|map-timeline|offline)\.html$/i.test(key)){
    var main=document.querySelector('main');
    if(main&&!main.querySelector('.chronicle-wikipedia')){
      var topic=pageTitle();
      if(/^(Chronicle of Bharat|Home|Overview)$/i.test(topic))topic='History of India';
      var box=document.createElement('section');box.className='chronicle-wikipedia';box.setAttribute('aria-labelledby','chronicle-wikipedia-title');
      var h=document.createElement('h2');h.id='chronicle-wikipedia-title';h.textContent='Further reading';
      var p=document.createElement('p');p.textContent='Continue exploring this topic on Wikipedia. Search results open in a new tab.';
      var row=document.createElement('div');row.className='chronicle-wikipedia__links';
      [['English Wikipedia','https://en.wikipedia.org/w/index.php?search='+encodeURIComponent(topic)+'&go=Go'],['हिंदी विकिपीडिया','https://hi.wikipedia.org/w/index.php?search='+encodeURIComponent(topic)+'&go=Go']] .forEach(function(item){var a=document.createElement('a');a.href=item[1];a.target='_blank';a.rel='noopener noreferrer';a.textContent=item[0]+' ↗';row.appendChild(a);});
      box.appendChild(h);box.appendChild(p);box.appendChild(row);main.appendChild(box);
    }
  }

  /* Cache the core study shell and every page a learner visits. */
  if('serviceWorker' in navigator&&window.isSecureContext){
    navigator.serviceWorker.register(asset('service-worker.js'),{scope:rootPath}).catch(function(){});
  }
  window.addEventListener('beforeinstallprompt',function(event){event.preventDefault();window.__chronicleInstallPrompt=event;window.dispatchEvent(new Event('chronicle:pwa-ready'));});
})();
