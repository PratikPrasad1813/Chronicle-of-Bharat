# Chronicle of Bharat — thematic studies roadmap

## Implemented: cross-era thematic studies

The former content suggestions are now organised as a companion portal at [`thematic-studies/index.html`](thematic-studies/index.html). It adds nine long-form modules without replacing the four chronological chronicles.

1. **Rajasthan and the North-West** — Kalibangan, the Ahar-Banas tradition, Gurjara-Pratihara and regional courts, Ajmer’s Sufi networks, Prajamandals, staged integration, the Gang Canal and Sri Ganganagar.
2. **India and the Indian Ocean** — monsoon routes, early ports, Chola–Srivijaya encounters, merchant networks, European companies, migration and the modern ocean.
3. **People’s Histories** — work, Adivasi and pastoral histories, gender, caste, popular politics and the challenges of reading everyday evidence.
4. **Constitutional Federalism** — Constitution-making, the Union and states, linguistic reorganisation, princely integration, fiscal bargaining and local government.
5. **Environmental History** — land and water systems, forests and law, famine, dams, the Green Revolution, environmental movements and climate history.
6. **Science, Technology and Knowledge** — mathematics, medicine, craft and engineering, translation networks, colonial science and Republic-era institutions.
7. **Cities Through Time** — Harappan urbanism, Pataliputra, Ujjain, Delhi, Hampi, Kolkata, Mumbai, Chennai and Bengaluru.
8. **Regional Movements Atlas** — a filterable, deliberately selective set of movements by period and region, connected to the interactive map timeline.
9. **Exam Answer Workshops** — argument, chronology, comparison, evidence and short outline practice.

## Integration with existing study features

- The chapters are linked from the new thematic portal, the main home page, global navigation, search and the local study dashboard.
- New glossary terms feed the glossary, classic flashcards and spaced-repetition revision deck.
- Added questions appear in the cross-era and era-filtered quizzes.
- New events and places are connected to the shared chronology, atlas and interactive map timeline.
- Every new module uses the site’s English/Hindi language control and Wikipedia further-reading links; there is no separate bibliography section.
- Dashboard tracking is local-only: study progress and revision data stay in this browser’s local storage, with JSON backup/restore for portability. There is no sign-in or cloud sync.

## Sensible future extensions

These are optional follow-up ideas, not unfinished requirements:

- Add more district-level Rajasthan histories, oral-history case studies and additional princely-state Praja Mandals.
- Extend the movement atlas with more regional filters and a dedicated visual map layer.
- Add more city case studies and comparative maps of transport, water and land use.
- Commission human-reviewed Hindi translations for the long-form chapter text when a translation budget is available.
- Expand the short exam workshops into printable practice sets with model outlines for different syllabi.
