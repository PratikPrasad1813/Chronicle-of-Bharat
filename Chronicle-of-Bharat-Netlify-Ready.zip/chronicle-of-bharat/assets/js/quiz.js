(function(){
  "use strict";
  var bank = window.QUIZ_BANK || [];
  var STORAGE_KEY = "chronicle-quiz-best";

  var screens = {
    setup: document.getElementById("quiz-setup"),
    play: document.getElementById("quiz-play"),
    results: document.getElementById("quiz-results")
  };

  var eraCheckboxes = document.querySelectorAll(".quiz-era-check");
  var lengthRadios = document.querySelectorAll(".quiz-length-radio");
  var startBtn = document.getElementById("quiz-start");
  var nextBtn = document.getElementById("quiz-next");
  var retryBtn = document.getElementById("quiz-retry");
  var progressEl = document.getElementById("quiz-progress");
  var progressBar = document.getElementById("quiz-progress-bar");
  var promptEl = document.getElementById("quiz-prompt");
  var optionsEl = document.getElementById("quiz-options");
  var explainEl = document.getElementById("quiz-explain");
  var eraTagEl = document.getElementById("quiz-era-tag");
  var scoreLine = document.getElementById("quiz-score-line");
  var gradeLine = document.getElementById("quiz-grade-line");
  var bestLine = document.getElementById("quiz-best-line");
  var setupBestLine = document.getElementById("quiz-setup-best");
  var breakdownEl = document.getElementById("quiz-breakdown");

  function shuffle(arr){
    var a = arr.slice();
    for(var i = a.length - 1; i > 0; i--){
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  function getBest(){
    try{
      var raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    }catch(e){ return null; }
  }
  function setBest(record){
    try{ localStorage.setItem(STORAGE_KEY, JSON.stringify(record)); }catch(e){}
  }

  function renderSetupBest(){
    if(!setupBestLine) return;
    var best = getBest();
    setupBestLine.textContent = best
      ? "Your best so far: " + best.score + "/" + best.total + " (" + best.pct + "%), set " + best.date + "."
      : "No attempts recorded yet on this device \u2014 this run will set the first score.";
  }

  var state = null;

  function showScreen(name){
    Object.keys(screens).forEach(function(k){
      screens[k].hidden = (k !== name);
    });
    if(name === "setup") renderSetupBest();
  }

  function eraLabel(era){
    return era === "ancient" ? "Ancient" : era === "medieval" ? "Medieval" : era === "colonial" ? "Colonial" : "Modern";
  }

  function getSelectedEras(){
    var out = [];
    eraCheckboxes.forEach(function(c){ if(c.checked) out.push(c.value); });
    return out.length ? out : ["ancient","medieval","colonial","modern"];
  }
  function getSelectedLength(){
    var val = 10;
    lengthRadios.forEach(function(r){ if(r.checked) val = parseInt(r.value, 10); });
    return val;
  }

  function startQuiz(){
    var eras = getSelectedEras();
    var len = getSelectedLength();
    var pool = shuffle(bank.filter(function(q){ return eras.indexOf(q.era) !== -1; }));
    var questions = pool.slice(0, Math.min(len, pool.length));
    state = {
      questions: questions,
      index: 0,
      score: 0,
      answered: false,
      perEra: {}
    };
    questions.forEach(function(q){
      if(!state.perEra[q.era]) state.perEra[q.era] = { correct:0, total:0 };
    });
    showScreen("play");
    renderQuestion();
  }

  function renderQuestion(){
    var q = state.questions[state.index];
    state.answered = false;
    nextBtn.hidden = true;
    explainEl.hidden = true;
    explainEl.textContent = "";
    progressEl.textContent = "Question " + (state.index + 1) + " of " + state.questions.length;
    progressBar.style.width = ((state.index) / state.questions.length * 100) + "%";
    eraTagEl.textContent = eraLabel(q.era);
    eraTagEl.className = "chip quiz-era-chip quiz-era-chip--" + q.era;
    promptEl.textContent = q.q;
    optionsEl.innerHTML = "";

    var optOrder = shuffle(q.options.map(function(text, i){ return { text:text, isCorrect:i === q.correct }; }));

    optOrder.forEach(function(opt){
      var btn = document.createElement("button");
      btn.className = "quiz-option";
      btn.type = "button";
      btn.textContent = opt.text;
      btn.addEventListener("click", function(){ selectOption(btn, opt, q); });
      optionsEl.appendChild(btn);
    });
  }

  function selectOption(btn, opt, q){
    if(state.answered) return;
    state.answered = true;
    state.perEra[q.era].total++;

    var buttons = optionsEl.querySelectorAll(".quiz-option");
    buttons.forEach(function(b){ b.disabled = true; });

    if(opt.isCorrect){
      btn.classList.add("is-correct");
      state.score++;
      state.perEra[q.era].correct++;
    } else {
      btn.classList.add("is-wrong");
      buttons.forEach(function(b){
        if(b.textContent === q.options[q.correct]) b.classList.add("is-correct");
      });
    }

    if(q.explain){
      explainEl.innerHTML = '<strong>' + (opt.isCorrect ? "Right \u2014 " : "Not quite \u2014 ") + '</strong>' + q.explain;
      explainEl.className = "quiz-explain " + (opt.isCorrect ? "quiz-explain--correct" : "quiz-explain--wrong");
      explainEl.hidden = false;
    }

    nextBtn.hidden = false;
    nextBtn.focus();
  }

  function nextQuestion(){
    state.index++;
    if(state.index >= state.questions.length){
      showResults();
    } else {
      renderQuestion();
    }
  }

  function showResults(){
    showScreen("results");
    var total = state.questions.length;
    var pct = total ? Math.round((state.score / total) * 100) : 0;
    scoreLine.textContent = state.score + " / " + total + " correct  (" + pct + "%)";

    var grade;
    if(pct >= 90) grade = "Distinction \u2014 you could set the paper.";
    else if(pct >= 75) grade = "First Class \u2014 strong command of the material.";
    else if(pct >= 60) grade = "Second Class \u2014 solid, with a few gaps to close.";
    else if(pct >= 40) grade = "Pass \u2014 worth another pass through the chronicles.";
    else grade = "Needs revision \u2014 start back at the beginning of each chronicle.";
    gradeLine.textContent = grade;

    // Best-score tracking (per device, via localStorage)
    var best = getBest();
    var isNewBest = !best || pct > best.pct || (pct === best.pct && total > best.total);
    if(isNewBest && total > 0){
      best = {
        score: state.score, total: total, pct: pct,
        date: new Date().toLocaleDateString(undefined, { year:"numeric", month:"short", day:"numeric" })
      };
      setBest(best);
      bestLine.textContent = "\uD83C\uDFC6 New personal best on this device!";
      bestLine.hidden = false;
    } else if(best){
      bestLine.textContent = "Personal best on this device: " + best.score + "/" + best.total + " (" + best.pct + "%), set " + best.date + ".";
      bestLine.hidden = false;
    } else {
      bestLine.hidden = true;
    }

    try{
      var attempt={era:"all",eraLabel:"Cross-era",score:state.score,total:total,pct:pct,date:new Date().toISOString()};
      if(window.ChronicleStudy&&window.ChronicleStudy.recordQuiz)window.ChronicleStudy.recordQuiz(attempt);
      else{var saved=JSON.parse(localStorage.getItem("chronicle-study-v1")||"{}");saved.quizAttempts=Array.isArray(saved.quizAttempts)?saved.quizAttempts:[];saved.quizAttempts.unshift(Object.assign({at:Date.now()},attempt));saved.quizAttempts=saved.quizAttempts.slice(0,100);saved.updatedAt=Date.now();localStorage.setItem("chronicle-study-v1",JSON.stringify(saved));}
    }catch(e){}

    breakdownEl.innerHTML = "";
    ["ancient","medieval","colonial","modern"].forEach(function(era){
      var d = state.perEra[era];
      if(!d || !d.total) return;
      var row = document.createElement("div");
      row.className = "quiz-bd-row";
      var rowPct = Math.round((d.correct / d.total) * 100);
      row.innerHTML =
        '<span class="quiz-bd-label">' + eraLabel(era) + '</span>' +
        '<span class="quiz-bd-track"><span class="quiz-bd-fill quiz-bd-fill--' + era + '" style="width:' + rowPct + '%"></span></span>' +
        '<span class="quiz-bd-value">' + d.correct + '/' + d.total + '</span>';
      breakdownEl.appendChild(row);
    });
  }

  startBtn.addEventListener("click", startQuiz);
  nextBtn.addEventListener("click", nextQuestion);
  retryBtn.addEventListener("click", function(){ showScreen("setup"); });

  showScreen("setup");
})();
