// Chronicle of Bharat — glossary data. Shared by: auto-tooltips on the
// chronicle pages, glossary.html, flashcards.html, and site search.
window.GLOSSARY = [
  // ---------- ANCIENT ----------
  { term:"Varna", era:"ancient", def:"The four-fold social classification — Brahmin, Kshatriya, Vaishya, Shudra — that hardened into a rigid hierarchy during the Later Vedic period." },
  { term:"Janapada", era:"ancient", def:"A territorial kingdom that replaced fluid tribal clans as Vedic society settled into surplus agriculture." },
  { term:"Gana-sangha", era:"ancient", def:"A non-monarchical, oligarchic republic — such as Vajji or Malla — governed by an assembly rather than a king." },
  { term:"Sramana", era:"ancient", def:"An ascetic movement, notably Buddhism and Jainism, that rejected Vedic ritual, animal sacrifice, and hereditary priesthood." },
  { term:"Saptanga", era:"ancient", def:"Kautilya's seven-limb theory of the state in the Arthashastra: sovereign, officials, territory, fortifications, treasury, army, and allies." },
  { term:"Dhamma", era:"ancient", def:"Ashoka's policy of moral governance, non-violence, and religious tolerance, adopted after the Kalinga War and carved onto rock and pillar edicts." },
  { term:"Agrahara", era:"ancient", def:"A tax-free land grant made to Brahmins or religious institutions, central to the 'Indian Feudalism' historiographical debate." },
  { term:"Yajna", era:"ancient", def:"A Vedic ritual fire-sacrifice, central to Early Vedic religious life before the rise of Upanishadic philosophy." },
  { term:"Meluhha", era:"ancient", def:"The name Mesopotamian cuneiform records used for the Indus Valley trading region." },
  { term:"Mahajanapada", era:"ancient", def:"One of sixteen major territorial states that emerged in the central Gangetic valley during the Second Urbanisation, c. 600 BCE." },

  // ---------- MEDIEVAL ----------
  { term:"Iqta", era:"medieval", def:"A non-hereditary, regularly rotated land-revenue assignment used by the Delhi Sultanate to fund military commanders without creating hereditary fiefdoms." },
  { term:"Muqti", era:"medieval", def:"The holder of an Iqta (also called an Iqtadar), responsible for collecting revenue and maintaining troops for imperial service." },
  { term:"Fawazil", era:"medieval", def:"The surplus revenue an Iqtadar was required to remit to the Sultanate's imperial treasury." },
  { term:"Zabt", era:"medieval", def:"Alauddin Khalji's system of direct land measurement for setting revenue demand, replacing loose estimates." },
  { term:"Diwan", era:"medieval", def:"An executive ministry of the Delhi Sultanate's central bureaucracy, such as the Diwan-i-Wizarat (finance) or Diwan-i-Arz (military)." },
  { term:"Mansabdari", era:"medieval", def:"The Mughal system ranking every military and civil officer on a dual numerical scale (Zat and Sawar)." },
  { term:"Sawar", era:"medieval", def:"The half of a Mansabdar's rank specifying exactly how many cavalry and horses he had to maintain for the state." },
  { term:"Jagirdari", era:"medieval", def:"The Mughal system of non-hereditary land-revenue assignments (Jagirs), paid to Mansabdars and periodically rotated." },
  { term:"Dahsala", era:"medieval", def:"Akbar's land-revenue settlement system, setting tax on a ten-year average of crop yield and market price." },
  { term:"Sulh-i-Kul", era:"medieval", def:"Akbar's policy of 'universal peace' — religious tolerance, abolition of the Jizya, and interfaith dialogue at the Ibadat Khana." },
  { term:"Be-jagiri", era:"medieval", def:"The early 18th-century crisis in which the Mughal Empire had appointed more Mansabdars than it had revenue-yielding land to pay them with." },
  { term:"Nayankara", era:"medieval", def:"The Vijayanagara system of assigning territory (Amaram) to military commanders (Nayakas) in exchange for cavalry and tribute." },
  { term:"Chauth", era:"medieval", def:"A 25% revenue levy extracted by the Marathas under Shivaji from Mughal-held territory in the Deccan." },
  { term:"Sardeshmukhi", era:"medieval", def:"An additional 10% Maratha revenue levy, collected alongside Chauth." },
  { term:"Silsila", era:"medieval", def:"A Sufi spiritual lineage or order — such as the Chishti, Suhrawardi, Qadiri, or Naqshbandi." },
  { term:"Bhakti", era:"medieval", def:"A devotional movement spanning two streams: Nirguna (a formless divine, rejecting caste) and Saguna (a manifest divine, such as Krishna or Rama)." },
  { term:"Khanqah", era:"medieval", def:"A Sufi hospice offering food and shelter to anyone regardless of social background, central to the Chishti order's inclusive ethos." },
  { term:"Charbagh", era:"medieval", def:"The quadripartite, symmetrical Persian-style garden layout adopted in Mughal architecture, seen at the Taj Mahal and Humayun's Tomb." },

  // ---------- COLONIAL ----------
  { term:"Diwani", era:"colonial", def:"The right to collect land revenue and administer civil justice, granted to the East India Company over Bengal, Bihar and Orissa by the 1765 Treaty of Allahabad." },
  { term:"Dastak", era:"colonial", def:"A duty-free trade pass; Company servants' abuse of dastaks for private trade helped trigger the conflict leading to the Battle of Plassey." },
  { term:"Doctrine of Lapse", era:"colonial", def:"Governor-General Dalhousie's policy of annexing any princely state under Company paramountcy whose ruler died without a natural male heir." },
  { term:"Subsidiary Alliance", era:"colonial", def:"Governor-General Wellesley's system requiring princely states to disband their armies and host a Company garrison, in exchange for surrendering foreign-policy independence." },
  { term:"Permanent Settlement", era:"colonial", def:"Lord Cornwallis's 1793 land-revenue system fixing Bengal's tax demand forever and converting zamindars into absolute private landowners." },
  { term:"Ryotwari", era:"colonial", def:"A direct revenue contract between the colonial state and individual cultivators, used in the Madras and Bombay presidencies." },
  { term:"Mahalwari", era:"colonial", def:"A land-revenue system assessing tax on the village community (mahal) collectively, used in the North-Western Provinces and Punjab." },
  { term:"Drain of Wealth", era:"colonial", def:"Dadabhai Naoroji's theory that a share of India's annual wealth was systematically transferred to Britain via Home Charges, unrequited exports, and remittances." },
  { term:"Home Charges", era:"colonial", def:"Expenditures paid in London out of Indian revenue, including railway and public-debt interest, pensions, and India Office administrative costs." },
  { term:"Deindustrialization", era:"colonial", def:"The contested decline of India's traditional manufacturing sector under colonial trade policy, explained differently by the Nationalist, Neoclassical, and Macroeconomic historiographical schools." },
  { term:"Food Entitlement Decline", era:"colonial", def:"Amartya Sen's model arguing that famines are political-economic failures of purchasing power to access food, not simply an absolute food-availability decline." },
  { term:"Dyarchy", era:"colonial", def:"The 1919 system splitting provincial government into elected-minister \"Transferred\" subjects and Governor-controlled \"Reserved\" subjects." },
  { term:"Jama / Hasil", era:"colonial", def:"The assessed Mughal revenue demand (jama) versus the revenue actually collected (hasil) — the widening gap Irfan Habib traces through 18th-century decline." },

  // ---------- MODERN ----------
  { term:"Instrument of Accession", era:"modern", def:"The legal document by which a princely state's ruler joined the Indian Union after 1947." },
  { term:"Police Action", era:"modern", def:"The Indian government's official framing of the September 1948 Hyderabad military intervention (Operation Polo), chosen to avoid UN Security Council involvement." },
  { term:"Panchsheel", era:"modern", def:"The five principles of peaceful coexistence agreed between India and China in 1954, covering sovereignty and non-interference." },
  { term:"Non-Alignment", era:"modern", def:"India's Cold War foreign policy of refusing formal military alliance with either the US or Soviet bloc." },
  { term:"HYV", era:"modern", def:"High-Yielding Variety seeds — the semi-dwarf wheat and rice strains central to the Green Revolution." },
  { term:"PL-480", era:"modern", def:"A United States food aid program that India depended on before the Green Revolution reduced its food-import dependence." },
  { term:"No First Use", era:"modern", def:"India's nuclear doctrine, adopted after Pokhran-II, committing to never be the first to use nuclear weapons in a conflict." },
  { term:"LPG reforms", era:"modern", def:"Liberalisation, Privatisation, Globalisation — the three pillars of India's 1991 New Economic Policy." },
  { term:"MRTP Act", era:"modern", def:"The Monopolies and Restrictive Trade Practices Act, whose mandatory clearances were dismantled during the 1991 reforms." },
  { term:"Mandal Commission", era:"modern", def:"A commission whose recommendations, implemented in 1990, extended constitutional reservations to Other Backward Classes (OBCs)." },
  { term:"Sarva Dharma Sambhava", era:"modern", def:"India's model of secularism — equal, neutral respect for all religions rather than strict separation of religion and state." }
];
