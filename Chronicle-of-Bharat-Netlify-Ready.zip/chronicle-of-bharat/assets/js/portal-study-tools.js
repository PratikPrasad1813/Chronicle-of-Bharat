/* Era-filtered study tools for the Colonial India and Post-Independence portals. */
(function(){
  'use strict';
  var body=document.body,era=body&&body.getAttribute('data-era'),tool=body&&body.getAttribute('data-study');
  if(!body||!tool||!era)return;
  var names={colonial:'Colonial India',modern:'Post-Independence India'};
  var portal=era==='colonial'?'colonial-india':'modern-india';
  var accent=era==='colonial'?'Colonial':'Republic';
  var ranges={colonial:'c. 1707–1947 CE',modern:'1947 CE – Present'};
  var chapters={
    colonial:[['Mughal Decline','mughal-decline.html'],['Company Raj','company-raj.html'],['The Great Rebellion','the-great-rebellion.html'],['Deindustrialisation','deindustrialisation-debate.html'],['Land & Famine','land-and-famine.html'],['Resistance & Reform','resistance-and-reform.html'],['Steel Frame & Partition','steel-frame-and-partition.html']],
    modern:[['Princely Integration','princely-states.html'],['Planning & Nonalignment','nehruvian-planning.html'],['Green Revolution','green-revolution.html'],['Pokhran-I (1974)','pokhran-1974.html'],['Pokhran-II (1998)','pokhran-1998.html'],['The 1991 Reforms','reforms-1991.html'],['Caste & Secularism','caste-secularism.html']]
  };
  var meta={
    colonial:{
      timeline:{title:'A century in motion',lead:'Trace the turning points from Mughal fragmentation through Company rule, resistance, Crown rule and Partition.',heading:'Power, extraction, resistance, rupture',aside:'A chronological spine for an era that moved through political change, uneven economic transformation and mass mobilisation.',kicker:'The colonial chronology'},
      map:{title:'A terrain of power',lead:'Place battles, capitals, uprisings and regional economies on the map that shaped colonial India.',heading:'Where the story took place',aside:'Select a site on the map or in the list to connect geography with the decisions, conflicts and movements studied in this portal.',kicker:'The colonial atlas'},
      glossary:{title:'The language of empire',lead:'A concise, searchable lexicon for the institutions, land systems and arguments that recur across the colonial chapters.',heading:'Terms that carry the argument',aside:'Filter by letter or search a definition. Each entry is paired with a related chapter for a quick return to context.',kicker:'The colonial glossary'},
      flashcards:{title:'Recall the terms',lead:'Build quick, active recall around the vocabulary of Company rule, revenue, resistance and colonial political economy.',heading:'Turn recognition into recall',aside:'Flip each card to reveal its definition. Use the controls to review in sequence, shuffle the deck or return to a difficult term.',kicker:'The revision deck'},
      quiz:{title:'The examiner’s table',lead:'Test whether you can connect chronology, policy and consequence across the colonial era—not just recall a date.',heading:'A short paper in colonial history',aside:'Choose a question set, answer at your own pace, and read the explanation after each response.',kicker:'The colonial examination'},
      notes:{title:'A revision ledger',lead:'A structured review of the period’s core transitions, economic debates, resistance movements and route to Partition.',heading:'Keep the argument in view',aside:'Use the printable outline to revise themes and build an answer around cause, mechanism, evidence and consequence.',kicker:'The revision ledger'},
      dynasties:{title:'How authority changed hands',lead:'Follow the institutional hand-offs that transformed a trading company into an imperial state, then brought the Raj to an end.',heading:'Institutions, not dynasties',aside:'This portal’s political-succession view follows offices, legal frameworks and transfers of sovereignty rather than royal family trees.',kicker:'Dynasty Trees'}
    },
    modern:{
      timeline:{title:'The republic, in motion',lead:'Follow the major milestones from Independence and integration to planning, food security, nuclear doctrine and economic reform.',heading:'A republic across turning points',aside:'Use chronology to connect the decisions of one generation to the institutions, debates and policy choices inherited by the next.',kicker:'The republic’s chronology'},
      map:{title:'A republic on the map',lead:'Locate the places where political integration, food policy, nuclear strategy and the post-1991 economy took shape.',heading:'Where policy meets place',aside:'Select a site to see its role in the chapter sequence. The markers are drawn from the portal’s own site atlas.',kicker:'The post-Independence atlas'},
      glossary:{title:'The republic’s vocabulary',lead:'A focused glossary for the legal, political, economic and social concepts that shape the post-Independence chapters.',heading:'The words behind the institutions',aside:'Search or browse alphabetically, then follow a term back into the chapter where its context matters.',kicker:'The post-Independence glossary'},
      flashcards:{title:'Recall the turning points',lead:'Use active recall to revisit the language of integration, non-alignment, food security, nuclear doctrine and reform.',heading:'Review with active recall',aside:'Flip a card to reveal its definition. Change the order or move through the deck at your own pace.',kicker:'The republic’s revision deck'},
      quiz:{title:'The republic’s examination hall',lead:'Check your grasp of integration, the Constitution, planning, the Green Revolution, nuclear policy and the 1991 reforms.',heading:'Make connections, not just guesses',aside:'Choose a short or full question set. Each answer includes a brief explanation to reinforce the underlying idea.',kicker:'The post-Independence examination'},
      notes:{title:'A revision fieldbook',lead:'A compact guide to the republic’s institutional choices, policy shifts and unresolved questions.',heading:'A map of the main arguments',aside:'Print or download the outline, then use the chapter links to deepen any section that needs more evidence.',kicker:'The revision fieldbook'},
      dynasties:{title:'Leadership, law and the republic',lead:'Read political succession through constitutional institutions, not dynastic inheritance: the authority, offices and policy eras of a republic.',heading:'A succession of public institutions',aside:'The timeline foregrounds constitutional authority and policy phases, offering a better fit for republican India than a royal family tree.',kicker:'Institutions & leadership'}
    }
  };
  var pageMeta=(meta[era]&&meta[era][tool])||meta.colonial.timeline;
  function $(sel,root){return (root||document).querySelector(sel);}
  function make(tag,className,text){var n=document.createElement(tag);if(className)n.className=className;if(text!==undefined&&text!==null)n.textContent=String(text);return n;}
  function append(parent,child){if(child)parent.appendChild(child);return child;}
  function setText(sel,value){var n=$(sel);if(n)n.textContent=value;}
  function slug(s){return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'');}
  function chapterFor(subject){
    var maps=era==='colonial'?
      [[/decline|Nadir|Mughal|jama|hasil/i,'mughal-decline.html'],[/Plassey|Buxar|Diwani|Company|dastak|Wellesley/i,'company-raj.html'],[/rebellion|1857|sepoy|Meerut/i,'the-great-rebellion.html'],[/deindustrial|manufactur|drain of wealth/i,'deindustrialisation-debate.html'],[/famine|revenue|Permanent Settlement|Ryotwari|Mahalwari/i,'land-and-famine.html'],[/resistance|Santhal|Munda|Indigo|reform/i,'resistance-and-reform.html'],[/Partition|Cabinet Mission|Constitution|ICS|Crown rule/i,'steel-frame-and-partition.html']]:
      [[/accession|Hyderabad|Integration|Constitution|Polo/i,'princely-states.html'],[/Non-Alignment|Panchsheel|Nehru|planning|Sino-Indian/i,'nehruvian-planning.html'],[/Green Revolution|HYV|food aid|PL-480/i,'green-revolution.html'],[/Smiling Buddha|1974|Pokhran-I/i,'pokhran-1974.html'],[/Pokhran-II|1998|No First Use|nuclear/i,'pokhran-1998.html'],[/LPG|1991|MRTP|reform|privatisation|liberalisation/i,'reforms-1991.html'],[/Mandal|caste|secular|Sarva Dharma/i,'caste-secularism.html']];
    var text=String(subject||'');
    for(var i=0;i<maps.length;i++)if(maps[i][0].test(text))return maps[i][1];
    return chapters[era][0][1];
  }
  function chapterLink(subject,label){var a=make('a','study-inline-link',label||'Read the related chapter →');a.href=chapterFor(subject);return a;}
  function setHero(){
    document.title=pageMeta.title+' · '+names[era]+' — Chronicle of Bharat';
    setText('[data-study-kicker]',pageMeta.kicker+' · '+names[era]);
    setText('[data-study-title]',pageMeta.title);
    setText('[data-study-lede]',pageMeta.lead);
    setText('[data-study-range]',ranges[era]);
    setText('[data-study-heading]',pageMeta.heading);
    setText('[data-study-aside]',pageMeta.aside);
    setText('[data-study-label]',names[era]+' · Study companion');
    var menu=$('.study-tools-nav');if(menu){menu.querySelectorAll('a').forEach(function(a){if(a.dataset.tool===tool){a.setAttribute('aria-current','page');}});}
  }
  function mount(){var n=$('#study-app');if(n)n.textContent='';return n;}
  function countChip(text){setText('[data-study-count]',text);}

  function renderGlossary(root){
    var terms=(window.GLOSSARY||[]).filter(function(t){return t.era===era;}).slice().sort(function(a,b){return a.term.localeCompare(b.term);});
    countChip(terms.length+' terms');
    var toolbar=make('div','study-toolbar');
    var field=make('div','study-field');var label=make('label',null,'Search definitions');label.htmlFor='term-search';var input=make('input','study-input');input.id='term-search';input.type='search';input.placeholder='Try “Diwani” or “Mandal”';input.autocomplete='off';append(field,label);append(field,input);append(toolbar,field);
    var count=make('p','study-toolbar__count');append(toolbar,count);append(root,toolbar);
    var letters=make('div','study-toolbar');var letterGroup=make('div','study-chip-row');var current='';
    var all=make('button','study-chip','All letters');all.type='button';all.setAttribute('aria-pressed','true');all.dataset.letter='';append(letterGroup,all);
    'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').forEach(function(letter){if(!terms.some(function(t){return t.term.toUpperCase().charAt(0)===letter;}))return;var b=make('button','study-chip',letter);b.type='button';b.dataset.letter=letter;b.setAttribute('aria-pressed','false');append(letterGroup,b);});
    append(letters,letterGroup);append(root,letters);
    var grid=make('div','term-grid');append(root,grid);
    function draw(){
      var q=input.value.trim().toLowerCase();grid.textContent='';
      var visible=terms.filter(function(t){return (!current||t.term.toUpperCase().indexOf(current)===0)&&(!q||(t.term+' '+t.def).toLowerCase().indexOf(q)!==-1);});
      count.textContent=visible.length+' / '+terms.length+' TERMS';
      if(!visible.length){append(grid,make('p','study-empty','No terms match this search. Try another keyword or letter.'));return;}
      visible.forEach(function(t){
        var card=make('article','term-card');card.id='term-'+slug(t.term);
        var eraText=make('p','term-card__era',names[era]+' · field note');var h=make('h3',null,t.term);var d=make('p',null,t.def);append(card,eraText);append(card,h);append(card,d);append(card,chapterLink(t.term));append(grid,card);
      });
    }
    input.addEventListener('input',draw);
    letterGroup.addEventListener('click',function(e){var b=e.target.closest('button[data-letter]');if(!b)return;current=b.dataset.letter;letterGroup.querySelectorAll('button').forEach(function(x){x.setAttribute('aria-pressed',String(x===b));});draw();});
    draw();
  }

  function renderTimeline(root){
    var events=(window.TIMELINE_EVENTS||[]).filter(function(e){return e.era===era;}).slice().sort(function(a,b){return a.sortKey-b.sortKey;});
    countChip(events.length+' milestones');
    var toolbar=make('div','study-toolbar');var field=make('div','study-field');var label=make('label',null,'Find a milestone');label.htmlFor='timeline-search';var input=make('input','study-input');input.type='search';input.id='timeline-search';input.placeholder='Search dates, people or policies';input.autocomplete='off';append(field,label);append(field,input);append(toolbar,field);var count=make('p','study-toolbar__count');append(toolbar,count);append(root,toolbar);
    var list=make('div','study-timeline');append(root,list);
    function draw(){var q=input.value.trim().toLowerCase();list.textContent='';var visible=events.filter(function(e){return (e.date+' '+e.title+' '+e.body).toLowerCase().indexOf(q)!==-1;});count.textContent=visible.length+' / '+events.length+' MILESTONES';if(!visible.length){append(list,make('p','study-empty','No milestones match that search.'));return;}
      visible.forEach(function(e,i){var card=make('article','study-event');card.id='milestone-'+slug(e.title);var date=make('p','study-event__date',e.date);var detail=make('div','study-event__content');var title=make('h3',null,e.title);var bodyText=make('p','study-event__body',e.body);append(detail,title);append(detail,bodyText);var route=chapterFor(e.title+' '+e.body);if(route){var link=make('a','study-event__link','Open the related chapter →');link.href=route;append(detail,link);}append(card,date);append(card,detail);card.style.animationDelay=Math.min(i*24,280)+'ms';append(list,card);});}
    input.addEventListener('input',draw);draw();
  }

  function renderAtlas(root){
    var sites=(window.MAP_SITES||[]).filter(function(s){return s.era===era;});
    countChip(sites.length+' mapped places');
    if(!sites.length){append(root,make('p','study-empty','The site atlas could not load.'));return;}
    var layout=make('div','atlas-layout');var mapCard=make('div','atlas-map-card');var mapWrap=make('div','atlas-map-wrap');
    var geo=window.INDIA_GEO||{};var vbw=geo.proj&&geo.proj.VBW||1000;var vbh=geo.proj&&geo.proj.VBH||1000;
    if(geo.featureHref){
      var ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 '+vbw+' '+vbh);svg.setAttribute('class','atlas-map-svg');svg.setAttribute('role','img');svg.setAttribute('aria-label','Map of India with state and Union Territory boundaries and '+names[era]+' history sites');
      var title=document.createElementNS(ns,'title');title.textContent='India — state and Union Territory boundaries';svg.appendChild(title);
      var desc=document.createElementNS(ns,'desc');desc.textContent='Administrative regions shown: '+(geo.regionNames||[]).join(', ')+'. Map geometry from Simplemaps.com.';svg.appendChild(desc);
      var country=document.createElementNS(ns,'use');country.setAttribute('class','country');country.setAttribute('href',geo.featureHref);country.setAttributeNS('http://www.w3.org/1999/xlink','xlink:href',geo.featureHref);svg.appendChild(country);
      append(mapWrap,svg);
    }else{append(mapWrap,make('div','study-empty','Map outline unavailable. See the location index beside it.'));}
    var pins=[];
    sites.forEach(function(site,i){
      var pt=window.projectLonLat?window.projectLonLat(site.lon,site.lat):{x:vbw/2,y:vbh/2};
      var pin=make('button','map-pin');pin.type='button';pin.style.left=(pt.x/vbw*100)+'%';pin.style.top=(pt.y/vbh*100)+'%';pin.setAttribute('aria-label','Show '+site.name);pin.setAttribute('aria-pressed','false');
      var tag=make('span','map-pin__label',site.name);append(pin,tag);pin.addEventListener('click',function(){select(i);});append(mapWrap,pin);pins.push(pin);
    });
    append(mapCard,mapWrap);var caption=make('div','atlas-map-caption');append(caption,make('span','',names[era]));append(caption,make('span','','Select a marker'));append(mapCard,caption);
    var credit=make('p','atlas-map-credit');credit.appendChild(document.createTextNode('Map geometry © 2024 Pareto Software, LLC DBA '));
    var creditSite=make('a',null,'Simplemaps.com');creditSite.href='https://simplemaps.com';creditSite.target='_blank';creditSite.rel='noopener noreferrer';append(credit,creditSite);
    credit.appendChild(document.createTextNode(' · Free for commercial and personal use under '));
    var creditLicense=make('a',null,'the Simplemaps SVG license');creditLicense.href='https://simplemaps.com/resources/svg-license';creditLicense.target='_blank';creditLicense.rel='noopener noreferrer';append(credit,creditLicense);
    credit.appendChild(document.createTextNode(' (attribution appreciated).'));append(mapCard,credit);
    var listCard=make('div','atlas-list-card');var detail=make('div','atlas-detail');var siteList=make('div','atlas-sites');append(listCard,detail);append(listCard,siteList);
    var siteButtons=[];
    sites.forEach(function(site,i){var row=make('button','atlas-site');row.type='button';row.setAttribute('aria-pressed','false');var number=make('span','atlas-site__num',String(i+1).padStart(2,'0'));var name=make('span','atlas-site__name',site.name);var arrow=make('span','atlas-site__arrow','↗');append(row,number);append(row,name);append(row,arrow);row.addEventListener('click',function(){select(i);});append(siteList,row);siteButtons.push(row);});
    function select(index){var s=sites[index];pins.forEach(function(p,i){p.classList.toggle('is-active',i===index);p.setAttribute('aria-pressed',String(i===index));});siteButtons.forEach(function(p,i){p.classList.toggle('is-active',i===index);p.setAttribute('aria-pressed',String(i===index));});detail.textContent='';append(detail,make('p','atlas-detail__kicker',names[era]+' · mapped place'));append(detail,make('h3',null,s.name));append(detail,make('p',null,s.blurb));var coord=make('span','atlas-detail__coords',s.lat.toFixed(3)+'° N  ·  '+s.lon.toFixed(3)+'° E');append(detail,coord);}
    append(layout,mapCard);append(layout,listCard);append(root,layout);select(0);
  }

  function renderFlashcards(root){
    var deck=(window.GLOSSARY||[]).filter(function(t){return t.era===era;}).slice();
    if(!deck.length){append(root,make('p','study-empty','No flashcards available yet.'));return;}
    countChip(deck.length+' cards');var wrap=make('div','flashcard-layout');var progress=make('div','flash-progress');var fill=make('span');append(progress,fill);append(wrap,progress);
    var card=make('button','study-flashcard');card.type='button';card.setAttribute('aria-label','Flip flashcard');var inner=make('span','study-flashcard__inner');var front=make('span','study-flashcard__face study-flashcard__face--front');var back=make('span','study-flashcard__face study-flashcard__face--back');append(front,make('span','study-flashcard__index','Term · 01'));append(front,make('span','study-flashcard__term',''));append(front,make('span','study-flashcard__hint','Activate to reveal definition'));append(back,make('span','study-flashcard__index','Definition'));append(back,make('span','study-flashcard__definition',''));append(back,make('span','study-flashcard__hint','Activate to return'));append(inner,front);append(inner,back);append(card,inner);append(wrap,card);
    var controls=make('div','flash-controls');var prev=make('button','study-action study-action--outline','← Previous');prev.type='button';var flip=make('button','study-action','Reveal definition');flip.type='button';var next=make('button','study-action study-action--outline','Next →');next.type='button';var shuffle=make('button','study-action study-action--outline','Shuffle deck');shuffle.type='button';append(controls,prev);append(controls,flip);append(controls,next);append(controls,shuffle);append(wrap,controls);
    var status=make('p','study-toolbar__count');status.style.textAlign='center';append(wrap,status);append(root,wrap);var index=0;
    function draw(){var term=deck[index];card.classList.remove('is-flipped');front.querySelector('.study-flashcard__index').textContent='Term · '+String(index+1).padStart(2,'0');front.querySelector('.study-flashcard__term').textContent=term.term;back.querySelector('.study-flashcard__definition').textContent=term.def;status.textContent='CARD '+(index+1)+' OF '+deck.length;fill.style.width=((index+1)/deck.length*100)+'%';flip.textContent='Reveal definition';card.setAttribute('aria-label','Flashcard '+(index+1)+' of '+deck.length+': '+term.term+'. Activate to reveal the definition.');}
    function flipCard(){var on=card.classList.toggle('is-flipped');flip.textContent=on?'Show term':'Reveal definition';}
    prev.addEventListener('click',function(){index=(index-1+deck.length)%deck.length;draw();});next.addEventListener('click',function(){index=(index+1)%deck.length;draw();});flip.addEventListener('click',flipCard);card.addEventListener('click',flipCard);shuffle.addEventListener('click',function(){for(var i=deck.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var tmp=deck[i];deck[i]=deck[j];deck[j]=tmp;}index=0;draw();});draw();
  }

  function renderQuiz(root){
    var bank=(window.QUIZ_BANK||[]).filter(function(q){return q.era===era;});
    countChip(bank.length+' questions');if(!bank.length){append(root,make('p','study-empty','The quiz bank could not load.'));return;}
    var panel=make('section','study-quiz-card');var setup=make('div','quiz-setup');append(setup,make('p','study-label',names[era]+' · challenge settings'));append(setup,make('h3','',era==='colonial'?'How well do you know the Raj?':'How well do you know the republic?'));
    var intro=make('p','power-intro','Choose a set length. Questions are drawn from the portal’s chapter themes, and each answer includes a short explanation.');append(setup,intro);
    var group=make('div','study-toolbar');group.setAttribute('role','group');group.setAttribute('aria-label','Choose quiz length');
    [[5,'5 questions'],[10,'10 questions'],['all','Full set · '+bank.length]].forEach(function(opt,i){var label=make('label','study-chip',opt[1]);label.style.cursor='pointer';var radio=document.createElement('input');radio.type='radio';radio.name='quiz-length';radio.value=String(opt[0]);radio.style.accentColor='var(--study-accent)';radio.style.marginRight='.4rem';if(i===1)radio.checked=true;label.prepend(radio);append(group,label);});
    append(setup,group);var start=make('button','study-action','Begin the challenge →');start.type='button';append(setup,start);append(panel,setup);
    var play=make('div','quiz-play');play.hidden=true;var top=make('div','study-quiz-top');var prog=make('span','study-quiz-progress');var score=make('span','study-quiz-score','Score · 0');append(top,prog);append(top,score);append(play,top);var track=make('div','study-progress');var bar=make('span');append(track,bar);append(play,track);var question=make('h3','study-question');append(play,question);var options=make('div','study-options');append(play,options);var explanation=make('p','study-explain');explanation.hidden=true;append(play,explanation);var actions=make('div','study-quiz-actions');var answerNote=make('span','study-quiz-progress','Choose the strongest answer.');var next=make('button','study-action','Next question →');next.type='button';next.hidden=true;append(actions,answerNote);append(actions,next);append(play,actions);append(panel,play);
    var result=make('div','study-results');result.hidden=true;append(panel,result);append(root,panel);
    var run=[],at=0,points=0,missed=[];
    start.addEventListener('click',function(){var selected=panel.querySelector('input[name="quiz-length"]:checked');var n=selected&&selected.value==='all'?bank.length:Number(selected&&selected.value||10);var pool=bank.slice();for(var i=pool.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1));var tmp=pool[i];pool[i]=pool[j];pool[j]=tmp;}run=pool.slice(0,Math.min(n,pool.length));at=0;points=0;missed=[];setup.hidden=true;result.hidden=true;play.hidden=false;drawQuestion();});
    function drawQuestion(){var q=run[at];prog.textContent='QUESTION '+String(at+1).padStart(2,'0')+' / '+run.length;score.textContent='Score · '+points;bar.style.width=(at/run.length*100)+'%';question.textContent=q.q;options.textContent='';explanation.hidden=true;next.hidden=true;answerNote.textContent='Choose the strongest answer.';q.options.forEach(function(text,index){var btn=make('button','study-option');btn.type='button';var letter=make('span','study-option__letter',String.fromCharCode(65+index));var copy=make('span','',text);append(btn,letter);append(btn,copy);btn.addEventListener('click',function(){answer(index,q);});append(options,btn);});}
    function answer(choice,q){if(options.querySelector(':disabled'))return;var correct=choice===q.correct;if(correct)points++;else missed.push({q:q,choice:choice});Array.prototype.forEach.call(options.querySelectorAll('button'),function(btn,index){btn.disabled=true;if(index===q.correct)btn.classList.add('is-correct');if(index===choice&&!correct)btn.classList.add('is-wrong');});score.textContent='Score · '+points;bar.style.width=((at+1)/run.length*100)+'%';explanation.textContent=(correct?'Correct. ':'Not quite. ')+q.explain;explanation.hidden=false;answerNote.textContent=correct?'Good connection.':'Review the distinction.';next.hidden=false;next.textContent=at===run.length-1?'See your result →':'Next question →';}
    next.addEventListener('click',function(){at++;if(at<run.length)drawQuestion();else finish();});
    function finish(){play.hidden=true;result.hidden=false;result.textContent='';var pct=Math.round(points/run.length*100);try{var attempt={era:era,eraLabel:names[era],score:points,total:run.length,pct:pct,date:new Date().toISOString()};if(window.ChronicleStudy&&window.ChronicleStudy.recordQuiz)window.ChronicleStudy.recordQuiz(attempt);else{var saved=JSON.parse(localStorage.getItem('chronicle-study-v1')||'{}');saved.quizAttempts=Array.isArray(saved.quizAttempts)?saved.quizAttempts:[];saved.quizAttempts.unshift(Object.assign({at:Date.now()},attempt));saved.quizAttempts=saved.quizAttempts.slice(0,100);saved.updatedAt=Date.now();localStorage.setItem('chronicle-study-v1',JSON.stringify(saved));}}catch(e){}append(result,make('p','study-label','Paper complete · '+names[era]));append(result,make('h3','',pct>=80?'A strong reading of the era.':pct>=50?'A solid base—now sharpen the links.':'A good place to begin again.'));append(result,make('span','study-results__score',points+' / '+run.length));append(result,make('p','power-intro',points+' correct · '+pct+'% — revisit the explanations below, then return to the relevant chapter.'));
      if(missed.length){var review=make('div','study-results__review');append(review,make('p','study-label','Review the questions to revisit'));missed.forEach(function(m){var d=make('details');var summary=make('summary',null,m.q.q);append(d,summary);append(d,make('p',null,'Correct answer: '+m.q.options[m.q.correct]+'. '+m.q.explain));var a=chapterLink(m.q.q+' '+m.q.explain,'Open the related chapter →');append(d,a);append(review,d);});append(result,review);}else append(result,make('p','study-empty','Every answer was correct. Excellent work.'));
      var again=make('button','study-action','Try another set');again.type='button';again.style.marginTop='1rem';again.addEventListener('click',function(){result.hidden=true;setup.hidden=false;});append(result,again);}
  }

  var revisionNotes={
    colonial:[
      {eyebrow:'01 · State formation',title:'From Mughal fragmentation to Company power',dates:'c. 1707–1765',body:'Political authority did not pass to the Company in a single conquest. The weakening of Mughal central power created room for regional states and commercial intervention; Plassey and Buxar then changed the balance.',points:['Keep the jama–hasil gap and successor-state politics in view when explaining the early eighteenth century.','Separate the Company’s role as a political broker from its later territorial sovereignty.','The 1765 Diwani joined revenue collection to the Company’s military and administrative expansion.']},
      {eyebrow:'02 · Colonial state',title:'A trading corporation becomes a governing power',dates:'1757–1858',body:'The Company’s commercial and political functions increasingly converged. Parliamentary regulation, revenue administration and military expansion turned a private corporation into an imperial state.',points:['Plassey (1757), Buxar (1764) and Diwani (1765) are distinct turning points—not interchangeable milestones.','Regulating Act (1773) and later Acts mark attempts to supervise Company power.','Explain how control over revenue supported political and military authority.']},
      {eyebrow:'03 · Agrarian change',title:'Land systems, revenue and vulnerability',dates:'1793–1943',body:'Colonial land policy reshaped ownership, assessment and the state’s relationship with cultivators. Famine reveals how market access and purchasing power mattered alongside the availability of grain.',points:['Permanent Settlement, Ryotwari and Mahalwari used different units and intermediaries.','Distinguish revenue assessment from the actual collection and social burden.','Use Amartya Sen’s entitlement model to explain why food could move while people starved.']},
      {eyebrow:'04 · Resistance & reform',title:'Many movements, many political languages',dates:'1778–1924',body:'Resistance included tribal, peasant, sepoy, constitutional and social reform movements. Their aims and leadership differed, even when they challenged related structures of coercion and exclusion.',points:['Connect a movement to a specific pressure: land alienation, revenue, forced cultivation, military grievance or social reform.','The 1857 Rebellion brought together diverse actors without producing a single unified programme.','Avoid treating nationalist politics as the only form of resistance.']},
      {eyebrow:'05 · Economic debate',title:'Drain, deindustrialisation and evidence',dates:'Nineteenth century',body:'The economic consequences of empire remain a historiographical argument. Strong answers make each school’s mechanism explicit and weigh regional evidence rather than assuming a single verdict.',points:['Naoroji’s Drain of Wealth centres on transfers such as Home Charges and unrequited exports.','Separate an argument about policy intent from an argument about market outcomes.','Compare nationalist–Marxist, neoclassical–revisionist and macroeconomic explanations.']},
      {eyebrow:'06 · Constitutional route',title:'Concession, mobilisation and Partition',dates:'1885–1947',body:'Constitutional changes widened participation unevenly and against a backdrop of mass politics, communal division and war. Partition was a political outcome, not an inevitable end point.',points:['Trace the changing constitutional framework from provincial dyarchy toward autonomy.','The Cabinet Mission, communal politics and the transfer of power belong in the same explanation.','Separate the legal end of British rule from the human consequences of Partition.']}
    ],
    modern:[
      {eyebrow:'01 · Union making',title:'Accession and the shape of the republic',dates:'1947–1950',body:'Independence left the Union to bring more than 565 princely states into a constitutional framework. Negotiation, legal instruments and selective use of force shaped a difficult process of state formation.',points:['Distinguish accession from the later administrative integration of territories.','Patel and V.P. Menon were central to the political and administrative effort.','The Constitution came into force on 26 January 1950.']},
      {eyebrow:'02 · Development state',title:'Planning, public institutions and non-alignment',dates:'1950s–1960s',body:'The early republic pursued planned development and strategic autonomy while building national institutions. Non-alignment was an effort to retain room for independent policy in a polarised Cold War.',points:['Connect the Five-Year Plans to industrial capacity and public-sector institution building.','Explain non-alignment as a policy choice, not passive neutrality.','The 1962 war exposed the limits of diplomatic positioning without sufficient defence capacity.']},
      {eyebrow:'03 · Food security',title:'The Green Revolution: yield and uneven cost',dates:'Mid-1960s onward',body:'High-yielding varieties, fertiliser, irrigation and procurement raised grain output and reduced dependence on food aid. Benefits concentrated in regions with stronger irrigation and capital access, while environmental costs grew.',points:['Name the package: HYV seeds, fertiliser, irrigation, credit and procurement.','Punjab, Haryana and western Uttar Pradesh saw concentrated gains.','Balance food security against groundwater depletion, soil stress and regional inequality.']},
      {eyebrow:'04 · Strategic autonomy',title:'From Smiling Buddha to Pokhran-II',dates:'1974 & 1998',body:'India’s nuclear programme moved from the 1974 test framed as a peaceful nuclear explosion to the declared weapon tests of 1998 and a doctrine of credible minimum deterrence.',points:['Keep the political context and the stated framing of each test distinct.','Pokhran-II prompted sanctions and a more explicit deterrence debate.','No First Use is a declared doctrine; describe it accurately and in context.']},
      {eyebrow:'05 · Economic reform',title:'The 1991 crisis and the LPG turn',dates:'1991 onward',body:'A severe balance-of-payments crisis forced rapid policy change. Liberalisation, privatisation and globalisation reduced controls and opened the economy, accelerating growth while leaving distributional questions unresolved.',points:['Start with the foreign-exchange crisis and the immediate policy constraint.','Track the License-Permit-Quota Raj and the reforms that dismantled parts of it.','Evaluate services-led growth alongside informality and uneven job creation.']},
      {eyebrow:'06 · Social compact',title:'Caste, representation and secularism',dates:'1990 onward',body:'Mandal-era reservations reshaped representation and party politics. At the same time, arguments over secularism ask how the republic can ensure equal citizenship while engaging with a deeply religious society.',points:['The Mandal Commission’s implementation extended reservations to Other Backward Classes.','Separate formal equality from debates over substantive representation.','Sarva Dharma Sambhava describes equal respect for religions, a distinct approach from strict separation.']}
    ]
  };
  var powerData={
    colonial:[
      {date:'c. 1707–1757',title:'Regional authority rises',body:'Mughal central authority weakens; regional powers and commercial actors negotiate a changing political landscape.',subject:'Mughal Decline'},
      {date:'1757–1765',title:'Company becomes territorial',body:'Plassey, Buxar and the grant of Diwani move the East India Company from influence toward a durable fiscal-military state.',subject:'Plassey Diwani Company Raj'},
      {date:'1773–1858',title:'Company power is regulated—and expanded',body:'Parliamentary Acts seek oversight while the Company extends its reach. The 1857 Rebellion leads to the transfer of rule to the Crown.',subject:'Regulating Act 1857 Crown rule'},
      {date:'1858–1947',title:'Crown rule, constitutional change, transfer',body:'Imperial institutions coexist with reform and resistance. Constitutional concessions, mass mobilisation and the politics of Partition shape the end of the Raj.',subject:'Partition Cabinet Mission constitutional'}
    ],
    modern:[
      {date:'1947–1950',title:'Union and Constitution',body:'Accession, integration and constitution-making turn a newly independent territory into a sovereign republic.',subject:'Integration Constitution'},
      {date:'1950s–1960s',title:'Parliamentary institutions & planning',body:'The republic builds its institutions, pursues planned development and seeks strategic autonomy through non-alignment.',subject:'Nehru planning Non-Alignment'},
      {date:'1960s–1980s',title:'Food security & strategic capacity',body:'The Green Revolution changes agricultural output; the 1974 nuclear test marks a new strategic chapter.',subject:'Green Revolution Smiling Buddha 1974'},
      {date:'1991 onward',title:'Reform and social renegotiation',body:'Economic opening accelerates change while caste, representation, secularism and uneven development remain central public questions.',subject:'LPG reforms Mandal secularism'}
    ]
  };

  function renderNotes(root){
    var notes=revisionNotes[era]||[];countChip(notes.length+' revision themes');
    var toolbar=make('div','study-toolbar');var hint=make('p','study-toolbar__count','PRINT-FRIENDLY · '+notes.length+' THEMES');append(toolbar,hint);var actions=make('div','study-toolbar__group');var print=make('button','study-action study-action--outline','Print / Save as PDF');print.type='button';print.addEventListener('click',function(){window.print();});var download=make('a','study-action','Download notes');download.href='#download-notes';download.download=(era==='colonial'?'colonial-india':'post-independence-india')+'-revision-notes.md';download.addEventListener('click',function(e){e.preventDefault();var text='# '+names[era]+' — revision notes\n\n'+notes.map(function(n){return '## '+n.title+' ('+n.dates+')\n\n'+n.body+'\n\n'+n.points.map(function(p){return '- '+p;}).join('\n')+'\n';}).join('\n');var blob=new Blob([text],{type:'text/markdown;charset=utf-8'});var url=URL.createObjectURL(blob);var a=document.createElement('a');a.href=url;a.download=download.download;document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(url);},1200);});append(actions,print);append(actions,download);append(toolbar,actions);append(root,toolbar);
    var grid=make('div','notes-grid');notes.forEach(function(n){var card=make('article','note-card');append(card,make('p','note-card__eyebrow',n.eyebrow));append(card,make('h3',null,n.title));append(card,make('p',null,n.body));var ul=make('ul');n.points.forEach(function(p){append(ul,make('li',null,p));});append(card,ul);append(card,make('span','note-card__dates',n.dates));append(grid,card);});append(root,grid);
    var close=make('div','study-crosslink');append(close,make('p','',era==='colonial'?'Want the primary narrative? Continue into the seven chapter deep dive.':'Want more context? Continue into the seven chapter post-Independence deep dive.'));var link=make('a','btn btn--solid','Return to the portal →');link.href='index.html';append(close,link);append(root,close);
  }

  function renderPower(root){
    var data=powerData[era]||[];countChip(data.length+' stages');append(root,make('p','power-intro',era==='colonial'?'A quick institutional map: follow where authority sat, how it was justified and the moment it changed hands.':'A republican succession map: track constitutional authority, development priorities and the policy eras that followed.'));
    var track=make('div','power-track');data.forEach(function(step){var card=make('article','power-step');append(card,make('p','power-step__date',step.date));append(card,make('h3',null,step.title));append(card,make('p',null,step.body));append(card,chapterLink(step.subject,'Explore the related chapter →'));append(track,card);});append(root,track);
    var note=make('p','power-note',era==='colonial'?'A useful distinction for essays: a change in the formal sovereign did not instantly change every institution, local relationship or economic structure.':'India is a republic, not a dynasty. This view follows the succession of constitutional frameworks and policy priorities, rather than presenting Prime Ministers as hereditary rulers.');append(root,note);
  }

  setHero();var app=mount();if(!app)return;
  if(tool==='glossary')renderGlossary(app);
  else if(tool==='timeline')renderTimeline(app);
  else if(tool==='map')renderAtlas(app);
  else if(tool==='flashcards')renderFlashcards(app);
  else if(tool==='quiz')renderQuiz(app);
  else if(tool==='notes')renderNotes(app);
  else if(tool==='dynasties')renderPower(app);

  var themeButton=$('.theme-toggle');if(themeButton){themeButton.addEventListener('click',function(){var dark=document.documentElement.getAttribute('data-theme')==='dark';var next=dark?'light':'dark';document.documentElement.setAttribute('data-theme',next);try{localStorage.setItem('chronicle-theme',next);}catch(e){}});}
})();
