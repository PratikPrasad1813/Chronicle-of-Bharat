(function(){
  "use strict";
  var events = (window.TIMELINE_EVENTS || []).slice().sort(function(a,b){ return a.sortKey - b.sortKey; });
  var list = document.getElementById("timeline-list");
  var countEl = document.getElementById("timeline-count");
  var filterBtns = document.querySelectorAll(".tl-filter");
  var activeEra = "all";

  var eraLabel = { ancient:"Ancient", medieval:"Medieval", colonial:"Colonial", modern:"Modern" };

  function render(){
    list.innerHTML = "";
    var shown = events.filter(function(e){ return activeEra === "all" || e.era === activeEra; });
    shown.forEach(function(e, i){
      var li = document.createElement("li");
      li.className = "tl-item tl-item--" + e.era;
      li.innerHTML =
        '<div class="tl-item__dot" aria-hidden="true"></div>' +
        '<div class="tl-item__card">' +
          '<p class="eyebrow">' + e.date + ' \u00b7 ' + eraLabel[e.era] + '</p>' +
          '<h3>' + e.title + '</h3>' +
          '<p class="small">' + e.body + '</p>' +
        '</div>';
      list.appendChild(li);
    });
    countEl.textContent = shown.length + " of " + events.length + " events";
  }

  filterBtns.forEach(function(btn){
    btn.addEventListener("click", function(){
      activeEra = btn.getAttribute("data-filter");
      filterBtns.forEach(function(b){ b.classList.toggle("is-active", b === btn); });
      render();
    });
  });

  render();
})();
