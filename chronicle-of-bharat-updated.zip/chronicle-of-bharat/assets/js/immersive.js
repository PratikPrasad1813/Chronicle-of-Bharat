(function(){
var d=document,R=d.documentElement,reduce=matchMedia('(prefers-reduced-motion: reduce)').matches,fine=matchMedia('(hover:hover)').matches;
var path=location.pathname,page=/ancient(-india|\.html)/.test(path)?'ancient':/medieval(-india|\.html)/.test(path)?'medieval':/colonial(-india|\.html)/.test(path)?'colonial':/modern(-india|\.html)/.test(path)?'modern':'root';
R.classList.add('im');R.setAttribute('data-page',page);
function $(s,c){return [].slice.call((c||d).querySelectorAll(s))}

/* progress bar + cursor glow */
var bar=d.createElement('div');bar.className='im-bar';d.body.appendChild(bar);
var glow=d.createElement('div');glow.className='im-glow';d.body.appendChild(glow);
var mx=innerWidth/2,my=innerHeight/2,gx=mx,gy=my;
addEventListener('mousemove',function(e){mx=e.clientX;my=e.clientY},{passive:true});

/* hero stage: aurora + photo + dust */
var isStudy=false,base=(path.split('/').pop()||'index.html').replace('.html','');
var STUDY={timeline:'Konark Sun Temple wheel',map:'Hampi ruins',glossary:'Nalanda ruins',flashcards:'Ajanta caves paintings',dynasties:'Brihadisvara Temple Thanjavur',notes:'Sanchi Stupa',quiz:'Ashoka pillar Vaishali'};
if(!$('.hero')[0]&&!$('.era-band')[0]&&STUDY[base]){
  var sec=$('main .section')[0],h=sec&&sec.querySelector('h1');
  if(h){isStudy=true;var band=d.createElement('section'),bw=d.createElement('div');band.className='hero im-study'+(sec.classList.contains('no-print')?' no-print':'');bw.className='wrap';band.appendChild(bw);
    var ew=h.parentNode;[].slice.call(ew.children).forEach(function(k){
      if(k===h||k.classList.contains('eyebrow')||k.classList.contains('lede')||(k.tagName==='DIV'&&k.querySelector('a.btn[download]')))bw.appendChild(k)});
    sec.parentNode.insertBefore(band,sec);sec.style.paddingTop='2.5rem'}
}
var hero=$('.hero')[0]||$('.era-band')[0],photo;
if(hero){
  var st=d.createElement('div');st.className='im-stage';
  st.innerHTML='<div class="im-photo"></div><div class="im-veil"></div><div class="im-sun"></div><canvas class="im-dust"></canvas><div class="im-grain"></div>';
  hero.insertBefore(st,hero.firstChild);photo=st.querySelector('.im-photo');if(isStudy){var arch=d.createElement('div');arch.className='im-arch';hero.appendChild(arch)}
  var cv=st.querySelector('canvas'),cx=cv.getContext('2d'),P=[],W,H;
  function size(){W=cv.width=hero.offsetWidth;H=cv.height=hero.offsetHeight}
  size();addEventListener('resize',size);
  for(var i=0;i<(innerWidth<700?24:60);i++)P.push({x:Math.random(),y:Math.random(),r:Math.random()*1.8+.4,v:Math.random()*.00035+.00008,a:Math.random()*6.28});
  (function loop(t){
    cx.clearRect(0,0,W,H);
    P.forEach(function(p){p.y-=p.v*16;p.a+=.01;if(p.y<-.02){p.y=1.02;p.x=Math.random()}
      cx.globalAlpha=.25+.35*Math.abs(Math.sin(p.a));cx.fillStyle='#d8b565';cx.beginPath();cx.arc(p.x*W+Math.sin(p.a)*10,p.y*H,p.r,0,6.28);cx.fill()});
    if(!reduce)requestAnimationFrame(loop);
  })(0);
  /* split headline into words (text is preserved exactly) */
  var h1=hero.querySelector('h1');
  if(h1){var n=0;(function walk(el){[].slice.call(el.childNodes).forEach(function(c){
    if(c.nodeType===3){var f=d.createDocumentFragment();c.textContent.split(/(\s+)/).forEach(function(w){
      if(!w)return;if(/^\s+$/.test(w)){f.appendChild(d.createTextNode(w));return}
      var o=d.createElement('span');o.className='im-w';var i=d.createElement('span');i.style.setProperty('--i',n++);i.textContent=w;o.appendChild(i);f.appendChild(o)});
      c.parentNode.replaceChild(f,c)}else if(c.nodeType===1&&c.tagName!=='BR')walk(c)})})(h1);
    setTimeout(function(){R.classList.add('im-go')},reduce?0:900)}
}

/* photos from Wikimedia Commons (decorative) */
var Q={modern:['Parliament of India New Delhi'],root:['Taj Mahal Agra'],ancient:['Great Bath Mohenjo-daro'],medieval:['Hampi Vittala temple stone chariot'],colonial:['Victoria Memorial Kolkata']};
var CQ={ancient:'Sanchi Stupa',medieval:'Red Fort Delhi',colonial:'Gateway of India Mumbai',modern:'India Gate New Delhi'};
var API='https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&prop=imageinfo&iiprop=url|size|mime&iiurlwidth=1600&generator=search&gsrnamespace=6&gsrlimit=12&gsrsearch=';
function find(q){return fetch(API+encodeURIComponent(q+' filetype:bitmap')).then(function(r){return r.json()}).then(function(j){
  var p=j.query&&j.query.pages;if(!p)return null;
  var a=Object.keys(p).map(function(k){return p[k]}).filter(function(x){var i=x.imageinfo&&x.imageinfo[0];return i&&/jpeg/.test(i.mime)&&i.width>=1400&&i.width>i.height*1.15}).sort(function(a,b){return a.index-b.index});
  return a[0]||null}).catch(function(){return null})}
var chap=/-india\/(?!index)/.test(path),h1t=hero&&hero.querySelector('h1');
if(photo)(isStudy?find(STUDY[base]).then(function(x){return x||find(Q[page][0])}):chap&&h1t?(hero.getAttribute('data-img')?hero.getAttribute('data-img').split('|').reduce(function(pr,q){return pr.then(function(x){return x||find(q.trim())})},Promise.resolve(null)):find(h1t.textContent.replace(/\s+/g,' ').trim()+' India')).then(function(x){return x||find(Q[page][0])}):find(Q[page][0])).then(function(x){if(!x)return;var i=x.imageinfo[0],im=new Image();
  im.onload=function(){photo.style.backgroundImage='url("'+im.src+'")';photo.classList.add('in');var ar=hero.querySelector('.im-arch');if(ar){ar.style.backgroundImage='url("'+im.src+'")';ar.classList.add('in')}};im.src=i.thumburl||i.url;
  var a=d.createElement('a');a.className='im-credit';a.href=i.descriptionurl;a.target='_blank';a.rel='noopener';a.textContent='Photo: Wikimedia Commons';hero.appendChild(a)});
$('.era-cards>*').forEach(function(c){var q=CQ[c.getAttribute('data-era')];if(!q)return;
  var b=d.createElement('div');b.className='im-cardbg';c.insertBefore(b,c.firstChild);
  find(q).then(function(x){if(x){var i=x.imageinfo[0];b.style.backgroundImage='url("'+(i.thumburl||i.url)+'")'}})});

/* reveal on scroll */
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('im-in');io.unobserve(e.target)}})},{threshold:.12,rootMargin:'0px 0px -6% 0px'});
$('.reveal,.river').forEach(function(el){io.observe(el)});
$('.era-cards,.chapter-cards,.stat-strip').forEach(function(g){$('.reveal,:scope>*',g).forEach(function(c,i){c.style.setProperty('--d',(i*.09)+'s')})});
$('.river__node').forEach(function(n,i){n.style.setProperty('--n',i)});
setTimeout(function(){$('.reveal').forEach(function(e){if(!e.classList.contains('im-in')&&e.getBoundingClientRect().top<innerHeight)e.classList.add('im-in')})},1400);

/* count-up stats */
var cio=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;cio.unobserve(e.target);
  var el=e.target,t=el.textContent,m=t.match(/[\d,.]+/);if(!m||reduce)return;
  var end=parseFloat(m[0].replace(/,/g,'')),dec=(m[0].split('.')[1]||'').length,t0=performance.now();
  (function s(now){var k=Math.min(1,(now-t0)/1600),v=end*(1-Math.pow(1-k,3));
    el.textContent=t.replace(m[0],v.toLocaleString('en-US',{minimumFractionDigits:dec,maximumFractionDigits:dec}));
    if(k<1)requestAnimationFrame(s);else el.textContent=t})(t0)})},{threshold:.6});
$('.stat b').forEach(function(b){cio.observe(b)});

/* card tilt + shine, magnetic buttons */
if(fine&&!reduce){
  $('.era-cards>*,.chapter-cards>*').forEach(function(c){
    var s=d.createElement('div');s.className='im-shine';c.appendChild(s);
    c.addEventListener('mousemove',function(e){var r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;
      c.style.transform='perspective(900px) rotateY('+((x-.5)*9)+'deg) rotateX('+((.5-y)*9)+'deg) translateY(-6px)';
      s.style.setProperty('--mx',x*100+'%');s.style.setProperty('--my',y*100+'%')});
    c.addEventListener('mouseleave',function(){c.style.transform=''})});
  $('.btn').forEach(function(b){
    b.addEventListener('mousemove',function(e){var r=b.getBoundingClientRect();b.style.transform='translate('+((e.clientX-r.left-r.width/2)*.18)+'px,'+((e.clientY-r.top-r.height/2)*.3)+'px)'});
    b.addEventListener('mouseleave',function(){b.style.transform=''})})}

/* scroll + frame loop */
function frame(){
  var y=scrollY,max=R.scrollHeight-innerHeight;bar.style.width=(max>0?y/max*100:0)+'%';
  R.style.setProperty('--sy',y);R.style.setProperty('--my',((my/innerHeight)-.5).toFixed(3));R.style.setProperty('--mx',((mx/innerWidth)-.5).toFixed(3));gx+=(mx-gx)*.12;gy+=(my-gy)*.12;glow.style.transform='translate3d('+gx+'px,'+gy+'px,0)';
  if(hero&&!reduce&&innerWidth>700&&y<hero.offsetHeight){/* hero text stays put and fully readable while scrolling */}
  if(hero&&photo&&!reduce&&innerWidth>700&&y<hero.offsetHeight+200){photo.style.transform='translate3d(0,'+(y*.22)+'px,0) scale('+(1.04+y*.00008)+')'}
  requestAnimationFrame(frame)}
frame();
})();
setTimeout(function(){var l=document.getElementById('page-loader');if(l)l.classList.add('is-hidden')},4200);/*failsafe*/

/* ===== photography everywhere (v6) ===== */
(function(){
var d=document;function $(s,c){return [].slice.call((c||d).querySelectorAll(s))}
var page=d.documentElement.getAttribute('data-page');
var API='https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&prop=imageinfo&iiprop=url|size|mime&iiurlwidth=1600&generator=search&gsrnamespace=6&gsrlimit=15&gsrsearch=';
var POOL={
ancient:['Sanchi Stupa','Ajanta caves','Mohenjo-daro Great Bath','Ashoka pillar Vaishali','Nalanda ruins','Ellora Kailasa temple','Bodh Gaya Mahabodhi temple','Udayagiri caves'],
medieval:['Qutb Minar Delhi','Hampi Virupaksha temple','Red Fort Delhi','Fatehpur Sikri','Golconda Fort','Chittorgarh Fort','Humayun tomb','Gol Gumbaz Bijapur'],
colonial:['Victoria Memorial Kolkata','Gateway of India Mumbai','Chhatrapati Shivaji Terminus','Jallianwala Bagh memorial','Fort St George Chennai','Rashtrapati Bhavan','Howrah Bridge','Marine Drive Mumbai colonial buildings'],
modern:['Parliament House New Delhi','Bhakra Nangal Dam','India Gate New Delhi','Rashtrapati Bhavan','Supreme Court of India','Statue of Unity','Vidhana Soudha Bangalore','Lotus Temple Delhi'],
root:['Taj Mahal Agra','Sanchi Stupa','Hampi Virupaksha temple','Gateway of India Mumbai','Parliament House New Delhi','Konark Sun Temple','Red Fort Delhi','Ajanta caves']};
var pool=POOL[page]||POOL.root,ctx={ancient:'ancient India',medieval:'medieval India',colonial:'colonial India',modern:'India'}[page]||'India';
var Q=[],busy=0;
function next(){while(busy<3&&Q.length){busy++;(function(j){run(j.q).then(function(x){j.cb(x)}).then(function(){busy--;next()})})(Q.shift())}}
function run(q){var k='imq6:'+q;try{var c=localStorage.getItem(k);if(c)return Promise.resolve(JSON.parse(c))}catch(e){}
  return fetch(API+encodeURIComponent(q+' filetype:bitmap')).then(function(r){return r.json()}).then(function(j){
    var p=j.query&&j.query.pages;if(!p)return null;
    var a=Object.keys(p).map(function(k){return p[k]}).filter(function(x){var i=x.imageinfo&&x.imageinfo[0];return i&&/jpeg/.test(i.mime)&&i.width>=1400&&i.width>i.height*1.15}).sort(function(a,b){return a.index-b.index});
    var x=a[0];if(!x)return null;var i=x.imageinfo[0],r={u:i.thumburl||i.url,d:i.descriptionurl};
    try{localStorage.setItem(k,JSON.stringify(r))}catch(e){}return r}).catch(function(){return null})}
/* try the specific query first, then a guaranteed topic landmark */
function want(q,fb,cb){Q.push({q:q,cb:function(x){if(x)return cb(x);Q.push({q:fb,cb:function(y){if(y)cb(y)}});next()}});next()}
function wantAny(l,fb,cb){if(l.length<2)return want(l[0],fb,cb);Q.push({q:l[0],cb:function(x){if(x)return cb(x);wantAny(l.slice(1),fb,cb)}});next()}
function hint(el){var v=el.getAttribute('data-img');return v?v.split('|').map(function(z){return z.trim()}).filter(Boolean):null}
function title(el){var h=el.querySelector('h3,h2,h1');return h?h.textContent.replace(/\s+/g,' ').trim():''}
function credit(host,x){var a=d.createElement('a');a.className='im-cr';a.href=x.d;a.target='_blank';a.rel='noopener';a.textContent='Photo: Wikimedia Commons';host.appendChild(a)}
function paint(host,el,x){el.style.backgroundImage='url("'+x.u+'")';host.classList.add('ld');credit(host,x)}

/* cards: every card gets a photo header (fallback = topic landmark) */
$('.chapter-cards>*,.era-cards>*').forEach(function(c,i){
  var t=title(c);var p=d.createElement('div');p.className='im-cardpic';p.innerHTML='<div></div>';c.insertBefore(p,c.firstChild);
  var era=c.getAttribute('data-era'),fb=pool[i%pool.length];
  if(era&&POOL[era])fb=POOL[era][0];
  var hq=hint(c);if(hq)wantAny(hq,fb,function(x){paint(p,p.firstChild,x)});else want(era?fb:(t+' '+ctx),fb,function(x){paint(p,p.firstChild,x)})});

/* figures (diagrams): photo backdrop + frosted diagram panel, all of them */
$('.figure').forEach(function(f,i){
  if(!f.querySelector('svg')||f.querySelector('table,h2,h3,h4,p,a,ul,ol'))return;
  var e=f.closest('.entry'),t=e?title(e):'';var b=d.createElement('div');b.className='im-figbg';f.insertBefore(b,f.firstChild);f.classList.add('im-figure');
  want((t?t+' ':'')+ctx,pool[(i+2)%pool.length],function(x){paint(f,b,x)})});
$('.figure').forEach(function(f){var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){f.classList.add('im-draw');o.disconnect()}})},{threshold:.3});o.observe(f)});

/* entry banners on chronicle pages */
$('.entry').forEach(function(e,i){
  var t=title(e);if(!t)return;var f=d.createElement('figure');f.className='im-fig';f.innerHTML='<div class="pic"></div>';
  var h=e.querySelector('.entry__head');h&&h.nextSibling?e.insertBefore(f,h.nextSibling):e.insertBefore(f,e.firstChild);
  var hq=hint(e);if(hq)wantAny(hq,pool[i%pool.length],function(x){paint(f,f.firstChild,x)});else want(t+' '+ctx,pool[i%pool.length],function(x){paint(f,f.firstChild,x)})});

/* section dividers: topic landmark + medallion with the site mark */
$('main>.section,main>section.section').forEach(function(s,i){
  if(i%2!==1||d.querySelector('.im-study'))return;var b=d.createElement('div');b.className='im-band';
  b.innerHTML='<div class="bg"></div><span class="im-orn"><img src="'+(page==='root'?'':'')+'assets/img/loader-mark.png" alt=""></span>';
  var pre=/\/(ancient-india|medieval-india|colonial-india|modern-india)\//.test(location.pathname);if(pre)b.querySelector('img').src='../assets/img/loader-mark.png';
  s.parentNode.insertBefore(b,s);
  var q=pool[(i>>1)%pool.length];want(q,pool[0],function(x){paint(b,b.firstChild,x)})});
window.__im={run:run,pool:pool};
})();


/* loader: the five painted loading screens, one per section */
(function(){
var L=document.getElementById('page-loader'),d=document;if(!L||!window.__im)return;
var me=d.querySelector('script[src*="immersive.js"]'),pre=me?me.getAttribute('src').replace('js/immersive.js',''):'assets/';
var P=d.documentElement.getAttribute('data-page')||'root',key={ancient:'ancient',medieval:'medieval',colonial:'colonial',modern:'modern'}[P]||'overview';
var Y={overview:690,ancient:702,medieval:679,modern:692,colonial:706}[key],url=pre+'img/loader-'+key+'.jpg';
var abs=(function(){var a=d.createElement('a');a.href=url;return a.href})();
var s=d.createElement('div');s.className='im-lslides';
s.innerHTML='<div class="im-lblur" style="background-image:url('+url+')"></div><div class="im-lstage" style="--img:url(\''+abs+'\');--by:'+(Y/9.41).toFixed(2)+'%"><div class="im-lblk"><div class="im-lbar2"><i></i><b></b></div><div class="im-lload">Loading&hellip;</div></div></div>';
var kids=[].slice.call(L.children),card=d.createElement('div');card.className='im-lcard';card.style.display='none';kids.forEach(function(k){card.appendChild(k)});
L.appendChild(s);L.appendChild(card);
var f=d.querySelector('.site-footer');if(f){var m=d.createElement('div');m.className='im-fbg';f.insertBefore(m,f.firstChild);
window.__im.run(window.__im.pool[1]||window.__im.pool[0]).then(function(x){if(x){m.style.backgroundImage='url("'+x.u+'")';m.classList.add('ld')}})}
})();

/* timeline + atlas enhancements */
(function(){
var d=document;if(!window.__im)return;
var list=d.getElementById('timeline-list');
if(list){
  var eras={ancient:'Sanchi Stupa',medieval:'Qutb Minar Delhi',colonial:'Victoria Memorial Kolkata',modern:'Parliament House New Delhi'};
  Object.keys(eras).forEach(function(k){window.__im.run(eras[k]).then(function(x){if(x)d.documentElement.style.setProperty('--pic-'+k,'url("'+x.u+'")')})});
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('tl-in');io.unobserve(e.target)}})},{threshold:.12});
  function deco(){[].slice.call(list.children).forEach(function(li){io.observe(li)})}
  new MutationObserver(deco).observe(list,{childList:true});deco();
  function prog(){var r=list.getBoundingClientRect(),p=Math.min(1,Math.max(0,(innerHeight*.6-r.top)/r.height));list.style.setProperty('--p',(p*100)+'%')}
  addEventListener('scroll',prog,{passive:true});prog();
}
var panel=d.getElementById('map-panel');
if(panel){
  var last='';
  new MutationObserver(function(){
    var h=panel.querySelector('h3');if(!h)return;var t=h.textContent.trim();
    if(t===last&&panel.querySelector('.im-mappic'))return;last=t;
    var old=panel.querySelector('.im-mappic');if(old)old.remove();
    var p=d.createElement('div');p.className='im-mappic';panel.insertBefore(p,panel.firstChild);
    var pool=window.__im.pool;
    window.__im.run(t+' India').then(function(x){return x||window.__im.run(pool[0])}).then(function(x){if(x){p.style.backgroundImage='url("'+x.u+'")';p.style.opacity=1}else p.remove()});
  }).observe(panel,{childList:true,subtree:true});
}
})();

/* v12: header auto-hide, page-transition curtain, prefetch, kinetic headings */
(function(){
var d=document,R=d.documentElement,reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
/* header hides on scroll down, returns on scroll up */
var hd=d.querySelector('.site-header'),ly=scrollY;
if(hd)addEventListener('scroll',function(){var y=scrollY,hide=y>ly&&y>360;if(y!==ly){hd.classList.toggle('im-hide',hide);R.classList.toggle('im-hdr-hide',hide)}ly=y},{passive:true});
/* curtain */
var me=d.querySelector('script[src*="immersive.js"]'),logo=me?me.getAttribute('src').replace('js/immersive.js','img/loader-mark.png'):'';
var cur=d.createElement('div');cur.className='im-curtain';cur.innerHTML='<img alt="" src="'+logo+'">';d.body.appendChild(cur);
addEventListener('pageshow',function(e){cur.classList.remove('on')});
var seen={};
d.addEventListener('mouseover',function(e){var a=e.target.closest&&e.target.closest('a[href]');if(!a||a.origin!==location.origin||seen[a.href]||/\.pdf$/i.test(a.pathname))return;seen[a.href]=1;var l=d.createElement('link');l.rel='prefetch';l.href=a.href;d.head.appendChild(l)});
d.addEventListener('click',function(e){
  var a=e.target.closest&&e.target.closest('a[href]');
  if(!a||reduce||e.defaultPrevented||e.button||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||a.target==='_blank'||a.hasAttribute('download')||a.origin!==location.origin||/\.pdf$/i.test(a.pathname)||(a.pathname===location.pathname&&a.hash))return;
  e.preventDefault();cur.style.setProperty('--cx',e.clientX+'px');cur.style.setProperty('--cy',e.clientY+'px');cur.classList.add('on');
  setTimeout(function(){location.href=a.href},560);
});
/* kinetic headings */
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('im-go');io.unobserve(e.target)}})},{threshold:.4});
[].slice.call(d.querySelectorAll('main h2')).forEach(function(h){
  if(h.querySelector('.im-w')||h.closest('.hero,.era-band'))return;var n=0;
  (function walk(el){[].slice.call(el.childNodes).forEach(function(c){
    if(c.nodeType===3){var f=d.createDocumentFragment();c.textContent.split(/(\s+)/).forEach(function(w){if(!w)return;if(/^\s+$/.test(w)){f.appendChild(d.createTextNode(w));return}
      var o=d.createElement('span');o.className='im-w';var i=d.createElement('span');i.style.setProperty('--i',n++);i.textContent=w;o.appendChild(i);f.appendChild(o)});c.parentNode.replaceChild(f,c)}
    else if(c.nodeType===1&&!/^(svg|BR|IMG)$/i.test(c.tagName))walk(c)})})(h);
  io.observe(h)});
})();

/* v14: mobile bottom tab bar */
(function(){
var d=document,me=d.querySelector('script[src*="immersive.js"]');if(!me)return;
var pre=me.getAttribute('src').replace('assets/js/immersive.js','');
var I={home:'<svg viewBox="0 0 24 24"><path d="M3 11l9-8 9 8M5 10v10h14V10"/></svg>',tl:'<svg viewBox="0 0 24 24"><path d="M12 3v18"/><circle cx="12" cy="7" r="2.2"/><circle cx="12" cy="17" r="2.2"/><path d="M14.5 7H20M4 17h5.5"/></svg>',map:'<svg viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-11a7 7 0 10-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.4"/></svg>',fc:'<svg viewBox="0 0 24 24"><rect x="3" y="6" width="14" height="12" rx="2"/><path d="M7 3h13a1 1 0 011 1v11"/></svg>',qz:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 114 2c-.9.6-1.5 1-1.5 2M12 17h.01"/></svg>'};
var T=[['index.html','Home',I.home],['timeline.html','Timeline',I.tl],['map.html','Atlas',I.map],['flashcards.html','Cards',I.fc],['quiz.html','Quiz',I.qz]];
var cur=location.pathname.split('/').pop()||'index.html',inPortal=/-india\//.test(location.pathname);
var nav=d.createElement('nav');nav.className='im-tabs';nav.setAttribute('aria-label','Quick navigation');
nav.innerHTML=T.map(function(t){var on=t[0]===cur||(t[0]==='index.html'&&/index\.html$|\/$/.test(location.pathname)&&!inPortal);return '<a href="'+pre+t[0]+'"'+(on?' class="on" aria-current="page"':'')+'>'+t[2]+'<span>'+t[1]+'</span></a>'}).join('');
d.body.appendChild(nav);
})();

/* mobile: collapsible footer sections */
document.addEventListener('click',function(e){var h=e.target.closest&&e.target.closest('.site-footer h4');if(h&&innerWidth<=700)h.classList.toggle('open')});

setTimeout(function(){[].slice.call(document.querySelectorAll('main h2')).forEach(function(h){h.classList.add('im-go')})},4500);
(function(){var h=document.querySelector('.site-header');if(!h)return;function s(){document.documentElement.style.setProperty('--im-hh',h.offsetHeight+'px')}s();addEventListener('resize',s);addEventListener('load',s);setTimeout(s,1500)})();
