# Chronicle of Bharat

A static, multi-era study site for Indian history. The four chronological chronicles are complemented by a cross-era **Thematic Studies** portal, a local study dashboard and revision tools. Serve the project root over HTTP for the complete experience; browsers may block shared SVG map references when pages are opened directly with `file://`.

## Run locally

From this folder, run:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## Site structure

- `index.html` — the original Chronicle of Bharat home page and four era summaries.
- `ancient-india/`, `medieval-india/`, `colonial-india/`, `modern-india/` — chronological deep-dive portals and their study companions.
- `thematic-studies/index.html` — nine cross-era modules on Rajasthan and the North-West, Indian Ocean trade, people’s histories, constitutional federalism, environmental history, science and knowledge, cities, regional movements and exam-answer practice.
- `dashboard.html`, `revision.html`, `map-timeline.html` — local progress tracking, spaced-repetition review and the interactive map timeline.

The thematic chapters connect to the existing content rather than replacing it. New material is discoverable through the home page, global navigation, search, dashboard, glossary, flashcards, quizzes, chronology, atlas and map timeline. The theme portal also links back into the chronological portals.

## Shared study experience

- Site-wide navbar search is available in the main era pages and nested deep-dive pages.
- Glossary terms are underlined in relevant narrative copy; focus or hover to read their definitions.
- Era portals include a local study companion: timeline, atlas, glossary, quiz, flashcards, revision notes and political succession.
- The thematic studies are listed in the dashboard so chapters can be visited and marked complete.
- Historical pages offer English/Hindi machine translation and English/Hindi Wikipedia further-reading links. Hindi translation requires an internet connection; machine translation may not preserve every historical nuance.
- There is no separate bibliography section on the thematic pages.

## Shared brand mark and attribution

All header and footer brand marks use the canonical original artwork from `assets/img/chronicle-brand-mark.png`. The India atlas uses shared state/Union Territory geometry in `assets/svg/india-states-simplemaps.svg`; its Simplemaps copyright and license comment are retained. Map geometry is © 2024 Pareto Software, LLC DBA Simplemaps.com, used under the [Simplemaps SVG license](https://simplemaps.com/resources/svg-license), with attribution appreciated at [Simplemaps.com](https://simplemaps.com).

## Local study profile, backups and offline use

- **No account or sign-in is used.** Topic completion, recently visited pages, quiz attempts, personal notes and revision scheduling are saved in the browser’s `localStorage` on that computer. The site does not upload or sync study data to a server.
- This is browser site storage, not the browser’s file cache. It normally remains after closing and reopening the browser, but clearing site/browser data can erase it. Private browsing may discard it when the session closes. It is scoped to that browser profile, is not synced to other devices or password-protected, and is visible to anyone using that browser profile.
- Use the dashboard’s **Download progress backup** and **Restore progress backup** controls to keep a JSON copy or move the profile to another browser/device. Keep backups somewhere safe; they may contain personal notes.
- `revision.html` provides spaced repetition for the shared glossary and learner-created cards. Download a Markdown pack or print/save as PDF.
- `map-timeline.html` links dated events to places and related chapters. State outlines show present-day geography for orientation, not historical borders.
- The service worker caches the core study shell and pages opened online. Use the dashboard install button or your browser’s “Add to Home Screen” option to keep study tools available offline after the first online visit. Offline page caching is separate from local study-data storage.

## Netlify publishing

This is a static multi-page site; no application server, build step, authentication provider or environment variables are required. The included `netlify.toml` publishes the project root and sets service-worker and manifest cache headers. Connect the repository to Netlify or upload the project folder.

## Language-widget terms

The English/Hindi selector uses GTranslate’s website widget. Under the provider’s [terms](https://gtranslate.io/terms), the free version is limited to personal, educational, testing, nonprofit or government use that does not directly generate revenue; commercial use requires a paid subscription. Confirm the site qualifies before publishing.
