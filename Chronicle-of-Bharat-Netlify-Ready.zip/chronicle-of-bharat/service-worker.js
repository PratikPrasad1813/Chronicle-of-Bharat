/* Offline shell + cache for pages the learner has opened. */
'use strict';
const CACHE='chronicle-shell-v5';
const CORE_FILES=[
  'index.html','dashboard.html','revision.html','map-timeline.html','timeline.html','map.html','offline.html',
  'thematic-studies/index.html','thematic-studies/rajasthan-northwest.html','thematic-studies/indian-ocean.html',
  'thematic-studies/peoples-histories.html','thematic-studies/constitution-federalism.html','thematic-studies/environmental-history.html',
  'thematic-studies/science-knowledge.html','thematic-studies/cities-through-time.html','thematic-studies/regional-movements.html',
  'thematic-studies/exam-answer-workshops.html',
  'manifest.webmanifest','assets/css/style.css','assets/css/immersive.css','assets/css/chronicle-extras.css','assets/css/thematic-studies.css',
  'assets/js/chronicle-extras.js','assets/js/immersive.js','assets/js/main.js','assets/js/site-search-index.js',
  'assets/js/dashboard.js','assets/js/revision.js','assets/js/map-timeline.js','assets/js/thematic-movements.js',
  'assets/js/portal-study-tools.js','assets/js/flashcards.js','assets/js/quiz.js',
  'assets/js/map-timeline-data.js','assets/js/india-geo.js','assets/js/map-data.js','assets/js/glossary-data.js',
  'assets/js/quiz-data.js','assets/js/timeline-data.js','assets/img/chronicle-brand-mark.png',
  'assets/svg/india-states-simplemaps.svg','assets/svg/bharat-compass.svg'
];
self.addEventListener('install',function(event){
  event.waitUntil((async function(){
    const cache=await caches.open(CACHE);
    await Promise.all(CORE_FILES.map(async function(file){try{await cache.add(new URL(file,self.registration.scope).href);}catch(_){}}));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate',function(event){
  event.waitUntil((async function(){
    const keys=await caches.keys();
    await Promise.all(keys.filter(function(key){return key.indexOf('chronicle-')===0&&key!==CACHE;}).map(function(key){return caches.delete(key);}));
    await self.clients.claim();
  })());
});
self.addEventListener('message',function(event){if(event.data==='SKIP_WAITING')self.skipWaiting();});
self.addEventListener('fetch',function(event){
  const request=event.request;
  if(request.method!=='GET')return;
  const url=new URL(request.url);
  if(url.origin!==self.location.origin)return;
  if(request.mode==='navigate'){
    event.respondWith((async function(){
      const cache=await caches.open(CACHE);
      try{
        const response=await fetch(request);
        if(response&&response.ok)cache.put(request,response.clone());
        return response;
      }catch(_){
        const saved=await cache.match(request)||await cache.match(new URL('offline.html',self.registration.scope).href);
        return saved||new Response('You are offline. Open a page you have visited before or reconnect to the internet.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}});
      }
    })());
    return;
  }
  if(!/\.(?:html|css|js|svg|png|webmanifest|pdf)$/i.test(url.pathname))return;
  event.respondWith((async function(){
    const cache=await caches.open(CACHE),cached=await cache.match(request);
    const network=fetch(request).then(function(response){if(response&&response.ok)cache.put(request,response.clone());return response;}).catch(function(){return null;});
    return cached||await network||new Response('',{status:504});
  })());
});
