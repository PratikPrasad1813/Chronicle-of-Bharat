(function(){
  "use strict";
  var terms = (window.GLOSSARY || []).slice().sort(function(a,b){ return a.term.localeCompare(b.term); });
  var list = document.getElementById("glossary-list");
  var countEl = document.getElementById("glossary-count");
  var searchInput = document.getElementById("glossary-search");
  var filterBtns = document.querySelectorAll(".gl-filter");
  var activeEra = "all";

  var eraLabel = { ancient:"Ancient", medieval:"Medieval", modern:"Modern" };

  function slugify(s){
    return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  }

  function render(){
    var q = (searchInput.value || "").trim().toLowerCase();
    var shown = terms.filter(function(t){
      var eraOk = activeEra === "all" || t.era === activeEra;
      var qOk = !q || (t.term + " " + t.def).toLowerCase().indexOf(q) !== -1;
      return eraOk && qOk;
    });
    list.innerHTML = "";
    if(!shown.length){
      list.innerHTML = '<p class="small" style="padding:1rem 0;">No terms match. Try a different filter or search.</p>';
    }
    shown.forEach(function(t){
      var card = document.createElement("div");
      card.className = "gl-card gl-card--" + t.era;
      card.id = "term-" + slugify(t.term);
      card.innerHTML =
        '<div class="gl-card__head">' +
          '<h3>' + t.term + '</h3>' +
          '<span class="chip gl-chip gl-chip--' + t.era + '">' + eraLabel[t.era] + '</span>' +
        '</div>' +
        '<p>' + t.def + '</p>';
      list.appendChild(card);
    });
    countEl.textContent = shown.length + " of " + terms.length + " terms";
  }

  filterBtns.forEach(function(btn){
    btn.addEventListener("click", function(){
      activeEra = btn.getAttribute("data-filter");
      filterBtns.forEach(function(b){ b.classList.toggle("is-active", b === btn); });
      render();
    });
  });
  searchInput.addEventListener("input", render);

  render();

  // Deep-link: scroll to and briefly highlight a term if the URL has a hash
  if(location.hash && location.hash.indexOf("#term-") === 0){
    setTimeout(function(){
      var el = document.getElementById(location.hash.slice(1));
      if(el){
        el.scrollIntoView({ behavior:"smooth", block:"center" });
        el.classList.add("is-highlighted");
      }
    }, 120);
  }
})();
