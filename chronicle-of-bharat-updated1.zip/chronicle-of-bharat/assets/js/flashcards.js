(function(){
  "use strict";
  var terms = (window.GLOSSARY || []).slice();

  var screens = {
    setup: document.getElementById("fc-setup"),
    play: document.getElementById("fc-play"),
    done: document.getElementById("fc-done")
  };
  var eraCheckboxes = document.querySelectorAll(".fc-era-check");
  var startBtn = document.getElementById("fc-start");
  var restartBtn = document.getElementById("fc-restart");
  var retryWeakBtn = document.getElementById("fc-retry-weak");

  var card = document.getElementById("fc-card");
  var cardTerm = document.getElementById("fc-term");
  var cardEraFront = document.getElementById("fc-era-front");
  var cardDef = document.getElementById("fc-def");
  var progressEl = document.getElementById("fc-progress");
  var progressBar = document.getElementById("fc-progress-bar");
  var knowBtn = document.getElementById("fc-know");
  var learningBtn = document.getElementById("fc-learning");
  var prevBtn = document.getElementById("fc-prev");
  var shuffleBtn = document.getElementById("fc-shuffle");

  var doneKnow = document.getElementById("fc-done-know");
  var doneLearning = document.getElementById("fc-done-learning");

  var state = null;

  function shuffle(arr){
    var a = arr.slice();
    for(var i = a.length - 1; i > 0; i--){
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  function showScreen(name){
    Object.keys(screens).forEach(function(k){ screens[k].hidden = (k !== name); });
  }

  function getSelectedEras(){
    var out = [];
    eraCheckboxes.forEach(function(c){ if(c.checked) out.push(c.value); });
    return out.length ? out : ["ancient","medieval","colonial","modern"];
  }

  function begin(pool){
    state = {
      deck: shuffle(pool),
      index: 0,
      flipped: false,
      know: [],
      learning: []
    };
    showScreen("play");
    renderCard();
  }

  function startFromSetup(){
    var eras = getSelectedEras();
    var pool = terms.filter(function(t){ return eras.indexOf(t.era) !== -1; });
    begin(pool);
  }

  function renderCard(){
    if(state.index >= state.deck.length){
      finishSession();
      return;
    }
    var t = state.deck[state.index];
    state.flipped = false;
    card.classList.remove("is-flipped");
    cardTerm.textContent = t.term;
    cardEraFront.textContent = eraLabel(t.era);
    cardEraFront.className = "chip fc-era-chip fc-era-chip--" + t.era;
    cardDef.textContent = t.def;
    progressEl.textContent = "Card " + (state.index + 1) + " of " + state.deck.length;
    progressBar.style.width = (state.index / state.deck.length * 100) + "%";
    prevBtn.disabled = state.index === 0;
  }

  function eraLabel(era){
    return era === "ancient" ? "Ancient" : era === "medieval" ? "Medieval" : era === "colonial" ? "Colonial" : "Modern";
  }

  function flip(){
    state.flipped = !state.flipped;
    card.classList.toggle("is-flipped", state.flipped);
  }

  function mark(bucket){
    var t = state.deck[state.index];
    if(bucket === "know") state.know.push(t);
    else state.learning.push(t);
    state.index++;
    renderCard();
  }

  function goPrev(){
    if(state.index > 0){
      state.index--;
      renderCard();
    }
  }

  function reshuffleDeck(){
    var remaining = state.deck.slice(state.index);
    state.deck = state.deck.slice(0, state.index).concat(shuffle(remaining));
    renderCard();
  }

  function finishSession(){
    showScreen("done");
    doneKnow.textContent = state.know.length;
    doneLearning.textContent = state.learning.length;
    retryWeakBtn.hidden = state.learning.length === 0;
  }

  card.addEventListener("click", flip);
  card.addEventListener("keydown", function(e){
    if(e.key === "Enter" || e.key === " "){ e.preventDefault(); flip(); }
  });
  knowBtn.addEventListener("click", function(){ mark("know"); });
  learningBtn.addEventListener("click", function(){ mark("learning"); });
  prevBtn.addEventListener("click", goPrev);
  shuffleBtn.addEventListener("click", reshuffleDeck);
  startBtn.addEventListener("click", startFromSetup);
  restartBtn.addEventListener("click", function(){ showScreen("setup"); });
  retryWeakBtn.addEventListener("click", function(){ begin(state.learning); });

  showScreen("setup");
})();
